const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const crypto = require("crypto");

const userSchema = new mongoose.Schema(
  {
    // ---------- الخطوة 1: البيانات الأساسية ----------
    name: {
      type: String,
      required: [true, "الاسم مطلوب"],
      trim: true,
    },
    phone: {
      type: String,
      required: [true, "رقم الجوال مطلوب"],
      trim: true,
    },
    email: {
      type: String,
      required: [true, "البريد الإلكتروني مطلوب"],
      unique: true,
      lowercase: true,
      trim: true,
    },
    password: {
      type: String,
      required: [true, "كلمة المرور مطلوبة"],
      minlength: 8,
      select: false, // لا تُرجع كلمة المرور تلقائياً في أي query
    },

    // ---------- الخطوة 2: بيانات النشاط ----------
    salonName: { type: String, trim: true },
    activityName: { type: String, trim: true },

    // ---------- الخطوة 3: الاشتراك / الدفع ----------
    subscription: {
      plan: { type: String, default: null },
      paid: { type: Boolean, default: false },
      paidAt: { type: Date, default: null },
      paymentRef: { type: String, default: null },
    },

    // ---------- حالة الحساب ----------
    // pending  = تم التسجيل ولم يكتمل الدفع بعد
    // active   = تم الدفع، الحساب مفعل ويمكنه الدخول
    // suspended = موقوف من الإدارة
    status: {
      type: String,
      enum: ["pending", "active", "suspended"],
      default: "pending",
    },

    // ---------- استعادة كلمة المرور ----------
    resetPasswordToken: { type: String, select: false },
    resetPasswordExpire: { type: Date, select: false },
  },
  { timestamps: true }
);

// تشفير كلمة المرور قبل الحفظ (فقط إذا تغيّرت)
userSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next();
  const salt = await bcrypt.genSalt(12);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

// مقارنة كلمة المرور المدخلة مع المخزنة
userSchema.methods.comparePassword = async function (enteredPassword) {
  return bcrypt.compare(enteredPassword, this.password);
};

// إنشاء توكن استعادة كلمة المرور (يُرسل بالبريد كنص خام، ويُخزن كـ hash في القاعدة)
userSchema.methods.generateResetPasswordToken = function () {
  const rawToken = crypto.randomBytes(32).toString("hex");

  this.resetPasswordToken = crypto
    .createHash("sha256")
    .update(rawToken)
    .digest("hex");

  const expireMinutes = parseInt(process.env.RESET_TOKEN_EXPIRES_MIN || "30", 10);
  this.resetPasswordExpire = Date.now() + expireMinutes * 60 * 1000;

  return rawToken; // هذا هو الذي يُرسل في رابط البريد الإلكتروني
};

module.exports = mongoose.model("User", userSchema);
