const crypto = require("crypto");
const jwt = require("jsonwebtoken");
const validator = require("validator");
const User = require("../models/User");
const sendEmail = require("../utils/sendEmail");

// ---------- أداة مساعدة: إنشاء JWT ----------
const generateToken = (userId) => {
  return jwt.sign({ id: userId }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || "7d",
  });
};

/* =========================================================
   الخطوة 1: التسجيل الأساسي (اسم / جوال / إيميل / كلمة مرور)
   POST /api/auth/register/step1
   ========================================================= */
exports.registerStep1 = async (req, res) => {
  try {
    const { name, phone, email, password, confirmPassword } = req.body;

    if (!name || !phone || !email || !password || !confirmPassword) {
      return res.status(400).json({ message: "جميع الحقول مطلوبة" });
    }

    if (!validator.isEmail(email)) {
      return res.status(400).json({ message: "صيغة البريد الإلكتروني غير صحيحة" });
    }

    if (password !== confirmPassword) {
      return res.status(400).json({ message: "كلمتا المرور غير متطابقتين" });
    }

    if (password.length < 8) {
      return res.status(400).json({ message: "كلمة المرور يجب ألا تقل عن 8 أحرف" });
    }

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(409).json({ message: "البريد الإلكتروني مسجل مسبقاً" });
    }

    // إنشاء الحساب بحالة pending (لم يكتمل التسجيل/الدفع بعد)
    const user = await User.create({
      name,
      phone,
      email,
      password,
      status: "pending",
    });

    return res.status(201).json({
      message: "تم إنشاء الحساب، يرجى استكمال بيانات النشاط",
      userId: user._id,
    });
  } catch (error) {
    return res.status(500).json({ message: "حدث خطأ في الخادم", error: error.message });
  }
};

/* =========================================================
   الخطوة 2: بيانات النشاط (اسم الصالون / اسم النشاط)
   POST /api/auth/register/step2
   ========================================================= */
exports.registerStep2 = async (req, res) => {
  try {
    const { userId, salonName, activityName } = req.body;

    if (!userId || !salonName || !activityName) {
      return res.status(400).json({ message: "جميع الحقول مطلوبة" });
    }

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: "المستخدم غير موجود" });
    }

    user.salonName = salonName;
    user.activityName = activityName;
    await user.save();

    return res.status(200).json({
      message: "تم حفظ بيانات النشاط، يرجى استكمال الدفع لتفعيل الحساب",
      userId: user._id,
    });
  } catch (error) {
    return res.status(500).json({ message: "حدث خطأ في الخادم", error: error.message });
  }
};

/* =========================================================
   الخطوة 3أ: بدء عملية الدفع (إنشاء جلسة دفع)
   POST /api/auth/register/create-payment
   ملاحظة: هذا مثال عام. استبدله بتكامل بوابة الدفع
   الفعلية لديك (مدى / Stripe / PayTabs / HyperPay ... إلخ)
   ========================================================= */
exports.createPayment = async (req, res) => {
  try {
    const { userId, plan } = req.body;

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: "المستخدم غير موجود" });
    }

    // TODO: استبدل هذا بالاتصال الفعلي ببوابة الدفع الخاصة بك
    const fakePaymentSession = {
      checkoutUrl: `https://payment-gateway.example.com/checkout?ref=${user._id}`,
      reference: `PAY-${Date.now()}-${user._id}`,
    };

    user.subscription.plan = plan || "basic";
    user.subscription.paymentRef = fakePaymentSession.reference;
    await user.save();

    return res.status(200).json({
      message: "تم إنشاء جلسة الدفع",
      checkoutUrl: fakePaymentSession.checkoutUrl,
      reference: fakePaymentSession.reference,
    });
  } catch (error) {
    return res.status(500).json({ message: "حدث خطأ في الخادم", error: error.message });
  }
};

/* =========================================================
   الخطوة 3ب: تأكيد نجاح الدفع (Webhook / Callback من بوابة الدفع)
   POST /api/auth/register/payment-callback
   يُستدعى هذا المسار من بوابة الدفع نفسها بعد إتمام العملية،
   أو يمكن استدعاؤه من الفرونت إند بعد رجوع بوابة الدفع بنجاح.
   ========================================================= */
exports.paymentCallback = async (req, res) => {
  try {
    const { reference, success } = req.body;

    const user = await User.findOne({ "subscription.paymentRef": reference });
    if (!user) {
      return res.status(404).json({ message: "لم يتم العثور على عملية الدفع" });
    }

    if (!success) {
      return res.status(400).json({ message: "فشلت عملية الدفع" });
    }

    // ✅ تفعيل الحساب بعد نجاح الدفع
    user.subscription.paid = true;
    user.subscription.paidAt = new Date();
    user.status = "active";
    await user.save();

    return res.status(200).json({
      message: "تم الدفع وتفعيل الحساب بنجاح، يمكنك الآن تسجيل الدخول",
    });
  } catch (error) {
    return res.status(500).json({ message: "حدث خطأ في الخادم", error: error.message });
  }
};

/* =========================================================
   تسجيل الدخول العادي (Email/Username + Password)
   POST /api/auth/login
   ========================================================= */
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: "الرجاء إدخال البريد وكلمة المرور" });
    }

    // select("+password") لأن الحقل مخفي افتراضياً في الموديل
    const user = await User.findOne({ email }).select("+password");

    if (!user || !(await user.comparePassword(password))) {
      return res.status(401).json({ message: "البريد أو كلمة المرور غير صحيحة" });
    }

    if (user.status === "pending") {
      return res.status(403).json({
        message: "الحساب غير مفعّل بعد، يرجى إكمال عملية الدفع لتفعيل الاشتراك",
      });
    }

    if (user.status === "suspended") {
      return res.status(403).json({ message: "الحساب موقوف، يرجى التواصل مع الدعم" });
    }

    const token = generateToken(user._id);

    return res.status(200).json({
      message: "تم تسجيل الدخول بنجاح",
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        salonName: user.salonName,
        activityName: user.activityName,
      },
    });
  } catch (error) {
    return res.status(500).json({ message: "حدث خطأ في الخادم", error: error.message });
  }
};

/* =========================================================
   نسيت كلمة المرور: إرسال رابط إعادة التعيين بالبريد
   POST /api/auth/forgot-password
   ========================================================= */
exports.forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ message: "الرجاء إدخال البريد الإلكتروني" });
    }

    const user = await User.findOne({ email });

    // لأسباب أمنية: نفس الرسالة سواء كان البريد موجوداً أو لا
    const genericMessage =
      "إذا كان البريد الإلكتروني مسجلاً لدينا، فستصلك رسالة تحتوي على رابط إعادة تعيين كلمة المرور";

    if (!user) {
      return res.status(200).json({ message: genericMessage });
    }

    const rawToken = user.generateResetPasswordToken();
    await user.save({ validateBeforeSave: false });

    const resetUrl = `${process.env.CLIENT_URL}/reset-password/${rawToken}`;

    const html = `
      <div style="font-family: Tahoma, Arial, sans-serif; direction: rtl; text-align: right;">
        <h2>طلب إعادة تعيين كلمة المرور</h2>
        <p>مرحباً ${user.name}،</p>
        <p>وصلنا طلب لإعادة تعيين كلمة المرور الخاصة بحسابك. اضغط على الرابط أدناه لتعيين كلمة مرور جديدة:</p>
        <p><a href="${resetUrl}" style="background:#4a86e8;color:#fff;padding:10px 20px;text-decoration:none;border-radius:6px;">تغيير كلمة المرور</a></p>
        <p>هذا الرابط صالح لمدة ${process.env.RESET_TOKEN_EXPIRES_MIN || 30} دقيقة فقط.</p>
        <p>إذا لم تطلب ذلك، يمكنك تجاهل هذه الرسالة بأمان.</p>
      </div>
    `;

    try {
      await sendEmail({
        to: user.email,
        subject: "إعادة تعيين كلمة المرور",
        html,
      });
    } catch (emailError) {
      // في حال فشل إرسال البريد، نلغي التوكن حتى لا يبقى صالحاً بدون فائدة
      user.resetPasswordToken = undefined;
      user.resetPasswordExpire = undefined;
      await user.save({ validateBeforeSave: false });

      return res.status(500).json({ message: "فشل إرسال البريد الإلكتروني، حاول لاحقاً" });
    }

    return res.status(200).json({ message: genericMessage });
  } catch (error) {
    return res.status(500).json({ message: "حدث خطأ في الخادم", error: error.message });
  }
};

/* =========================================================
   إعادة تعيين كلمة المرور (من رابط البريد)
   POST /api/auth/reset-password/:token
   ========================================================= */
exports.resetPassword = async (req, res) => {
  try {
    const { token } = req.params;
    const { password, confirmPassword } = req.body;

    if (!password || !confirmPassword) {
      return res.status(400).json({ message: "الرجاء إدخال كلمة المرور وتأكيدها" });
    }

    if (password !== confirmPassword) {
      return res.status(400).json({ message: "كلمتا المرور غير متطابقتين" });
    }

    if (password.length < 8) {
      return res.status(400).json({ message: "كلمة المرور يجب ألا تقل عن 8 أحرف" });
    }

    // نحوّل التوكن المُستلم إلى نفس الـ hash المخزن في القاعدة للمقارنة
    const hashedToken = crypto.createHash("sha256").update(token).digest("hex");

    const user = await User.findOne({
      resetPasswordToken: hashedToken,
      resetPasswordExpire: { $gt: Date.now() },
    }).select("+resetPasswordToken +resetPasswordExpire");

    if (!user) {
      return res.status(400).json({ message: "رابط إعادة التعيين غير صالح أو منتهي الصلاحية" });
    }

    // تعيين كلمة المرور الجديدة (سيتم تشفيرها تلقائياً عبر pre-save hook)
    user.password = password;
    user.resetPasswordToken = undefined;
    user.resetPasswordExpire = undefined;
    await user.save();

    return res.status(200).json({
      message: "تم تغيير كلمة المرور بنجاح، يمكنك الآن تسجيل الدخول بكلمة المرور الجديدة",
    });
  } catch (error) {
    return res.status(500).json({ message: "حدث خطأ في الخادم", error: error.message });
  }
};

/* =========================================================
   تغيير كلمة المرور من داخل الحساب (مستخدم مسجّل دخول)
   POST /api/auth/change-password  (Protected)
   ========================================================= */
exports.changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword, confirmNewPassword } = req.body;

    if (!currentPassword || !newPassword || !confirmNewPassword) {
      return res.status(400).json({ message: "جميع الحقول مطلوبة" });
    }

    if (newPassword !== confirmNewPassword) {
      return res.status(400).json({ message: "كلمتا المرور الجديدتان غير متطابقتين" });
    }

    if (newPassword.length < 8) {
      return res.status(400).json({ message: "كلمة المرور يجب ألا تقل عن 8 أحرف" });
    }

    const user = await User.findById(req.user._id).select("+password");

    const isMatch = await user.comparePassword(currentPassword);
    if (!isMatch) {
      return res.status(401).json({ message: "كلمة المرور الحالية غير صحيحة" });
    }

    if (currentPassword === newPassword) {
      return res.status(400).json({ message: "كلمة المرور الجديدة يجب أن تختلف عن الحالية" });
    }

    user.password = newPassword;
    await user.save();

    return res.status(200).json({ message: "تم تغيير كلمة المرور بنجاح" });
  } catch (error) {
    return res.status(500).json({ message: "حدث خطأ في الخادم", error: error.message });
  }
};
