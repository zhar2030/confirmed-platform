# نظام تسجيل الدخول والتسجيل - منصة الصالونات

تطبيق Backend (Node.js + Express + MongoDB) يغطي السيناريو التالي:

1. **التسجيل - خطوة 1:** اسم، جوال، إيميل، **كلمة مرور** (بدون كود تحقق)
2. **التسجيل - خطوة 2:** اسم الصالون، اسم النشاط
3. **التسجيل - خطوة 3:** الدفع للاشتراك → تفعيل الحساب تلقائياً بعد نجاح الدفع
4. **تسجيل الدخول العادي:** إيميل + كلمة مرور
5. **نسيت كلمة المرور:** إرسال رابط عبر البريد → فتح نافذة تغيير كلمة المرور → حفظ كلمة المرور الجديدة → التحويل لصفحة تسجيل الدخول
6. **تغيير كلمة المرور من الحساب:** لمستخدم مسجّل دخول بالفعل

## 📁 هيكل المشروع
```
salon-auth/
├── config/db.js                  # الاتصال بقاعدة البيانات
├── models/User.js                 # موديل المستخدم
├── controllers/authController.js  # كل منطق العمليات (Business Logic)
├── routes/authRoutes.js           # تعريف المسارات (Endpoints)
├── middleware/auth.js             # حماية المسارات بـ JWT
├── utils/sendEmail.js             # إرسال البريد الإلكتروني (Nodemailer)
├── public/reset-password.html     # صفحة تغيير كلمة المرور (تُفتح من رابط البريد)
├── server.js                      # نقطة تشغيل السيرفر
└── .env.example                   # متغيرات البيئة (انسخها إلى .env)
```

## ⚙️ التشغيل
```bash
npm install
cp .env.example .env   # ثم عدّل القيم (خصوصاً بيانات SMTP و MONGO_URI)
npm run dev
```

## 🔗 المسارات (API Endpoints)

| Method | Endpoint | الوصف |
|---|---|---|
| POST | `/api/auth/register/step1` | تسجيل البيانات الأساسية (اسم/جوال/إيميل/كلمة مرور) |
| POST | `/api/auth/register/step2` | حفظ بيانات النشاط (اسم الصالون/النشاط) |
| POST | `/api/auth/register/create-payment` | إنشاء جلسة دفع للاشتراك |
| POST | `/api/auth/register/payment-callback` | تأكيد نجاح الدفع وتفعيل الحساب |
| POST | `/api/auth/login` | تسجيل الدخول (إيميل + كلمة مرور) |
| POST | `/api/auth/forgot-password` | طلب رابط استعادة كلمة المرور |
| POST | `/api/auth/reset-password/:token` | حفظ كلمة المرور الجديدة عبر رابط البريد |
| POST | `/api/auth/change-password` | تغيير كلمة المرور (يتطلب تسجيل دخول - Bearer Token) |

## 🧪 أمثلة اختبار (cURL)

### 1) التسجيل - خطوة 1
```bash
curl -X POST http://localhost:5000/api/auth/register/step1 \
  -H "Content-Type: application/json" \
  -d '{"name":"أحمد","phone":"0500000000","email":"ahmed@example.com","password":"Pass1234","confirmPassword":"Pass1234"}'
```

### 2) التسجيل - خطوة 2
```bash
curl -X POST http://localhost:5000/api/auth/register/step2 \
  -H "Content-Type: application/json" \
  -d '{"userId":"<USER_ID>","salonName":"صالون النخبة","activityName":"صالون رجالي"}'
```

### 3) إنشاء جلسة دفع
```bash
curl -X POST http://localhost:5000/api/auth/register/create-payment \
  -H "Content-Type: application/json" \
  -d '{"userId":"<USER_ID>","plan":"basic"}'
```

### 4) تأكيد نجاح الدفع (استدعاء تجريبي، عادة تستدعيه بوابة الدفع)
```bash
curl -X POST http://localhost:5000/api/auth/register/payment-callback \
  -H "Content-Type: application/json" \
  -d '{"reference":"<PAYMENT_REF>","success":true}'
```

### 5) تسجيل الدخول
```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"ahmed@example.com","password":"Pass1234"}'
```

### 6) نسيت كلمة المرور
```bash
curl -X POST http://localhost:5000/api/auth/forgot-password \
  -H "Content-Type: application/json" \
  -d '{"email":"ahmed@example.com"}'
```
سيصل رابط بالبريد مثل:
```
http://localhost:3000/reset-password/<RESET_TOKEN>
```

### 7) تغيير كلمة المرور عبر الرابط
```bash
curl -X POST http://localhost:5000/api/auth/reset-password/<RESET_TOKEN> \
  -H "Content-Type: application/json" \
  -d '{"password":"NewPass123","confirmPassword":"NewPass123"}'
```

### 8) تغيير كلمة المرور من داخل الحساب (بعد تسجيل الدخول)
```bash
curl -X POST http://localhost:5000/api/auth/change-password \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <JWT_TOKEN>" \
  -d '{"currentPassword":"Pass1234","newPassword":"NewPass456","confirmNewPassword":"NewPass456"}'
```

## 🔒 ملاحظات أمنية مطبقة في الكود
- تشفير كلمة المرور بـ **bcrypt** (12 rounds) قبل الحفظ في قاعدة البيانات
- توكن استعادة كلمة المرور:
  - يُنشأ عشوائياً (32 بايت) باستخدام `crypto.randomBytes`
  - يُخزّن في قاعدة البيانات كـ **hash** (SHA-256) وليس كنص خام
  - له **مدة صلاحية محدودة** (30 دقيقة افتراضياً، قابلة للتعديل من `.env`)
  - **يُستخدم مرة واحدة فقط** (يُحذف من القاعدة بعد الاستخدام)
- رسالة "نسيت كلمة المرور" لا تكشف ما إذا كان البريد مسجلاً أو لا (لحماية الخصوصية)
- الحساب لا يمكنه تسجيل الدخول إلا بعد أن يصبح `status = active` (أي بعد نجاح الدفع)
- حقل `password` مخفي افتراضياً (`select: false`) ولا يظهر في أي استعلام إلا صراحة

## 🔧 نقاط تحتاج ربطها بمنصتك الفعلية
1. **بوابة الدفع:** استبدل الكود التجريبي في `createPayment` و `paymentCallback` بتكامل بوابة الدفع الحقيقية لديك (مدى، Stripe، PayTabs، HyperPay، إلخ) — عادة تلك البوابات ترسل Webhook عند نجاح/فشل الدفع، فيجب ربط `paymentCallback` بذلك الـ Webhook مع التحقق من توقيع الطلب (Signature Verification) لمنع التلاعب.
2. **رابط الواجهة الأمامية (Frontend):** غيّر `CLIENT_URL` في `.env` ليطابق رابط موقعك الفعلي حتى يعمل رابط البريد الإلكتروني بشكل صحيح.
3. **صفحة `reset-password.html`:** هذه صفحة تجريبية بسيطة (HTML/JS خام) لتوضيح الفكرة. إذا كانت منصتك مبنية بإطار عمل أمامي (React/Vue/Angular)، يُفضّل بناء نفس الصفحة كمكوّن ضمن ذلك الإطار بدلاً من هذا الملف المستقل.
