const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/auth");
const {
  registerStep1,
  registerStep2,
  createPayment,
  paymentCallback,
  login,
  forgotPassword,
  resetPassword,
  changePassword,
} = require("../controllers/authController");

// ---------- التسجيل (3 خطوات) ----------
router.post("/register/step1", registerStep1); // اسم / جوال / إيميل / باسورد
router.post("/register/step2", registerStep2); // اسم الصالون / النشاط
router.post("/register/create-payment", createPayment); // إنشاء جلسة دفع
router.post("/register/payment-callback", paymentCallback); // تأكيد نجاح الدفع + تفعيل الحساب

// ---------- تسجيل الدخول ----------
router.post("/login", login);

// ---------- نسيان واستعادة كلمة المرور ----------
router.post("/forgot-password", forgotPassword);
router.post("/reset-password/:token", resetPassword);

// ---------- تغيير كلمة المرور (يتطلب تسجيل دخول) ----------
router.post("/change-password", protect, changePassword);

module.exports = router;
