import React, { useState, useEffect } from 'react';
import DashboardOverview from './DashboardOverview';
import BookingsManager from './BookingsManager';
import POSManager from './POSManager';
import InventoryManager from './InventoryManager';
import CRMManager from './CRMManager';
import StaffManager from './StaffManager';
import MarketingManager from './MarketingManager';
import GiftCardsManager from './GiftCardsManager';
import ReportsManager from './ReportsManager';
import SettingsManager from './SettingsManager';
import SubscriptionPaymentGateway from './SubscriptionPaymentGateway';
import CustomerIntelligence from './CustomerIntelligence';
import ExpensesManager from './ExpensesManager';
import ProviderProfileManager from './ProviderProfileManager';
import { useLanguage } from '../LanguageContext';

import { 
  initialBookings, 
  initialServices, 
  initialProducts, 
  initialClients, 
  initialStaff, 
  initialInvoices, 
  initialPromotions, 
  initialGiftCards,
  initialBranches
} from '../data';

import { Booking, Service, Product, Client, Staff, Invoice, Promotion, GiftCard, Branch, ProviderRequest } from '../types';

import { 
  Calendar, 
  LayoutDashboard, 
  ShoppingBag, 
  Boxes, 
  Users, 
  Award, 
  Megaphone, 
  Gift, 
  BarChart3, 
  Settings as SettingsIcon, 
  LogOut, 
  Sparkles,
  Menu,
  X,
  Building2,
  CheckCircle,
  HelpCircle,
  BadgeAlert,
  Receipt,
  AlertTriangle,
  Lock
} from 'lucide-react';

interface ProviderDashboardProps {
  onLogout: () => void;
  providerData: {
    id?: string;
    username: string;
    storeName?: string;
    activity?: string;
    name?: string;
    email?: string;
    phone?: string;
    paymentStatus?: string;
    selectedPackage?: string;
    billingCycle?: string;
    trialDaysLeft?: number;
  } | null;
  providerRequests?: ProviderRequest[];
  onApproveProviderRequest?: (reqId: string) => void;
  onUpdateProviderSubscription?: (reqId: string, packageType: string, billingCycle: 'monthly' | 'yearly', amountPaid: string, paymentMethod: string) => void;
  onUpdateProviderPaymentStatus?: (reqId: string, newStatus: string) => void;
}

export default function ProviderDashboard({ 
  onLogout, 
  providerData,
  providerRequests = [],
  onApproveProviderRequest,
  onUpdateProviderSubscription,
  onUpdateProviderPaymentStatus
}: ProviderDashboardProps) {
  const { lang, toggleLanguage, t, dir, isAr, isEn } = useLanguage();
  const [activeTab, setActiveTab] = useState('dash');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Core App States (contained per provider session)
  const [bookings, setBookings] = useState<Booking[]>(initialBookings);
  const [services, setServices] = useState<Service[]>(initialServices);
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [clients, setClients] = useState<Client[]>(initialClients);
  const [staff, setStaff] = useState<Staff[]>(initialStaff);
  const [invoices, setInvoices] = useState<Invoice[]>(initialInvoices);
  const [promotions, setPromotions] = useState<Promotion[]>(initialPromotions);
  const [giftCards, setGiftCards] = useState<GiftCard[]>(initialGiftCards);

  // Branch Management States (Dynamically overrides to registered salon details if applicable)
  const [branches, setBranches] = useState<Branch[]>(() => {
    if (providerData?.storeName) {
      return [
        { 
          id: 'br-main', 
          nameAr: providerData.storeName, 
          nameEn: providerData.storeName, 
          cityAr: 'الفرع الرئيسي', 
          cityEn: 'Main Branch' 
        },
        { 
          id: 'br-sub', 
          nameAr: `${providerData.storeName} - فرع إضافي`, 
          nameEn: `${providerData.storeName} - Sub Branch`, 
          cityAr: 'جدة', 
          cityEn: 'Jeddah' 
        }
      ];
    }
    return initialBranches;
  });

  const [currentBranchId, setCurrentBranchId] = useState<string>(() => {
    if (providerData?.storeName) {
      return 'br-main';
    }
    return 'br-riyadh';
  });

  // Filtered lists based on current selected branch
  const branchBookings = bookings.filter(b => {
    if (providerData?.storeName) {
      return true; // show all for custom registered accounts
    }
    return (b.branchId || 'br-riyadh') === currentBranchId;
  });

  const branchProducts = products.filter(p => {
    if (providerData?.storeName) {
      return true;
    }
    return (p.branchId || 'br-riyadh') === currentBranchId;
  });

  const branchInvoices = invoices.filter(inv => {
    if (providerData?.storeName) {
      return true;
    }
    return (inv.branchId || 'br-riyadh') === currentBranchId;
  });

  const currentBranch = branches.find(b => b.id === currentBranchId) || branches[0];

  // Core Updators
  const handleAddBooking = (newBooking: Booking) => {
    const bookingWithBranch = { ...newBooking, branchId: currentBranchId };
    setBookings(prev => [bookingWithBranch, ...prev]);
    // Also increment bookingsToday for the assigned staff member
    setStaff(prev => prev.map(s => s.id === newBooking.staffId ? { ...s, bookingsToday: s.bookingsToday + 1 } : s));
  };

  const handleUpdateBookingStatus = (bookingId: string, status: 'pending' | 'confirmed' | 'attended' | 'cancelled') => {
    setBookings(prev => prev.map(b => b.id === bookingId ? { ...b, status } : b));
  };

  const handleUpdateBookingTime = (bookingId: string, time: string) => {
    setBookings(prev => prev.map(b => b.id === bookingId ? { ...b, time } : b));
  };

  const handleAddInvoice = (newInvoice: Invoice) => {
    const invoiceWithBranch = { ...newInvoice, branchId: currentBranchId };
    setInvoices(prev => [invoiceWithBranch, ...prev]);
    // Also increment visits count and award loyalty points
    setClients(prev => prev.map(c => {
      if (c.name === newInvoice.clientName) {
        const earnedPoints = Math.max(1, Math.floor(newInvoice.total / 10));
        return { 
          ...c, 
          visits: c.visits + 1,
          loyaltyPoints: (c.loyaltyPoints || 0) + earnedPoints
        };
      }
      return c;
    }));
  };

  const handleUpdateClientPoints = (clientId: string, newPoints: number) => {
    setClients(prev => prev.map(c => c.id === clientId ? { ...c, loyaltyPoints: newPoints } : c));
  };

  const handleUpdateProductStock = (productId: string, newStock: number) => {
    setProducts(prev => prev.map(p => p.id === productId ? { ...p, stock: newStock } : p));
  };

  const handleUpdateProductMinStock = (productId: string, newMinStock: number) => {
    setProducts(prev => prev.map(p => p.id === productId ? { ...p, minStock: newMinStock } : p));
  };

  const handleAddProduct = (newProduct: Product) => {
    const productWithBranch = { ...newProduct, branchId: currentBranchId };
    setProducts(prev => [productWithBranch, ...prev]);
  };

  const handleAddClient = (newClient: Client) => {
    setClients(prev => [newClient, ...prev]);
  };

  const handleUpdateClientNotes = (clientId: string, newNotes: string) => {
    setClients(prev => prev.map(c => c.id === clientId ? { ...c, notes: newNotes } : c));
  };

  const handleUpdateClient = (updatedClient: Client) => {
    setClients(prev => prev.map(c => c.id === updatedClient.id ? updatedClient : c));
  };

  const handleIncrementVisits = (clientId: string) => {
    setClients(prev => prev.map(c => c.id === clientId ? { ...c, visits: c.visits + 1 } : c));
  };

  const handleAddStaff = (newStaff: Staff) => {
    setStaff(prev => [newStaff, ...prev]);
  };

  const handleUpdateStaff = (updatedStaff: Staff) => {
    setStaff(prev => prev.map(s => s.id === updatedStaff.id ? updatedStaff : s));
  };

  const handleAddPromotion = (newPromo: Promotion) => {
    setPromotions(prev => [newPromo, ...prev]);
  };

  const handleTogglePromoStatus = (promoId: string) => {
    setPromotions(prev => prev.map(p => p.id === promoId ? { ...p, status: p.status === 'active' ? 'inactive' : 'active' } : p));
  };

  const handleAddGiftCard = (newCard: GiftCard) => {
    setGiftCards(prev => [newCard, ...prev]);
  };

  const handleToggleCardStatus = (cardId: string) => {
    setGiftCards(prev => prev.map(c => c.id === cardId ? { ...c, status: c.status === 'active' ? 'used' : 'active' } : c));
  };

  // Sidebar Tabs Config
  const sidebarTabs = [
    { id: 'dash', name: t('dash'), icon: LayoutDashboard },
    { id: 'book', name: t('book'), icon: Calendar },
    { id: 'pos', name: t('pos'), icon: ShoppingBag },
    { id: 'inv', name: t('inv'), icon: Boxes },
    { id: 'crm', name: t('crm'), icon: Users },
    { id: 'intel', name: isAr ? 'تحليل سلوك العميلات' : 'Customer Behavior (AI)', icon: Sparkles },
    { id: 'exp', name: isAr ? 'إدارة المصاريف اليومية' : 'Daily Expenses', icon: Receipt },
    { id: 'staff', name: t('staff'), icon: Award },
    { id: 'mkt', name: t('mkt'), icon: Megaphone },
    { id: 'gift', name: t('gift'), icon: Gift },
    { id: 'rep', name: t('rep'), icon: BarChart3 },
    { id: 'profile', name: isAr ? 'الملف التعريفي للمزود' : 'Provider Profile', icon: Building2 },
    { id: 'set', name: t('set'), icon: SettingsIcon },
  ];

  const currentTabName = sidebarTabs.find(t => t.id === activeTab)?.name || '';

  // Subscription check
  const isPaid = providerData?.paymentStatus === 'paid_verified';
  const isTrialActive = providerData?.paymentStatus === 'trial_active' && (providerData?.trialDaysLeft === undefined || providerData?.trialDaysLeft > 0);
  const [localPaymentComplete, setLocalPaymentComplete] = useState(false);

  if (!isPaid && !isTrialActive && !localPaymentComplete && providerData && providerData.username !== 'admin') {
    return (
      <SubscriptionPaymentGateway 
        providerData={providerData}
        initialPackage={providerData.selectedPackage || 'pro'}
        onPaymentSuccess={(packageType, billingCycle, amountPaid, paymentMethod) => {
          setLocalPaymentComplete(true);
          if (onUpdateProviderSubscription && providerData.id) {
            onUpdateProviderSubscription(providerData.id, packageType, billingCycle, amountPaid, paymentMethod);
          }
        }}
        onCancel={onLogout}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#F6F6F4] text-[#1C1B18] flex flex-col md:flex-row antialiased select-none font-sans" dir={dir}>
      
      {/* ===== MOBILE HEADER BAR ===== */}
      <header className="md:hidden bg-[#F8FAFC] border-b border-slate-200 px-5 py-4 flex items-center justify-between sticky top-0 z-40 w-full shrink-0">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2.5 rounded-xl bg-slate-200/60 hover:bg-slate-200 text-slate-700 transition-all cursor-pointer flex items-center justify-center shadow-xs"
            aria-label="Toggle Menu"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div>
            <span className="font-sans text-lg font-black text-slate-900 tracking-wider uppercase block leading-none">
              {providerData?.storeName || t('brandName')}
            </span>
            <span className="text-[9px] text-[#FF5A5F] uppercase font-bold block leading-none mt-1">
              {isAr ? 'لوحة تحكم الشركاء' : 'PARTNER DASHBOARD'}
            </span>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <button
            onClick={toggleLanguage}
            className="px-3 py-1.5 rounded-lg bg-slate-200/80 text-slate-700 text-xs font-bold hover:bg-slate-300 transition-all cursor-pointer"
          >
            {isAr ? 'EN' : 'AR'}
          </button>
        </div>
      </header>

      {/* Backdrop for mobile drawer */}
      {mobileMenuOpen && (
        <div 
          onClick={() => setMobileMenuOpen(false)}
          className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs z-40 md:hidden transition-all duration-300"
        />
      )}

      {/* ===== SIDEBAR ===== */}
      <aside className={`
        fixed md:static inset-y-0 top-0 z-50 w-64 bg-gradient-to-b from-[#F8FAFC] to-[#F1F5F9] text-slate-600 flex flex-col justify-between shrink-0 border-slate-200/80 transition-transform duration-300 shadow-2xl md:shadow-none
        ${isAr ? 'right-0 border-l md:border-l-2' : 'left-0 border-r md:border-r-2'}
        ${mobileMenuOpen ? 'translate-x-0' : (isAr ? 'translate-x-full md:translate-x-0' : '-translate-x-full md:translate-x-0')}
      `}>
        
        {/* Brand / Header */}
        <div>
          <div className="p-6 border-b border-slate-200 flex flex-col gap-3 relative">
            {/* Close Button on Mobile Drawer */}
            <button 
              onClick={() => setMobileMenuOpen(false)}
              className="md:hidden absolute top-4 left-4 p-1.5 rounded-lg bg-slate-200/50 hover:bg-slate-200 text-slate-700 cursor-pointer"
              title={isAr ? 'إغلاق' : 'Close'}
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center justify-between w-full">
              {/* High quality 3-dot professional logo */}
              <div className="flex gap-1.5 items-center">
                <span className="w-2.5 h-2.5 rounded-full bg-[#FF5A5F] shadow-sm animate-pulse" />
                <span className="w-2.5 h-2.5 rounded-full bg-[#14332B] shadow-sm" />
                <span className="w-2.5 h-2.5 rounded-full bg-[#FFAE34] shadow-sm" />
              </div>
              
              <button
                onClick={() => {
                  toggleLanguage();
                  setMobileMenuOpen(false);
                }}
                className="px-2.5 py-1.5 rounded-lg bg-slate-200/80 text-slate-700 text-[11px] font-bold hover:bg-slate-300 transition-all cursor-pointer"
                title={isAr ? 'English' : 'العربية'}
              >
                {isAr ? 'EN' : 'AR'}
              </button>
            </div>
            <div>
              <span className="font-serif text-lg font-black text-slate-900 tracking-tight block truncate">
                {providerData?.storeName || t('brandName')}
              </span>
              <span className="text-[9px] text-[#FF5A5F] uppercase font-bold block leading-none mt-1">
                {isAr ? 'بوابة تشغيل مزودي الخدمة' : 'Provider Cloud Portal'}
              </span>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="p-4 space-y-1 overflow-y-auto max-h-[calc(100vh-240px)]">
            {sidebarTabs.map(tab => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setActiveTab(tab.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold transition-all text-start ${
                    isActive 
                      ? 'bg-[#FF5A5F] text-white shadow-lg shadow-[#FF5A5F]/20' 
                      : 'hover:bg-slate-200/50 text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{tab.name}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Footer / Logout */}
        <div className="p-4 border-t border-slate-200 space-y-3">
          <div className="px-4 py-2.5 bg-[#FF5A5F]/5 rounded-xl text-[10px] space-y-1 border border-[#FF5A5F]/10">
            <p className="text-slate-800 font-bold truncate">👤 {providerData?.name || t('currentUser')}</p>
            <p className="text-slate-500 font-medium">📍 {isAr ? currentBranch.nameAr : currentBranch.nameEn}</p>
            <p className="text-emerald-700 font-bold text-[9px] uppercase font-mono tracking-wider flex items-center gap-1 mt-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              {isAr ? 'حساب نشط ومفعّل' : 'Active Account'}
            </p>
          </div>

          <button
            onClick={() => {
              onLogout();
              setMobileMenuOpen(false);
            }}
            className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-xs font-bold text-red-600 hover:bg-red-50 hover:text-red-700 transition-all text-start cursor-pointer"
          >
            <LogOut className="w-4 h-4 shrink-0" />
            <span>{t('logout')}</span>
          </button>
        </div>

      </aside>

      {/* ===== MAIN BODY ===== */}
      <main className="flex-1 p-5 md:p-10 max-w-7xl mx-auto w-full space-y-6 overflow-y-auto">
        
        {/* Trial Status Banner */}
        {providerData?.paymentStatus === 'trial_active' && (
          <div className="bg-amber-50 border border-amber-200 text-amber-800 p-4 rounded-xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 text-xs font-bold shadow-xs">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
              <div>
                <p>{isAr ? `تنبيه الحساب: يتبقى لكِ ${providerData.trialDaysLeft || 14} يوماً في الفترة التجريبية المجانية.` : `Trial Alert: You have ${providerData.trialDaysLeft || 14} days left in your free trial.`}</p>
                <p className="font-normal text-[10px] text-amber-700 mt-0.5">{isAr ? 'سيتم إيقاف حسابك تلقائياً فور انتهاء المدة ما لم يتم تفعيل قيمة الباقة من قبل إدارة الموقع.' : 'Your account will lock automatically unless subscription is approved by the site administration.'}</p>
              </div>
            </div>
            <button 
              onClick={() => {
                setLocalPaymentComplete(false);
                if (onUpdateProviderPaymentStatus && providerData.id) {
                  onUpdateProviderPaymentStatus(providerData.id, 'trial_expired');
                }
              }}
              className="px-3.5 py-1.5 bg-[#FF5A5F] hover:bg-[#ff4248] text-white rounded-lg transition-all cursor-pointer shadow-xs text-[10px] shrink-0"
            >
              {isAr ? 'ترقية وتفعيل الحساب الآن' : 'Upgrade & Activate Now'}
            </button>
          </div>
        )}

        {/* Breadcrumbs, Title & Dynamic Branch Selector */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-[#E9E7E2]">
          <div>
            <span className="text-xs font-bold text-[#6E6A63]">{providerData?.storeName || t('brandName')} / {t('dash')}</span>
            <h1 className="font-serif text-2xl md:text-3xl font-bold text-slate-900 mt-1">{currentTabName}</h1>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Business Status */}
            <div className="text-xs text-[#6E6A63] font-medium px-3 py-1.5 bg-[#F6F6F4] rounded-xl border border-[#E9E7E2] select-none flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>{isAr ? 'مفتوح للعمل · تشفير سحابي آمن' : 'Open for Business · Secure Encrypted Session'}</span>
            </div>

            {/* Quick Manual Lock Screen Action */}
            <button
              onClick={() => {
                window.dispatchEvent(new CustomEvent('request-lock'));
              }}
              title={isAr ? 'قفل الشاشة السيبرانية يدوياً لحماية السجل (Ctrl + L)' : 'Lock terminal screen manually to secure records (Ctrl + L)'}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-red-50 hover:bg-red-100 border border-red-200 text-red-600 hover:text-red-700 rounded-xl text-xs font-bold transition-all cursor-pointer shadow-xs"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>{isAr ? 'قفل المحطة 🔒' : 'Lock POS 🔒'}</span>
            </button>

            {/* Premium Branch Switching select element */}
            <div className="flex items-center gap-2 bg-white border border-[#E9E7E2] rounded-xl px-3 py-1.5 shadow-xs transition-all hover:border-[#FF5A5F]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#FF5A5F] animate-ping" />
              <select
                value={currentBranchId}
                onChange={(e) => setCurrentBranchId(e.target.value)}
                className="bg-transparent border-none text-xs font-bold text-[#14332B] focus:outline-none cursor-pointer pr-1"
              >
                {branches.map(b => (
                  <option key={b.id} value={b.id} className="text-[#1C1B18] font-medium bg-white">
                    {isAr ? b.nameAr : b.nameEn}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* ===== SWITCH ACTIVE VIEW ===== */}
        {activeTab === 'dash' && (
          <DashboardOverview 
            bookings={branchBookings}
            products={branchProducts}
            invoices={branchInvoices}
            clientsCount={clients.length}
            onNavigate={(page) => setActiveTab(page)}
            staffList={staff}
          />
        )}

        {activeTab === 'book' && (
          <BookingsManager 
            bookings={branchBookings}
            services={services}
            staffList={staff}
            onAddBooking={handleAddBooking}
            onUpdateStatus={handleUpdateBookingStatus}
            onUpdateBookingTime={handleUpdateBookingTime}
          />
        )}

        {activeTab === 'pos' && (
          <POSManager 
            services={services}
            products={branchProducts}
            invoices={branchInvoices}
            onAddInvoice={handleAddInvoice}
            onUpdateProductStock={handleUpdateProductStock}
            currentBranch={currentBranch}
          />
        )}

        {activeTab === 'inv' && (
          <InventoryManager 
            products={branchProducts}
            onAddProduct={handleAddProduct}
            onUpdateStock={handleUpdateProductStock}
            onUpdateMinStock={handleUpdateProductMinStock}
          />
        )}

        {activeTab === 'crm' && (
          <CRMManager 
            clients={clients}
            onAddClient={handleAddClient}
            onUpdateClientNotes={handleUpdateClientNotes}
            onIncrementVisits={handleIncrementVisits}
            onUpdateClientPoints={handleUpdateClientPoints}
            onUpdateClient={handleUpdateClient}
          />
        )}

        {activeTab === 'intel' && (
          <CustomerIntelligence />
        )}

        {activeTab === 'exp' && (
          <ExpensesManager currentBranchId={currentBranchId} />
        )}

        {activeTab === 'staff' && (
          <StaffManager 
            staffList={staff}
            onAddStaff={handleAddStaff}
            onUpdateStaff={handleUpdateStaff}
          />
        )}

        {activeTab === 'mkt' && (
          <MarketingManager 
            promotions={promotions}
            onAddPromotion={handleAddPromotion}
            onTogglePromoStatus={handleTogglePromoStatus}
          />
        )}

        {activeTab === 'gift' && (
          <GiftCardsManager 
            giftCards={giftCards}
            onAddGiftCard={handleAddGiftCard}
            onToggleCardStatus={handleToggleCardStatus}
          />
        )}

        {activeTab === 'rep' && (
          <ReportsManager 
            bookings={branchBookings}
            invoices={branchInvoices}
            staffList={staff}
            services={services}
          />
        )}

        {activeTab === 'profile' && (
          <ProviderProfileManager initialData={providerData} />
        )}

        {activeTab === 'set' && (
          <SettingsManager />
        )}

        <footer className="mt-12 pt-6 border-t border-[#E9E7E2] flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-[#6E6A63]">
          <span>© {isAr ? 'CONFIRMED ٢٠٢٦ — جميع الحقوق محفوظة لشركاء كُونفيرمد.' : 'CONFIRMED 2026 — All rights reserved to Confirmed Partners.'}</span>
          <span className="font-bold tracking-wider text-[#FF5A5F]">{t('byAhmed')}</span>
          <span>{t('brandDesc')}</span>
        </footer>

      </main>

    </div>
  );
}
