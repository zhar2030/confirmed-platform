import React, { useState } from 'react';
import { Booking, Product, Invoice, Staff } from '../types';
import { Calendar, DollarSign, Users, AlertTriangle, ArrowLeftRight, CheckCircle2, ShoppingBag, Award, Sparkles, Star, Crown, ChevronDown, ChevronUp } from 'lucide-react';
import { useLanguage } from '../LanguageContext';

interface DashboardOverviewProps {
  bookings: Booking[];
  products: Product[];
  invoices: Invoice[];
  clientsCount: number;
  onNavigate: (page: string) => void;
  staffList: Staff[];
}

export default function DashboardOverview({ bookings, products, invoices, clientsCount, onNavigate, staffList }: DashboardOverviewProps) {
  const { t, isAr } = useLanguage();

  // Calculations
  const todayDateStr = '2026-07-18';
  const todayBookings = bookings.filter(b => b.date === todayDateStr);
  
  const todayInvoices = invoices.filter(inv => inv.date === todayDateStr);
  const todaySales = todayInvoices.reduce((sum, inv) => sum + inv.total, 0);

  const lowStockProducts = products.filter(p => p.stock <= p.minStock);

  // Daily Schedule List
  const displayBookings = todayBookings.slice(0, 4);

  // Sales of last 7 days mockup
  const last7DaysData = isAr ? [
    { day: 'سبت', amount: 980, isToday: false },
    { day: 'أحد', amount: 1240, isToday: false },
    { day: 'اثنين', amount: 760, isToday: false },
    { day: 'ثلاثاء', amount: 1510, isToday: true },
    { day: 'أربعاء', amount: 890, isToday: false },
    { day: 'خميس', amount: 1050, isToday: false },
    { day: 'جمعة', amount: todaySales > 0 ? Math.round(todaySales) : 1280, isToday: false },
  ] : [
    { day: 'Sat', amount: 980, isToday: false },
    { day: 'Sun', amount: 1240, isToday: false },
    { day: 'Mon', amount: 760, isToday: false },
    { day: 'Tue', amount: 1510, isToday: true },
    { day: 'Wed', amount: 890, isToday: false },
    { day: 'Thu', amount: 1050, isToday: false },
    { day: 'Fri', amount: todaySales > 0 ? Math.round(todaySales) : 1280, isToday: false },
  ];

  const maxAmount = Math.max(...last7DaysData.map(d => d.amount));

  // Static translations helpers for items
  const getServiceName = (id: string) => {
    switch(id) {
      case 's1': return isAr ? 'قص وسشوار' : 'Haircut & Blowdry';
      case 's2': return isAr ? 'صبغة كاملة' : 'Full Hair Dye';
      case 's3': return isAr ? 'علاج بروتين شعر' : 'Hair Protein Treatment';
      case 's4': return isAr ? 'جلسة سبا 90 دقيقة' : '90 Min Spa Session';
      case 's5': return isAr ? 'عناية بالأظافر (مانيكير)' : 'Nail Care (Manicure)';
      case 's6': return isAr ? 'تنظيف بشرة عميق' : 'Deep Facial Cleanse';
      case 's7': return isAr ? 'مكياج سهرة كامل' : 'Full Evening Makeup';
      default: return isAr ? 'جلسة العناية' : 'Beauty Session';
    }
  };

  const getStaffName = (id: string) => {
    switch(id) {
      case 'e1': return isAr ? 'أمل' : 'Amal';
      case 'e2': return isAr ? 'دلال' : 'Dalal';
      case 'e3': return isAr ? 'شهد' : 'Shahad';
      case 'e4': return isAr ? 'جواهر' : 'Jawahir';
      default: return id;
    }
  };

  // Interactive State for Top Employees
  const [employeeTimeFilter, setEmployeeTimeFilter] = useState<'completed' | 'today'>('completed');
  const [selectedStaffDetail, setSelectedStaffDetail] = useState<string | null>(null);

  // Top Staff calculation
  const topStaff = (staffList || []).map(member => {
    // Count live completed (attended) bookings
    const liveCompleted = bookings.filter(b => b.staffId === member.id && b.status === 'attended').length;
    // Count live total bookings
    const liveTotal = bookings.filter(b => b.staffId === member.id).length;
    
    // Historical base completed bookings
    const baseCompleted = member.id === 'e3' ? 48 : member.id === 'e1' ? 42 : member.id === 'e2' ? 35 : 29;
    
    // If today is selected, filter by today + attended.
    // If completed is selected, show historical + live attended.
    const completedCount = employeeTimeFilter === 'today' 
      ? bookings.filter(b => b.staffId === member.id && b.date === todayDateStr && b.status === 'attended').length
      : baseCompleted + liveCompleted;

    const totalCount = employeeTimeFilter === 'today'
      ? bookings.filter(b => b.staffId === member.id && b.date === todayDateStr).length
      : baseCompleted + liveTotal + 5;

    // Success rate
    const successRate = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 100;

    return {
      ...member,
      completedCount,
      totalCount,
      successRate
    };
  }).sort((a, b) => b.completedCount - a.completedCount).slice(0, 3);

  const maxCompleted = topStaff.length > 0 ? topStaff[0].completedCount : 1;

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* ===== STATS CARDS ===== */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* Card 1 */}
        <div className="bg-white border border-[#E9E7E2] rounded-2xl p-5 shadow-sm hover:shadow-md transition-all">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-bold text-[#6E6A63] uppercase">{t('todayBookings')}</p>
              <h4 className="text-3xl font-serif font-bold text-[#14332B] mt-2">{todayBookings.length}</h4>
            </div>
            <div className="p-3 rounded-xl bg-[#FFF0F0] text-[#FF5A5F]">
              <Calendar className="w-5 h-5" />
            </div>
          </div>
          <p className="text-xs text-emerald-600 font-medium mt-3 flex items-center gap-1">
            <span>{bookings.filter(b => b.status === 'confirmed').length} {t('confirmed')}</span>
          </p>
        </div>

        {/* Card 2 */}
        <div className="bg-white border border-[#E9E7E2] rounded-2xl p-5 shadow-sm hover:shadow-md transition-all">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-bold text-[#6E6A63] uppercase">{t('todaySales')}</p>
              <h4 className="text-3xl font-serif font-bold text-[#14332B] mt-2">
                {todaySales.toLocaleString()} <span className="text-xs font-sans">{t('currency')}</span>
              </h4>
            </div>
            <div className="p-3 rounded-xl bg-emerald-50 text-emerald-700">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <p className="text-xs text-emerald-600 font-medium mt-3">
            {isAr ? `من واقع ${todayInvoices.length} فواتير إلكترونية` : `Based on ${todayInvoices.length} e-invoices`}
          </p>
        </div>

        {/* Card 3 */}
        <div className="bg-white border border-[#E9E7E2] rounded-2xl p-5 shadow-sm hover:shadow-md transition-all">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-bold text-[#6E6A63] uppercase">{t('registeredClients')}</p>
              <h4 className="text-3xl font-serif font-bold text-[#14332B] mt-2">{clientsCount}</h4>
            </div>
            <div className="p-3 rounded-xl bg-amber-50 text-amber-700">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <p className="text-xs text-emerald-600 font-medium mt-3">
            {t('registeredInBranch')}
          </p>
        </div>

        {/* Card 4 */}
        <div className="bg-white border border-[#E9E7E2] rounded-2xl p-5 shadow-sm hover:shadow-md transition-all">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-bold text-[#6E6A63] uppercase">{t('stockAlerts')}</p>
              <h4 className="text-3xl font-serif font-bold text-[#14332B] mt-2">{lowStockProducts.length}</h4>
            </div>
            <div className={`p-3 rounded-xl ${lowStockProducts.length > 0 ? 'bg-red-50 text-red-700' : 'bg-emerald-50 text-emerald-700'}`}>
              <AlertTriangle className="w-5 h-5" />
            </div>
          </div>
          <p className={`text-xs font-medium mt-3 ${lowStockProducts.length > 0 ? 'text-red-600' : 'text-emerald-600'}`}>
            {lowStockProducts.length > 0 ? t('stockWarning') : t('stockNormal')}
          </p>
        </div>
      </div>

      {/* ===== WORKSPACE GRID ===== */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Schedule list */}
        <div className="lg:col-span-7 bg-white border border-[#E9E7E2] rounded-2xl p-6 shadow-sm">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h3 className="font-serif text-lg font-bold text-[#14332B]">{t('todaySchedule')}</h3>
              <p className="text-xs text-[#6E6A63]">{isAr ? 'الثلاثاء، ١٤ ذو الحجة ١٤٤٧' : 'Tuesday, 14 Dhu al-Hijjah 1447'}</p>
            </div>
            <button 
              onClick={() => onNavigate('book')}
              className="text-xs font-bold bg-[#FF5A5F] hover:bg-[#E04B50] text-white px-3.5 py-2 rounded-xl transition-colors"
            >
              {t('allBookings')}
            </button>
          </div>

          <div className="space-y-3">
            {displayBookings.length === 0 ? (
              <div className="text-center py-8 text-[#6E6A63] text-sm">
                {isAr ? 'لا توجد حجوزات مسجلة اليوم بعد.' : 'No bookings registered for today yet.'}
              </div>
            ) : (
              displayBookings.map((b) => (
                <div key={b.id} className="flex items-center gap-4 p-4 rounded-xl bg-[#F6F6F4] border border-[#E9E7E2] hover:bg-[#FFF0F0]/30 transition-all">
                  <span className="text-sm font-bold text-[#FF5A5F] min-w-[56px] font-mono">{b.time}</span>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <b className="text-sm text-[#1C1B18]">{b.clientName}</b>
                      <span className="text-[10px] text-[#6E6A63]">{b.clientPhone}</span>
                    </div>
                    <p className="text-xs text-[#6E6A63] mt-0.5">
                      {isAr ? 'الخدمة' : 'Service'}: {getServiceName(b.serviceId)} · {isAr ? 'الموظفة' : 'Staff'}: {getStaffName(b.staffId)}
                    </p>
                  </div>
                  <span 
                    className={`text-xs font-semibold px-2.5 py-1 rounded-full ${
                      b.status === 'attended' 
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' 
                        : b.status === 'confirmed'
                        ? 'bg-rose-50 text-rose-700 border border-rose-100'
                        : 'bg-amber-50 text-amber-700 border border-amber-100'
                    }`}
                  >
                    {b.status === 'attended' ? t('attended') : b.status === 'confirmed' ? t('confirmed') : t('pending')}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right: Charts and low stock alerts */}
        <div className="lg:col-span-5 flex flex-col gap-6">
          {/* Chart Card */}
          <div className="bg-white border border-[#E9E7E2] rounded-2xl p-6 shadow-sm">
            <h3 className="font-serif text-base font-bold text-[#14332B] mb-6">{t('salesLast7Days')}</h3>
            <div className="flex items-end justify-between gap-2 h-36 pt-2">
              {last7DaysData.map((d, idx) => {
                const heightPercentage = Math.round((d.amount / maxAmount) * 100);
                return (
                  <div key={idx} className="flex-1 flex flex-col items-center gap-2 h-full justify-end">
                    <span className="text-[10px] font-bold text-[#FF5A5F] font-mono">{d.amount}</span>
                    <div 
                      style={{ height: `${heightPercentage}%` }} 
                      className={`w-full max-w-[28px] rounded-t-md transition-all duration-500 ${
                        d.isToday ? 'bg-[#FF5A5F] shadow-md shadow-[#FF5A5F]/30' : 'bg-[#14332B]'
                      }`}
                    />
                    <span className="text-xs text-[#6E6A63] font-medium">{d.day}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Top Performers Card */}
          <div className="bg-white border border-[#E9E7E2] rounded-2xl p-6 shadow-sm space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-[#F6F6F4]">
              <div className="flex items-center gap-2">
                <Crown className="w-5 h-5 text-[#FFAE34] animate-bounce" />
                <h3 className="font-serif text-base font-bold text-[#14332B]">
                  {isAr ? 'أفضل الموظفات أداءً' : 'Top Performing Staff'}
                </h3>
              </div>
              
              {/* Interactive Toggle Button */}
              <div className="flex bg-[#F6F6F4] p-1 rounded-xl border border-[#E9E7E2]">
                <button
                  onClick={() => setEmployeeTimeFilter('completed')}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all border-none cursor-pointer ${
                    employeeTimeFilter === 'completed'
                      ? 'bg-[#FF5A5F] text-white shadow-sm'
                      : 'text-[#6E6A63] hover:text-[#1C1B18]'
                  }`}
                >
                  {isAr ? 'تراكمي' : 'All-Time'}
                </button>
                <button
                  onClick={() => setEmployeeTimeFilter('today')}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all border-none cursor-pointer ${
                    employeeTimeFilter === 'today'
                      ? 'bg-[#FF5A5F] text-white shadow-sm'
                      : 'text-[#6E6A63] hover:text-[#1C1B18]'
                  }`}
                >
                  {isAr ? 'اليوم' : 'Today'}
                </button>
              </div>
            </div>

            <div className="space-y-3">
              {topStaff.map((staffMember, index) => {
                const rankColors = [
                  { bg: 'bg-[#FFF9E6]', border: 'border-[#FFAE34]/30', text: 'text-[#FFAE34]', rankLabel: '🥇' },
                  { bg: 'bg-slate-50', border: 'border-slate-300/30', text: 'text-slate-500', rankLabel: '🥈' },
                  { bg: 'bg-amber-50/50', border: 'border-amber-700/10', text: 'text-amber-700/80', rankLabel: '🥉' }
                ];
                const rank = rankColors[index] || { bg: 'bg-slate-50', border: 'border-slate-200', text: 'text-slate-500', rankLabel: '•' };
                const isExpanded = selectedStaffDetail === staffMember.id;
                const percentage = Math.round((staffMember.completedCount / maxCompleted) * 100) || 0;

                return (
                  <div 
                    key={staffMember.id}
                    className={`border rounded-xl transition-all duration-300 overflow-hidden ${
                      isExpanded 
                        ? 'border-[#FF5A5F] bg-[#FFF0F0]/10 shadow-sm' 
                        : 'border-[#E9E7E2] hover:border-[#FF5A5F]/50 hover:bg-slate-50/40'
                    }`}
                  >
                    {/* Main Row clickable to toggle detail */}
                    <div 
                      onClick={() => setSelectedStaffDetail(isExpanded ? null : staffMember.id)}
                      className="p-3 flex items-center justify-between gap-3 cursor-pointer select-none"
                    >
                      <div className="flex items-center gap-3">
                        {/* Rank Badge */}
                        <div className={`w-8 h-8 rounded-xl ${rank.bg} ${rank.border} border flex items-center justify-center font-bold text-sm ${rank.text}`}>
                          {rank.rankLabel}
                        </div>
                        
                        <div>
                          <b className="text-xs text-slate-800 block">{getStaffName(staffMember.id)}</b>
                          <span className="text-[10px] text-slate-500 block">{staffMember.role}</span>
                        </div>
                      </div>

                      <div className="text-right flex items-center gap-2">
                        <div className="space-y-0.5">
                          <span className="text-xs font-mono font-bold text-[#FF5A5F] block">
                            {staffMember.completedCount} {isAr ? 'مكتمل' : 'Completed'}
                          </span>
                          <span className="text-[9px] text-slate-400 block font-mono">
                            {isAr ? 'معدل الرضا' : 'Satisfaction'} {staffMember.successRate}%
                          </span>
                        </div>
                        {isExpanded ? (
                          <ChevronUp className="w-4 h-4 text-[#FF5A5F]" />
                        ) : (
                          <ChevronDown className="w-4 h-4 text-slate-400" />
                        )}
                      </div>
                    </div>

                    {/* Animated custom interactive progress bar */}
                    <div className="px-3 pb-2.5">
                      <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                        <div 
                          style={{ width: `${percentage}%` }}
                          className="bg-gradient-to-r from-[#FF5A5F] to-[#FFAE34] h-full rounded-full transition-all duration-500"
                        />
                      </div>
                    </div>

                    {/* Interactive Expanded Detail Card */}
                    {isExpanded && (
                      <div className="px-4 pb-4 pt-1 border-t border-[#E9E7E2]/60 bg-white/60 text-[11px] text-slate-600 space-y-2 animate-fadeIn">
                        <div className="flex justify-between items-center">
                          <span className="font-semibold text-slate-700">
                            {isAr ? '🏆 الإنجاز والمستوى:' : '🏆 Achievement Level:'}
                          </span>
                          <span className="text-xs font-bold text-[#FF5A5F] bg-[#FFF0F0] px-2 py-0.5 rounded-full">
                            {index === 0 
                              ? (isAr ? 'نجمة الشهر الأولى 👑' : 'Top Performer of the Month 👑')
                              : index === 1 
                              ? (isAr ? 'أداء ممتاز دائم 🌟' : 'Consistently Excellent 🌟')
                              : (isAr ? 'متميزة وواعدة ✨' : 'Talented & Rising Star ✨')}
                          </span>
                        </div>
                        
                        <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200/50 space-y-1">
                          <p className="text-slate-500 leading-normal">
                            {index === 0 
                              ? (isAr ? 'أظهرت أداءً مذهلاً هذا الشهر وحققت أعلى نسبة رضا لدى عميلات صالون كونفيرمد التجميلي بفضل دقتّها واحترافيتها العالية.' : 'Demonstrated incredible performance this month with the highest customer satisfaction score at CONFIRMED Salon.')
                              : index === 1
                              ? (isAr ? 'تتميز بالتزامها العالي ودقّة مواعيدها، وتحظى بتقييمات رائعة وتكرار حجوزات ممتاز من العميلات.' : 'Distinguished by high commitment and absolute punctuality, with consistent repeat bookings.')
                              : (isAr ? 'طاقة إيجابية رائعة وسرعة استثنائية في تقديم الخدمات مع الحفاظ على أعلى معايير الجودة والراحة.' : 'Amazing energy and exceptional service delivery speed while maintaining comfort and pristine quality.')}
                          </p>
                        </div>

                        <div className="grid grid-cols-3 gap-2 text-center text-[10px]">
                          <div className="bg-[#FFF0F0] p-1.5 rounded-lg border border-[#FF5A5F]/10">
                            <span className="text-[#FF5A5F] font-bold block text-sm font-mono">{staffMember.completedCount}</span>
                            <span className="text-slate-500">{isAr ? 'مكتملة' : 'Completed'}</span>
                          </div>
                          <div className="bg-rose-50/50 p-1.5 rounded-lg border border-rose-200/40">
                            <span className="text-rose-700 font-bold block text-sm font-mono">{staffMember.totalCount}</span>
                            <span className="text-slate-500">{isAr ? 'إجمالي' : 'Total'}</span>
                          </div>
                          <div className="bg-emerald-50/50 p-1.5 rounded-lg border border-emerald-200/40">
                            <span className="text-emerald-700 font-bold block text-sm font-mono">{staffMember.successRate}%</span>
                            <span className="text-slate-500">{isAr ? 'معدل الرضا' : 'Satisfaction'}</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Low Stock Card */}
          <div className="bg-white border border-[#E9E7E2] rounded-2xl p-6 shadow-sm">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-serif text-sm font-bold text-[#14332B]">⚠️ {t('lowStockLabel')}</h3>
              <button 
                onClick={() => onNavigate('inv')}
                className="text-xs font-bold text-[#FF5A5F] hover:underline"
              >
                {t('updateStock')}
              </button>
            </div>

            <div className="space-y-2">
              {lowStockProducts.length === 0 ? (
                <div className="text-xs text-emerald-600 bg-emerald-50 p-2.5 rounded-xl border border-emerald-100">
                  {isAr ? 'لا توجد منتجات منخفضة المخزون حالياً ✓' : 'No low stock products currently ✓'}
                </div>
              ) : (
                lowStockProducts.map(p => (
                  <div key={p.id} className="flex justify-between items-center py-2 border-b border-[#F6F6F4] text-sm">
                    <span className="font-medium text-[#1C1B18]">{p.name}</span>
                    <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-red-50 text-red-700 border border-red-100">
                      {isAr ? `متبقي ${p.stock} فقط (الحد ${p.minStock})` : `${p.stock} left (Min ${p.minStock})`}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
