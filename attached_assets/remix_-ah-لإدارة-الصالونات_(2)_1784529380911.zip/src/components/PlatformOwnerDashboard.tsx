import React, { useState, useEffect } from 'react';
import { 
  Building, 
  Users, 
  Megaphone, 
  ShieldCheck, 
  ShieldAlert, 
  Plus, 
  UserPlus, 
  Mail, 
  Phone, 
  Lock, 
  Unlock, 
  Trash2, 
  Sparkles, 
  Check, 
  Send, 
  Bell, 
  Search, 
  Activity, 
  Smartphone, 
  Clock, 
  Layers, 
  LogOut,
  Sliders,
  Database,
  Briefcase,
  ExternalLink,
  DollarSign,
  TrendingUp,
  CreditCard,
  ArrowUpRight,
  SlidersHorizontal,
  Filter,
  CheckCircle2,
  AlertTriangle,
  FileText,
  RefreshCw,
  Download
} from 'lucide-react';
import { useLanguage } from '../LanguageContext';
import { SubscriptionPackage } from '../types';

interface ProviderRequest {
  id: string;
  name: string;
  phone: string;
  email: string;
  storeName: string;
  activity: string;
  status: 'pending' | 'approved';
  requestedAt: string;
  selectedPackage?: string;
  billingCycle?: string;
  amountPaid?: string;
  paymentMethod?: string;
  paymentStatus?: string;
}

interface PlatformEmployee {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'senior_admin' | 'ops_supervisor' | 'marketing_spec' | 'tech_support';
  joinedAt: string;
  permissions: string[];
  status: 'active' | 'suspended';
}

interface RegisteredProvider {
  id: string;
  storeName: string;
  ownerName: string;
  phone: string;
  email: string;
  activity: string;
  status: 'active' | 'suspended';
  joinedAt: string;
  subdomain: string;
  totalSales: number;
  paidOut: number;
  pendingPayout: number;
  subscriptionTier: 'starter' | 'pro' | 'enterprise';
  subscriptionPrice: number;
  subscriptionStatus: 'active' | 'overdue' | 'trial';
  staffCount: number;
  bookingsCount: number;
  rating: number;
}

interface PlatformOwnerDashboardProps {
  providerRequests: ProviderRequest[];
  onApproveRequest: (id: string) => void;
  onLogout: () => void;
  onActivateProviderSubscription?: (reqId: string) => void;
  packages: SubscriptionPackage[];
  onAddPackage: (newPkg: SubscriptionPackage) => void;
  onUpdatePackage: (updatedPkg: SubscriptionPackage) => void;
  onDeletePackage: (id: string) => void;
}

export default function PlatformOwnerDashboard({ 
  providerRequests, 
  onApproveRequest, 
  onLogout,
  onActivateProviderSubscription,
  packages,
  onAddPackage,
  onUpdatePackage,
  onDeletePackage
}: PlatformOwnerDashboardProps) {
  const { isAr, t, dir } = useLanguage();
  const [activeSubTab, setActiveSubTab] = useState<'stats' | 'providers' | 'financials' | 'employees' | 'broadcast' | 'packages'>('stats');
  const [selectedProfileProvider, setSelectedProfileProvider] = useState<RegisteredProvider | null>(null);
  
  // Search state
  const [providerSearch, setProviderSearch] = useState('');
  const [employeeSearch, setEmployeeSearch] = useState('');

  // Subscription Packages States
  const [showPackageModal, setShowPackageModal] = useState(false);
  const [editingPackage, setEditingPackage] = useState<SubscriptionPackage | null>(null);
  
  const [pkgNameAr, setPkgNameAr] = useState('');
  const [pkgNameEn, setPkgNameEn] = useState('');
  const [pkgDescAr, setPkgDescAr] = useState('');
  const [pkgDescEn, setPkgDescEn] = useState('');
  const [pkgPriceMonthly, setPkgPriceMonthly] = useState(149);
  const [pkgPriceYearly, setPkgPriceYearly] = useState(119);
  const [pkgIsPopular, setPkgIsPopular] = useState(false);
  const [pkgIsEnterprise, setPkgIsEnterprise] = useState(false);
  const [pkgFeatures, setPkgFeatures] = useState<{ ar: string; en: string }[]>([{ ar: '', en: '' }]);

  const handleOpenAddPackage = () => {
    setEditingPackage(null);
    setPkgNameAr('');
    setPkgNameEn('');
    setPkgDescAr('');
    setPkgDescEn('');
    setPkgPriceMonthly(149);
    setPkgPriceYearly(119);
    setPkgIsPopular(false);
    setPkgIsEnterprise(false);
    setPkgFeatures([{ ar: '', en: '' }]);
    setShowPackageModal(true);
  };

  const handleOpenEditPackage = (pkg: SubscriptionPackage) => {
    setEditingPackage(pkg);
    setPkgNameAr(pkg.nameAr);
    setPkgNameEn(pkg.nameEn);
    setPkgDescAr(pkg.descriptionAr);
    setPkgDescEn(pkg.descriptionEn);
    setPkgPriceMonthly(pkg.priceMonthly);
    setPkgPriceYearly(pkg.priceYearly);
    setPkgIsPopular(!!pkg.isPopular);
    setPkgIsEnterprise(!!pkg.isEnterpriseContact);
    
    // Zip features back to objects
    const zipped: { ar: string; en: string }[] = [];
    const maxLen = Math.max(pkg.featuresAr?.length || 0, pkg.featuresEn?.length || 0);
    for (let i = 0; i < maxLen; i++) {
      zipped.push({
        ar: pkg.featuresAr?.[i] || '',
        en: pkg.featuresEn?.[i] || ''
      });
    }
    setPkgFeatures(zipped.length > 0 ? zipped : [{ ar: '', en: '' }]);
    setShowPackageModal(true);
  };

  const handleAddFeatureInput = () => {
    setPkgFeatures(prev => [...prev, { ar: '', en: '' }]);
  };

  const handleRemoveFeatureInput = (index: number) => {
    setPkgFeatures(prev => prev.filter((_, i) => i !== index));
  };

  const handleFeatureInputChange = (index: number, lang: 'ar' | 'en', val: string) => {
    setPkgFeatures(prev => prev.map((item, i) => i === index ? { ...item, [lang]: val } : item));
  };

  const handleSavePackage = (e: React.FormEvent) => {
    e.preventDefault();
    
    const preparedPkg: SubscriptionPackage = {
      id: editingPackage ? editingPackage.id : 'pkg_' + Date.now().toString(),
      nameAr: pkgNameAr,
      nameEn: pkgNameEn,
      descriptionAr: pkgDescAr,
      descriptionEn: pkgDescEn,
      priceMonthly: pkgIsEnterprise ? 0 : pkgPriceMonthly,
      priceYearly: pkgIsEnterprise ? 0 : pkgPriceYearly,
      featuresAr: pkgFeatures.map(f => f.ar.trim()).filter(Boolean),
      featuresEn: pkgFeatures.map(f => f.en.trim()).filter(Boolean),
      isPopular: pkgIsPopular,
      isEnterpriseContact: pkgIsEnterprise
    };

    if (editingPackage) {
      onUpdatePackage(preparedPkg);
    } else {
      onAddPackage(preparedPkg);
    }

    setShowPackageModal(false);
    setEditingPackage(null);
  };

  // 1. Registered Providers State
  const [registeredProviders, setRegisteredProviders] = useState<RegisteredProvider[]>(() => {
    const saved = localStorage.getItem('confirmed_registered_providers') || localStorage.getItem('refah_registered_providers');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed.map((prov: any) => ({
            ...prov,
            totalSales: typeof prov.totalSales === 'number' ? prov.totalSales : 0,
            paidOut: typeof prov.paidOut === 'number' ? prov.paidOut : 0,
            pendingPayout: typeof prov.pendingPayout === 'number' ? prov.pendingPayout : 0,
            subscriptionTier: prov.subscriptionTier || 'starter',
            subscriptionPrice: typeof prov.subscriptionPrice === 'number' ? prov.subscriptionPrice : 399,
            subscriptionStatus: prov.subscriptionStatus || 'active',
            staffCount: typeof prov.staffCount === 'number' ? prov.staffCount : 3,
            bookingsCount: typeof prov.bookingsCount === 'number' ? prov.bookingsCount : 0,
            rating: typeof prov.rating === 'number' ? prov.rating : 5.0
          }));
        }
      } catch (e) {
        console.error('Error parsing registered providers', e);
      }
    }
    return [
      {
        id: 'prov-1',
        storeName: isAr ? 'صالون عهود بيوتي لاونج' : 'Ohood Beauty Lounge',
        ownerName: isAr ? 'عهود الشلوي' : 'Ohood Al-Shalawi',
        phone: '0550112233',
        email: 'ohood@beauty.sa',
        activity: isAr ? 'صالون شعر وتجميل' : 'Full Beauty Salon',
        status: 'active',
        joinedAt: '2026-05-12T10:00:00Z',
        subdomain: 'ohood-lounge',
        totalSales: 84320,
        paidOut: 75888,
        pendingPayout: 8432,
        subscriptionTier: 'enterprise',
        subscriptionPrice: 1499,
        subscriptionStatus: 'active',
        staffCount: 14,
        bookingsCount: 284,
        rating: 4.9
      },
      {
        id: 'prov-2',
        storeName: isAr ? 'مركز تالة سبا النسائي' : 'Tala Spa & Wellness',
        ownerName: isAr ? 'منى القحطاني' : 'Mona Al-Qahtani',
        phone: '0550334455',
        email: 'mona@talaspa.sa',
        activity: isAr ? 'مركز سبا ومساج' : 'Spa & Wellness Center',
        status: 'active',
        joinedAt: '2026-06-01T14:30:00Z',
        subdomain: 'tala-spa',
        totalSales: 112450,
        paidOut: 101205,
        pendingPayout: 11245,
        subscriptionTier: 'pro',
        subscriptionPrice: 799,
        subscriptionStatus: 'active',
        staffCount: 19,
        bookingsCount: 412,
        rating: 4.8
      },
      {
        id: 'prov-3',
        storeName: isAr ? 'صالون نورة للتجميل والعناية' : 'Noura Salon & Care',
        ownerName: isAr ? 'نورة الفهيد' : 'Noura Al-Faheed',
        phone: '0550667788',
        email: 'noura@saloncare.sa',
        activity: isAr ? 'صالون شعر وتجميل' : 'Hair & Nail Salon',
        status: 'active',
        joinedAt: '2026-07-10T11:15:00Z',
        subdomain: 'noura-care',
        totalSales: 48900,
        paidOut: 44010,
        pendingPayout: 4890,
        subscriptionTier: 'starter',
        subscriptionPrice: 399,
        subscriptionStatus: 'active',
        staffCount: 8,
        bookingsCount: 142,
        rating: 4.7
      },
      {
        id: 'prov-4',
        storeName: isAr ? 'مركز سبا هيفاء والشرق' : 'Haifa Oriental Spa',
        ownerName: isAr ? 'هيفاء السليم' : 'Haifa Al-Salim',
        phone: '0558765432',
        email: 'haifa.spa@gmail.com',
        activity: isAr ? 'مركز سبا ومساج' : 'Spa & Wellness Center',
        status: 'suspended',
        joinedAt: '2026-07-17T14:15:00Z',
        subdomain: 'haifa-oriental',
        totalSales: 12800,
        paidOut: 11520,
        pendingPayout: 1280,
        subscriptionTier: 'starter',
        subscriptionPrice: 399,
        subscriptionStatus: 'overdue',
        staffCount: 5,
        bookingsCount: 39,
        rating: 4.2
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem('confirmed_registered_providers', JSON.stringify(registeredProviders));
  }, [registeredProviders]);

  // Synchronize approved provider requests into registered providers automatically
  useEffect(() => {
    const approvedRequests = providerRequests.filter(r => r.status === 'approved');
    let updated = false;
    const newProviders = [...registeredProviders];

    approvedRequests.forEach(req => {
      const exists = newProviders.some(p => p.email === req.email);
      if (!exists) {
        newProviders.push({
          id: `prov-${req.id}`,
          storeName: req.storeName,
          ownerName: req.name,
          phone: req.phone,
          email: req.email,
          activity: req.activity,
          status: 'active',
          joinedAt: req.requestedAt,
          subdomain: req.storeName.toLowerCase().replace(/[^a-z0-9]/g, '-'),
          totalSales: 0,
          paidOut: 0,
          pendingPayout: 0,
          subscriptionTier: 'starter',
          subscriptionPrice: 399,
          subscriptionStatus: 'active',
          staffCount: 3,
          bookingsCount: 0,
          rating: 5.0
        });
        updated = true;
      }
    });

    if (updated) {
      setRegisteredProviders(newProviders);
    }
  }, [providerRequests]);

  // 2. Administrative Employees State (Hierarchy & Levels)
  const [employees, setEmployees] = useState<PlatformEmployee[]>(() => {
    const saved = localStorage.getItem('confirmed_admin_employees') || localStorage.getItem('refah_admin_employees');
    if (saved) return JSON.parse(saved);
    return [
      {
        id: 'emp-1',
        name: isAr ? 'أحمد الشايق' : 'Ahmed Al-Shayek',
        email: 'ahmed@confirmed.sa',
        phone: '0559900112',
        role: 'senior_admin',
        joinedAt: '2026-01-10T08:00:00Z',
        permissions: ['all_permissions', 'manage_providers', 'manage_employees', 'send_campaigns', 'view_reports'],
        status: 'active'
      },
      {
        id: 'emp-2',
        name: isAr ? 'سارة عبدالعزيز' : 'Sarah Abdulaziz',
        email: 'sarah.ops@confirmed.sa',
        phone: '0559900334',
        role: 'ops_supervisor',
        joinedAt: '2026-03-15T09:30:00Z',
        permissions: ['manage_providers', 'approve_requests', 'view_reports'],
        status: 'active'
      },
      {
        id: 'emp-3',
        name: isAr ? 'خالد العتيبي' : 'Khaled Al-Otaibi',
        email: 'khaled.mkt@confirmed.sa',
        phone: '0559900556',
        role: 'marketing_spec',
        joinedAt: '2026-05-20T11:00:00Z',
        permissions: ['send_campaigns', 'manage_discounts'],
        status: 'active'
      },
      {
        id: 'emp-4',
        name: isAr ? 'ريم السديري' : 'Reem Al-Sudairy',
        email: 'reem.support@confirmed.sa',
        phone: '0559900778',
        role: 'tech_support',
        joinedAt: '2026-06-01T10:00:00Z',
        permissions: ['view_reports', 'support_chat'],
        status: 'active'
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem('confirmed_admin_employees', JSON.stringify(employees));
  }, [employees]);

  // Financial Dashboard and Ledger States
  const [selectedInsightProvId, setSelectedInsightProvId] = useState<string>('prov-1');
  const [financialLogs, setFinancialLogs] = useState(() => {
    const saved = localStorage.getItem('confirmed_financial_logs');
    if (saved) return JSON.parse(saved);
    return [
      {
        id: 'tx-1',
        type: 'subscription_renew',
        providerName: isAr ? 'صالون عهود بيوتي لاونج' : 'Ohood Beauty Lounge',
        amount: 1499,
        date: '2026-07-10T09:00:00Z',
        status: 'completed',
        ref: 'SUB-482931'
      },
      {
        id: 'tx-2',
        type: 'settlement',
        providerName: isAr ? 'مركز تالة سبا النسائي' : 'Tala Spa & Wellness',
        amount: 15400,
        date: '2026-07-05T15:30:00Z',
        status: 'completed',
        ref: 'REF-920481'
      },
      {
        id: 'tx-3',
        type: 'subscription_renew',
        providerName: isAr ? 'صالون نورة للتجميل والعناية' : 'Noura Salon & Care',
        amount: 399,
        date: '2026-07-01T10:00:00Z',
        status: 'completed',
        ref: 'SUB-204918'
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem('confirmed_financial_logs', JSON.stringify(financialLogs));
  }, [financialLogs]);

  // Employee Add Modal
  const [showAddEmpModal, setShowAddEmpModal] = useState(false);
  const [newEmpName, setNewEmpName] = useState('');
  const [newEmpEmail, setNewEmpEmail] = useState('');
  const [newEmpPhone, setNewEmpPhone] = useState('');
  const [newEmpRole, setNewEmpRole] = useState<'senior_admin' | 'ops_supervisor' | 'marketing_spec' | 'tech_support'>('ops_supervisor');
  const [newEmpPermissions, setNewEmpPermissions] = useState<string[]>(['manage_providers']);

  const handleAddEmployee = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmpName || !newEmpEmail || !newEmpPhone) return;

    // Base permissions depending on role
    let defaultPerms: string[] = [];
    if (newEmpRole === 'senior_admin') {
      defaultPerms = ['all_permissions', 'manage_providers', 'manage_employees', 'send_campaigns', 'view_reports'];
    } else if (newEmpRole === 'ops_supervisor') {
      defaultPerms = ['manage_providers', 'approve_requests', 'view_reports'];
    } else if (newEmpRole === 'marketing_spec') {
      defaultPerms = ['send_campaigns', 'manage_discounts'];
    } else {
      defaultPerms = ['view_reports', 'support_chat'];
    }

    const newEmp: PlatformEmployee = {
      id: `emp-${Math.random().toString(36).substring(2, 9)}`,
      name: newEmpName,
      email: newEmpEmail,
      phone: newEmpPhone,
      role: newEmpRole,
      joinedAt: new Date().toISOString(),
      permissions: defaultPerms,
      status: 'active'
    };

    setEmployees(prev => [newEmp, ...prev]);
    setShowAddEmpModal(false);
    setNewEmpName('');
    setNewEmpEmail('');
    setNewEmpPhone('');
  };

  const handleToggleEmpStatus = (id: string) => {
    setEmployees(prev => prev.map(emp => {
      if (emp.id === id) {
        return { ...emp, status: emp.status === 'active' ? 'suspended' : 'active' };
      }
      return emp;
    }));
  };

  const handleDeleteEmployee = (id: string) => {
    if (window.confirm(isAr ? 'هل أنتِ متأكدة من حذف هذا الموظف نهائياً؟' : 'Are you sure you want to remove this platform employee?')) {
      setEmployees(prev => prev.filter(emp => emp.id !== id));
    }
  };

  // 3. Registered Provider Management Toggle
  const handleToggleProviderStatus = (id: string) => {
    setRegisteredProviders(prev => prev.map(p => {
      if (p.id === id) {
        const newStatus = p.status === 'active' ? 'suspended' : 'active';
        return { ...p, status: newStatus };
      }
      return p;
    }));
  };

  // 4. Broadcast Communication Engine State
  const [broadcastTarget, setBroadcastTarget] = useState<'all' | 'providers' | 'clients'>('all');
  const [broadcastChannel, setBroadcastChannel] = useState<'sms' | 'email' | 'both'>('both');
  const [broadcastTitle, setBroadcastTitle] = useState('');
  const [broadcastMessage, setBroadcastMessage] = useState('');
  const [campaignLogs, setCampaignLogs] = useState<{
    id: string;
    title: string;
    target: string;
    channel: string;
    sentAt: string;
    status: string;
    count: number;
  }[]>(() => {
    const saved = localStorage.getItem('confirmed_campaign_logs') || localStorage.getItem('refah_campaign_logs');
    if (saved) return JSON.parse(saved);
    return [
      {
        id: 'camp-1',
        title: isAr ? 'تنبيه صيانة وترقية النظام الدورية' : 'Scheduled Core Database Upgrade',
        target: isAr ? 'المزودين (الصالونات)' : 'Registered Providers',
        channel: 'SMS & Email',
        sentAt: '2026-07-15T01:00:00Z',
        status: 'completed',
        count: 4
      },
      {
        id: 'camp-2',
        title: isAr ? 'عرض الصيف: كود خصم للتسجيل المبكر' : 'Summer Early-Bird Campaign',
        target: isAr ? 'جميع العملاء والمزودين' : 'All Users & Providers',
        channel: 'Email Campaign',
        sentAt: '2026-07-10T12:00:00Z',
        status: 'completed',
        count: 154
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem('confirmed_campaign_logs', JSON.stringify(campaignLogs));
  }, [campaignLogs]);

  // Simulated notifications dispatch tracker
  const [simulatedDispatch, setSimulatedDispatch] = useState<{
    type: 'sms' | 'email';
    recipient: string;
    message: string;
    timestamp: string;
  }[]>([]);

  const handleSendBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastTitle || !broadcastMessage) return;

    // Calculate recipient count
    let count = 0;
    const dispatches: any[] = [];
    const timestamp = new Date().toLocaleTimeString(isAr ? 'ar-SA' : 'en-US');

    if (broadcastTarget === 'providers' || broadcastTarget === 'all') {
      registeredProviders.forEach(p => {
        count++;
        if (broadcastChannel === 'email' || broadcastChannel === 'both') {
          dispatches.push({
            type: 'email',
            recipient: p.email,
            message: `[${broadcastTitle}] - ${broadcastMessage}`,
            timestamp
          });
        }
        if (broadcastChannel === 'sms' || broadcastChannel === 'both') {
          dispatches.push({
            type: 'sms',
            recipient: p.phone,
            message: broadcastMessage,
            timestamp
          });
        }
      });
    }

    if (broadcastTarget === 'clients' || broadcastTarget === 'all') {
      // Simulate client list
      const mockClients = [
        { name: 'جود الرويس', email: 'joud@outlook.com', phone: '0559988111' },
        { name: 'أريج العلي', email: 'areej@gmail.com', phone: '0559988222' },
        { name: 'ابتسام محمد', email: 'ebtisam@hotmail.com', phone: '0559988333' }
      ];
      mockClients.forEach(c => {
        count++;
        if (broadcastChannel === 'email' || broadcastChannel === 'both') {
          dispatches.push({
            type: 'email',
            recipient: c.email,
            message: `[${broadcastTitle}] - ${broadcastMessage}`,
            timestamp
          });
        }
        if (broadcastChannel === 'sms' || broadcastChannel === 'both') {
          dispatches.push({
            type: 'sms',
            recipient: c.phone,
            message: broadcastMessage,
            timestamp
          });
        }
      });
    }

    // Set simulated animation dispatches
    setSimulatedDispatch(dispatches);

    // Save campaign log
    const newLog = {
      id: `camp-${Math.random().toString(36).substring(2, 9)}`,
      title: broadcastTitle,
      target: broadcastTarget === 'all' 
        ? (isAr ? 'العملاء والمزودين' : 'All Users') 
        : broadcastTarget === 'providers' 
        ? (isAr ? 'المزودين فقط' : 'Providers Only') 
        : (isAr ? 'العملاء فقط' : 'Clients Only'),
      channel: broadcastChannel === 'both' ? 'SMS & Email' : broadcastChannel.toUpperCase(),
      sentAt: new Date().toISOString(),
      status: 'completed',
      count
    };

    setCampaignLogs(prev => [newLog, ...prev]);

    // Show simulated confirmation
    alert(isAr 
      ? `تم إطلاق الحملة الإعلانية وبث ${count} تنبيهاً بنجاح عبر بروتوكولات الإرسال السحابية!` 
      : `Broadcast launched successfully! Dispatched ${count} messages across simulated cloud protocols.`);

    // Clear inputs
    setBroadcastTitle('');
    setBroadcastMessage('');
  };

  // 4b. Settle Provider Pending Payouts
  const handleSettlePayout = (providerId: string) => {
    const provider = registeredProviders.find(p => p.id === providerId);
    if (!provider) return;
    if (provider.pendingPayout <= 0) {
      alert(isAr ? 'لا يوجد مستحقات معلقة لتسويتها لهذا المزود!' : 'No pending payouts available to settle for this provider!');
      return;
    }
    
    const amount = provider.pendingPayout;
    if (window.confirm(isAr 
      ? `هل أنتِ متأكدة من تسوية المستحقات البالغة ${amount.toLocaleString()} ريال لـ (${provider.storeName})؟ سيتم تحويل المبلغ لـ "المبالغ المدفوعة".`
      : `Confirm settlement of SAR ${amount.toLocaleString()} for (${provider.storeName})? This will move the amount to "Paid Out".`
    )) {
      // Update provider financial state
      setRegisteredProviders(prev => prev.map(p => {
        if (p.id === providerId) {
          return {
            ...p,
            paidOut: p.paidOut + amount,
            pendingPayout: 0
          };
        }
        return p;
      }));

      // Log this financial transaction
      const newTxLog = {
        id: `tx-${Math.random().toString(36).substring(2, 9)}`,
        type: 'settlement',
        providerName: provider.storeName,
        amount,
        date: new Date().toISOString(),
        status: 'completed',
        ref: `REF-${Math.floor(100000 + Math.random() * 900000)}`
      };
      setFinancialLogs(prev => [newTxLog, ...prev]);

      alert(isAr 
        ? `تمت تسوية المستحقات بنجاح وصرف مبلغ ${amount.toLocaleString()} ريال لـ ${provider.storeName}!` 
        : `Payout of SAR ${amount.toLocaleString()} settled successfully for ${provider.storeName}!`);
    }
  };

  // 4c. Update Subscription parameters
  const handleUpdateSubscription = (providerId: string, tier: 'starter' | 'pro' | 'enterprise', status: 'active' | 'overdue' | 'trial') => {
    let price = 399;
    if (tier === 'pro') price = 799;
    if (tier === 'enterprise') price = 1499;

    setRegisteredProviders(prev => prev.map(p => {
      if (p.id === providerId) {
        return {
          ...p,
          subscriptionTier: tier,
          subscriptionPrice: price,
          subscriptionStatus: status
        };
      }
      return p;
    }));

    const storeName = registeredProviders.find(p => p.id === providerId)?.storeName || '';

    // Log transaction
    const newTxLog = {
      id: `tx-${Math.random().toString(36).substring(2, 9)}`,
      type: 'subscription_change',
      providerName: storeName,
      amount: price,
      date: new Date().toISOString(),
      status: 'completed',
      ref: `SUB-${Math.floor(100000 + Math.random() * 900000)}`
    };
    setFinancialLogs(prev => [newTxLog, ...prev]);

    alert(isAr 
      ? `تم تحديث اشتراك صالون (${storeName}) وتطبيق باقة الـ ${tier.toUpperCase()} بنجاح!` 
      : `Salon (${storeName}) subscription successfully upgraded to ${tier.toUpperCase()}!`);
  };

  // Filtering lists
  const filteredProviders = registeredProviders.filter(p => 
    p.storeName.toLowerCase().includes(providerSearch.toLowerCase()) ||
    p.ownerName.toLowerCase().includes(providerSearch.toLowerCase()) ||
    p.email.toLowerCase().includes(providerSearch.toLowerCase())
  );

  const filteredEmployees = employees.filter(e => 
    e.name.toLowerCase().includes(employeeSearch.toLowerCase()) ||
    e.email.toLowerCase().includes(employeeSearch.toLowerCase())
  );

  // Role translators
  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'senior_admin': return 'bg-purple-100 text-purple-700 border-purple-200';
      case 'ops_supervisor': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'marketing_spec': return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'tech_support': return 'bg-slate-100 text-slate-700 border-slate-200';
      default: return 'bg-slate-100 text-slate-700';
    }
  };

  const getRoleLabel = (role: string) => {
    if (isAr) {
      switch (role) {
        case "senior_admin": return "أدمن أول - مالك صلاحيات";
        case "ops_supervisor": return "مشرف عمليات وبوابات";
        case "marketing_spec": return "مسؤول تسويق وحملات";
        case "tech_support": return "دعم فني وتواصل";
        default: return role;
      }
    } else {
      switch (role) {
        case "senior_admin": return "Senior Admin";
        case "ops_supervisor": return "Operations Supervisor";
        case "marketing_spec": return "Marketing Specialist";
        case "tech_support": return "Technical Support";
        default: return role;
      }
    }
  };

  return (
    <div className="min-h-screen bg-white text-[#1C1B18] flex flex-col font-sans selection:bg-[#FF5A5F]/20 selection:text-[#FF5A5F]" dir={dir}>
      
      {/* ===== MASTER ADMIN HEADER ===== */}
      <header className="bg-white border-b border-[#E9E7E2] py-4 px-6 md:px-12 flex flex-col sm:flex-row justify-between items-center gap-4 sticky top-0 z-40 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="flex gap-1.5 items-center bg-[#F6F6F4] px-3 py-2.5 rounded-xl border border-[#E9E7E2]">
            <span className="w-2.5 h-2.5 rounded-full bg-[#FF5A5F] shadow-sm animate-pulse" />
            <span className="w-2.5 h-2.5 rounded-full bg-[#9E9E9E] shadow-sm" />
            <span className="w-2.5 h-2.5 rounded-full bg-[#FFAE34] shadow-sm" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
              <h1 className="text-sm md:text-base font-black tracking-widest uppercase text-[#14332B] font-mono">
                {isAr ? 'بوابة إدارة منصة CONFIRMED السحابية' : 'CONFIRMED SYSTEM PLATFORM OWNER'}
              </h1>
            </div>
            <span className="text-[10px] text-[#FF5A5F] font-bold block uppercase mt-0.5 tracking-wider font-mono">
              ⚡ CENTRAL COMMAND PANEL · MFA SIGNED
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3 self-stretch sm:self-auto justify-between">
          <div className="bg-[#F6F6F4] px-3.5 py-1.5 rounded-xl border border-[#E9E7E2] text-xs font-mono text-[#6E6A63] font-bold">
            👑 {isAr ? 'أدمن النظام الموحد' : 'System Master Admin'}
          </div>

          {/* Quick Lock Platform command */}
          <button
            onClick={() => {
              window.dispatchEvent(new CustomEvent('request-lock'));
            }}
            title={isAr ? 'قفل شاشة الأدمن يدوياً فوراً (Ctrl + L)' : 'Lock terminal screen manually immediately (Ctrl + L)'}
            className="flex items-center gap-1.5 px-3 py-2 bg-red-50 hover:bg-red-100 border border-red-200 text-red-600 hover:text-red-700 rounded-xl text-xs font-bold transition-all cursor-pointer shadow-xs"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>{isAr ? 'قفل الشاشة 🔒' : 'Lock Panel 🔒'}</span>
          </button>

          <button 
            onClick={onLogout}
            className="bg-[#FF5A5F]/15 hover:bg-[#FF5A5F] text-[#FF5A5F] hover:text-white border border-[#FF5A5F]/20 hover:border-transparent px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-sm shadow-[#FF5A5F]/5"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>{isAr ? 'تسجيل الخروج الأمن' : 'Secure Logout'}</span>
          </button>
        </div>
      </header>

      {/* ===== COMMAND DASHBOARD BODY ===== */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-5 md:p-8 space-y-8">
        
        {/* TOP LEVEL NAVIGATION TABS */}
        <div className="flex flex-wrap border-b border-[#E9E7E2] gap-6">
          <button
            onClick={() => setActiveSubTab('stats')}
            className={`pb-4 text-sm font-bold border-b-2 transition-all cursor-pointer relative ${
              activeSubTab === 'stats' 
                ? 'border-[#FF5A5F] text-[#FF5A5F]' 
                : 'border-transparent text-[#6E6A63] hover:text-[#14332B]'
            }`}
          >
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4" />
              <span>{isAr ? 'مؤشرات المنصة والأداء' : 'Platform Overview'}</span>
            </div>
          </button>

          <button
            onClick={() => setActiveSubTab('providers')}
            className={`pb-4 text-sm font-bold border-b-2 transition-all cursor-pointer relative ${
              activeSubTab === 'providers' 
                ? 'border-[#FF5A5F] text-[#FF5A5F]' 
                : 'border-transparent text-[#6E6A63] hover:text-[#14332B]'
            }`}
          >
            <div className="flex items-center gap-2">
              <Building className="w-4 h-4" />
              <span>{isAr ? 'إدارة مزودي الخدمات' : 'Service Providers'}</span>
              {providerRequests.filter(r => r.status === 'pending').length > 0 && (
                <span className="bg-[#FF5A5F] text-white text-[9px] font-bold px-2 py-0.5 rounded-full animate-bounce">
                  {providerRequests.filter(r => r.status === 'pending').length}
                </span>
              )}
            </div>
          </button>

          <button
            onClick={() => setActiveSubTab('financials')}
            className={`pb-4 text-sm font-bold border-b-2 transition-all cursor-pointer relative ${
              activeSubTab === 'financials' 
                ? 'border-[#FF5A5F] text-[#FF5A5F]' 
                : 'border-transparent text-[#6E6A63] hover:text-[#14332B]'
            }`}
          >
            <div className="flex items-center gap-2">
              <CreditCard className="w-4 h-4" />
              <span>{isAr ? 'التقارير والإيرادات المالية' : 'Financial Revenue Hub'}</span>
            </div>
          </button>

          <button
            onClick={() => setActiveSubTab('employees')}
            className={`pb-4 text-sm font-bold border-b-2 transition-all cursor-pointer relative ${
              activeSubTab === 'employees' 
                ? 'border-[#FF5A5F] text-[#FF5A5F]' 
                : 'border-transparent text-[#6E6A63] hover:text-[#14332B]'
            }`}
          >
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              <span>{isAr ? 'موظفي إدارة المنصة وطاقم العمل' : 'Administrative Staff'}</span>
              <span className="bg-white border border-[#E9E7E2] text-[#6E6A63] text-[10px] px-2 py-0.5 rounded-full font-bold">
                {employees.length}
              </span>
            </div>
          </button>

          <button
            onClick={() => setActiveSubTab('broadcast')}
            className={`pb-4 text-sm font-bold border-b-2 transition-all cursor-pointer relative ${
              activeSubTab === 'broadcast' 
                ? 'border-[#FF5A5F] text-[#FF5A5F]' 
                : 'border-transparent text-[#6E6A63] hover:text-[#14332B]'
            }`}
          >
            <div className="flex items-center gap-2">
              <Megaphone className="w-4 h-4" />
              <span>{isAr ? 'بث الإشعارات والرسائل والعروض' : 'Broadcast Center'}</span>
            </div>
          </button>

          <button
            onClick={() => setActiveSubTab('packages')}
            className={`pb-4 text-sm font-bold border-b-2 transition-all cursor-pointer relative ${
              activeSubTab === 'packages' 
                ? 'border-[#FF5A5F] text-[#FF5A5F]' 
                : 'border-transparent text-[#6E6A63] hover:text-[#14332B]'
            }`}
          >
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4" />
              <span>{isAr ? 'إدارة باقات الاشتراكات' : 'Subscription Packages'}</span>
              <span className="bg-[#FF5A5F]/10 text-[#FF5A5F] text-[10px] px-2 py-0.5 rounded-full font-bold border border-[#FF5A5F]/25">
                {packages?.length || 0}
              </span>
            </div>
          </button>
        </div>

        {/* ===== VIEW 1: STATS OVERVIEW ===== */}
        {activeSubTab === 'stats' && (
          <div className="space-y-6 animate-fadeIn">
            {/* Quick KPI Stats row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white border border-[#E9E7E2] rounded-3xl p-6 space-y-4 shadow-sm">
                <span className="text-[10px] text-[#6E6A63] block uppercase font-mono tracking-wider font-bold">{isAr ? 'إجمالي المتاجر ومزودي الخدمة' : 'TOTAL REGISTERED PROVIDERS'}</span>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-bold text-[#14332B] font-mono">{registeredProviders.length}</span>
                  <span className="text-xs text-emerald-600 font-bold">🟢 {registeredProviders.filter(p => p.status === 'active').length} {isAr ? 'نشط' : 'Active'}</span>
                </div>
                <p className="text-xs text-[#6E6A63] leading-normal">
                  {isAr ? 'عدد الصالونات والمشاغل ومراكز السبا المعتمدة حالياً بالمنصة.' : 'Fully verified beauty hubs, salons, and health spas in Saudi Arabia.'}
                </p>
              </div>

              <div className="bg-white border border-[#E9E7E2] rounded-3xl p-6 space-y-4 shadow-sm">
                <span className="text-[10px] text-[#6E6A63] block uppercase font-mono tracking-wider font-bold">{isAr ? 'طلبات التسجيل المعلقة مسبقاً' : 'PENDING ACTIVATIONS'}</span>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-bold text-[#FF5A5F] font-mono">
                    {providerRequests.filter(r => r.status === 'pending').length}
                  </span>
                  <span className="text-xs text-[#6E6A63] font-bold">{isAr ? 'طلبات بانتظار المراجعة' : 'awaiting verification'}</span>
                </div>
                <p className="text-xs text-[#6E6A63] leading-normal">
                  {isAr ? 'طلبات صالونات التجميل الجديدة التي قامت بالتسجيل عبر البوابة.' : 'New storefront registration tickets queued for verification.'}
                </p>
              </div>

              <div className="bg-white border border-[#E9E7E2] rounded-3xl p-6 space-y-4 shadow-sm">
                <span className="text-[10px] text-[#6E6A63] block uppercase font-mono tracking-wider font-bold">{isAr ? 'طاقم العمل والمسؤولين' : 'PLATFORM WORKFORCE'}</span>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-bold text-emerald-600 font-mono">{employees.length}</span>
                  <span className="text-xs text-[#6E6A63] font-bold">{isAr ? 'مدراء ومشرفين مفعّلين' : 'operational staff'}</span>
                </div>
                <p className="text-xs text-[#6E6A63] leading-normal">
                  {isAr ? 'طاقم الموظفين الخاضعين لإدارتكم لتوزيع مهام التشغيل والدعم.' : 'Platform team with role-based hierarchies and level permissions.'}
                </p>
              </div>

              <div className="bg-white border border-[#E9E7E2] rounded-3xl p-6 space-y-4 shadow-sm">
                <span className="text-[10px] text-[#6E6A63] block uppercase font-mono tracking-wider font-bold">{isAr ? 'الحملات الإعلانية الصادرة' : 'BROADCAST CAMPAIGNS'}</span>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-bold text-indigo-650 font-mono">{campaignLogs.length}</span>
                  <span className="text-xs text-emerald-600 font-bold">{isAr ? 'بث ناجح ✓' : 'dispatched ✓'}</span>
                </div>
                <p className="text-xs text-[#6E6A63] leading-normal">
                  {isAr ? 'عدد حملات الرسائل النصية القصيرة والإيميلات الإعلانية والتنبيهية.' : 'System notification notifications issued to clients and provider bases.'}
                </p>
              </div>
            </div>

            {/* Quick Financial Overview Bar */}
            <div className="bg-emerald-50/50 border border-emerald-100 rounded-3xl p-5 md:p-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div className="flex gap-4 items-center">
                <div className="bg-[#14332B] text-[#E9E7E2] p-3 rounded-2xl">
                  <DollarSign className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[10px] text-emerald-800 uppercase font-mono font-bold tracking-wider">{isAr ? 'الإيرادات والعمولات السحابية' : 'Platform Revenue Overview'}</span>
                  <div className="flex items-baseline gap-1.5 mt-0.5">
                    <span className="text-xl font-black text-[#14332B] font-mono">
                      {(registeredProviders.reduce((acc, curr) => acc + (curr.totalSales || 0), 0)).toLocaleString()} {isAr ? 'ريال' : 'SAR'}
                    </span>
                    <span className="text-xs text-[#6E6A63]">{isAr ? '(مبيعات الشركاء الإجمالية)' : '(Gross Partner GMV)'}</span>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-4 w-full md:w-auto">
                <div className="bg-white px-4 py-2 border border-emerald-100 rounded-xl font-mono text-xs text-right">
                  <span className="text-[#6E6A63] block text-[9px] font-bold">{isAr ? 'عمولة المنصة الصافية' : 'NET COMMISSION'}</span>
                  <span className="font-bold text-[#14332B]">{(Math.round(registeredProviders.reduce((acc, curr) => acc + (curr.totalSales || 0), 0) * 0.1)).toLocaleString()} ريال</span>
                </div>
                <div className="bg-white px-4 py-2 border border-emerald-100 rounded-xl font-mono text-xs text-right">
                  <span className="text-[#6E6A63] block text-[9px] font-bold">{isAr ? 'بانتظار صرف الشركاء' : 'AWAITING PAYOUT'}</span>
                  <span className="font-bold text-amber-700">{(registeredProviders.reduce((acc, curr) => acc + (curr.pendingPayout || 0), 0)).toLocaleString()} ريال</span>
                </div>
                <button
                  onClick={() => setActiveSubTab('financials')}
                  className="bg-[#14332B] hover:bg-[#FF5A5F] text-[#E9E7E2] hover:text-white border border-transparent px-5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer shadow-sm flex items-center gap-1.5"
                >
                  <ArrowUpRight className="w-4 h-4" />
                  <span>{isAr ? 'افتح بوابة الإيرادات والتسويات' : 'Open Financial Hub'}</span>
                </button>
              </div>
            </div>

            {/* Platform Master info box & Quick tutorial */}
            <div className="bg-white border border-[#E9E7E2] rounded-[32px] p-6 md:p-8 relative overflow-hidden grid grid-cols-1 md:grid-cols-12 gap-6 shadow-sm">
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#FF5A5F]/5 rounded-full blur-3xl pointer-events-none" />
              
              <div className="md:col-span-8 space-y-4">
                <div className="flex items-center gap-2">
                  <span className="bg-[#FF5A5F]/10 text-[#FF5A5F] text-[10px] font-bold px-2.5 py-1 rounded-lg border border-[#FF5A5F]/25">
                    {isAr ? 'مستندات حوكمة المنصة' : 'Governance & Audit'}
                  </span>
                  <span className="text-[#6E6A63] font-mono text-[11px] font-semibold">{isAr ? 'تأمين كامل للقنوات' : 'MFA SECURED PLATFORM'}</span>
                </div>
                <h3 className="font-serif text-xl sm:text-2xl font-bold text-[#14332B]">
                  {isAr ? 'حوكمة تفعيل حسابات الصالونات ومزودي الخدمات' : 'Onboarding and Provider Suspension Policy'}
                </h3>
                <p className="text-sm text-[#6E6A63] leading-relaxed">
                  {isAr 
                    ? 'بصفتكِ مالكة ومؤسسة النظام الموحد لـ CONFIRMED، تتمتعين بصلاحيات مطلقة لإدارة المتاجر المسجلة. قومي بمراجعة وتأكيد هوية الصالونات النسائية الجديدة قبل التفعيل لمنع انتحال العلامات التجارية، كما يمكنك تعليق أو إيقاف أي متجر مؤقتاً في حال الإخلال بشروط الاستخدام أو عدم سداد رسوم الاشتراك الدورية بنقرة زر واحدة.'
                    : 'As the principal platform owner, you wield central authority over the marketplace. Verify incoming salon businesses to avoid brand impersonation, approve their pending sign-up forms, or immediately suspend any provider who violates platform terms of service.'}
                </p>
              </div>

              <div className="md:col-span-4 bg-[#F6F6F4] border border-[#E9E7E2] p-5 rounded-2xl flex flex-col justify-between">
                <div className="space-y-3">
                  <span className="text-[10px] font-bold text-[#6E6A63] block uppercase font-mono">{isAr ? 'التحقق التلقائي للربط' : 'SYSTEM INTEGRATION LOG'}</span>
                  <div className="space-y-2 font-mono text-xs text-[#1C1B18]">
                    <div className="flex justify-between">
                      <span>ZATCA Hub:</span>
                      <span className="text-emerald-600 font-bold">ONLINE</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Secure Mailer:</span>
                      <span className="text-emerald-600 font-bold">ACTIVE</span>
                    </div>
                    <div className="flex justify-between">
                      <span>SMS Gateway:</span>
                      <span className="text-emerald-600 font-bold">ONLINE</span>
                    </div>
                  </div>
                </div>

                <div className="pt-4 mt-4 border-t border-[#E9E7E2] flex items-center gap-1.5 text-xs text-[#6E6A63]">
                  <Sliders className="w-4 h-4 text-[#FF5A5F]" />
                  <span>{isAr ? 'التشفير: AES-GCM 256' : 'AES-GCM 256 Encryption'}</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ===== VIEW 2: PROVIDERS MANAGEMENT ===== */}
        {activeSubTab === 'providers' && (
          <div className="space-y-8 animate-fadeIn">
            
            {/* 2a. Pending Requests Section */}
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                <div>
                  <h3 className="font-serif text-lg font-bold text-[#14332B] flex items-center gap-2">
                    <Clock className="w-5 h-5 text-[#FF5A5F]" />
                    <span>{isAr ? 'طلبات التسجيل المعلقة للمراجعة والموافقة' : 'Pending Salon Inquiries'}</span>
                  </h3>
                  <p className="text-xs text-[#6E6A63]">
                    {isAr ? 'يرجى مراجعة وتدقيق ملكية المشاغل والصالونات وتفعيل حساباتهم لإرسال يوزر ورابط الدخول آلياً.' : 'Verify identities and trigger immediate automated welcome/onboarding emails.'}
                  </p>
                </div>
              </div>

              {providerRequests.filter(r => r.status === 'pending').length === 0 ? (
                <div className="text-center py-10 bg-white rounded-3xl border border-[#E9E7E2] space-y-3 shadow-sm">
                  <Check className="w-8 h-8 text-emerald-500 mx-auto" />
                  <p className="text-xs text-[#14332B] font-bold">{isAr ? 'لا توجد أي طلبات تفعيل معلقة حالياً ✓' : 'No pending provider requests found ✓'}</p>
                  <p className="text-[11px] text-[#6E6A63] max-w-sm mx-auto">
                    {isAr 
                      ? 'عندما تقوم صالونات جديدة بالتسجيل عبر البوابة الرئيسية للإنضمام، ستظهر طلباتهم هنا فوراً للموافقة.' 
                      : 'When salon owners complete the progressive registry modal, their details appear here.'}
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {providerRequests.filter(r => r.status === 'pending').map((req) => (
                    <div 
                      key={req.id} 
                      className="bg-white border border-[#E9E7E2] rounded-2xl p-5 md:p-6 transition-all relative overflow-hidden flex flex-col md:flex-row justify-between items-start md:items-center gap-6 shadow-sm hover:shadow-md"
                    >
                      <div className="absolute top-0 bottom-0 left-0 w-1.5 bg-[#FF5A5F]" />

                      <div className="space-y-3 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-[#FF5A5F]/10 text-[#FF5A5F] border border-[#FF5A5F]/20">
                            {isAr ? 'معلق - بانتظار الموافقة والتفعيل' : 'Awaiting Review'}
                          </span>
                          <span className="text-[#6E6A63] text-[11px] font-mono font-medium">
                            {new Date(req.requestedAt).toLocaleString(isAr ? 'ar-SA' : 'en-US')}
                          </span>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                          <div>
                            <span className="text-[10px] text-[#6E6A63] block uppercase font-bold">{isAr ? 'الصالون / المشغل' : 'Salon Business Name'}</span>
                            <span className="text-sm font-bold text-[#14332B] block mt-0.5">{req.storeName}</span>
                          </div>
                          <div>
                            <span className="text-[10px] text-[#6E6A63] block uppercase font-bold">{isAr ? 'اسم المالكة / موظفة التواصل' : 'Owner / Contact'}</span>
                            <span className="text-sm font-bold text-[#1C1B18] block mt-0.5">{req.name}</span>
                          </div>
                          <div>
                            <span className="text-[10px] text-[#6E6A63] block uppercase font-bold">{isAr ? 'نوع النشاط' : 'Niche'}</span>
                            <span className="text-sm font-semibold text-teal-700 block mt-0.5">{req.activity}</span>
                          </div>
                          <div>
                            <span className="text-[10px] text-[#6E6A63] block uppercase font-bold">{isAr ? 'الباقة والمدفوعات' : 'Package & Payments'}</span>
                            <span className="text-xs font-bold text-emerald-600 block mt-0.5">
                              {req.selectedPackage === 'basic' ? (isAr ? 'الباقة الأساسية' : 'Basic Starter') : req.selectedPackage === 'pro' ? (isAr ? 'الباقة الاحترافية' : 'Professional') : req.selectedPackage === 'enterprise' ? (isAr ? 'سلاسل الصالونات' : 'Enterprise') : (isAr ? 'الباقة الاحترافية' : 'Professional Plan')}
                              {' '}({req.billingCycle === 'yearly' ? (isAr ? 'سنوي' : 'Yearly') : (isAr ? 'شهري' : 'Monthly')})
                            </span>
                            <span className="text-[10px] text-[#FF5A5F] block font-mono font-bold mt-0.5">
                              {req.amountPaid ? `${req.amountPaid} ${isAr ? 'ر.س' : 'SAR'}` : (req.selectedPackage === 'basic' ? (req.billingCycle === 'yearly' ? '1908' : '199') : (req.billingCycle === 'yearly' ? '3828' : '399')) + ` ${isAr ? 'ر.س' : 'SAR'}`} - {req.paymentStatus === 'paid_verified' ? (isAr ? '✓ مدفوع وآمن' : '✓ Paid & Secured') : (isAr ? '✓ مدفوع وآمن' : '✓ Paid & Secured')}
                            </span>
                          </div>
                        </div>

                        <div className="pt-2 border-t border-dashed border-[#E9E7E2] flex flex-wrap gap-4 text-xs font-mono text-[#6E6A63]">
                          <span className="flex items-center gap-1"><Mail className="w-3.5 h-3.5 text-[#FFAE34]" /> {req.email}</span>
                          <span className="flex items-center gap-1"><Phone className="w-3.5 h-3.5 text-[#FFAE34]" /> {req.phone}</span>
                        </div>
                      </div>

                      <div className="shrink-0 self-stretch md:self-auto flex items-center justify-end">
                        <button
                          onClick={() => {
                            onApproveRequest(req.id);
                            alert(isAr 
                              ? `تمت الموافقة وتفعيل حساب صالون (${req.storeName}) بنجاح! وتم إرسال رابط تسجيل الدخول المشفر للإيميل.` 
                              : `Successfully approved & activated (${req.storeName}) portal! Secure credentials dispatched via SMTP.`);
                          }}
                          className="w-full md:w-auto bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white font-bold text-xs sm:text-sm px-5 py-3.5 rounded-xl transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
                        >
                          <ShieldCheck className="w-4 h-4 text-white animate-pulse" />
                          <span>{isAr ? 'تأكيد التفعيل والمراسلة الفورية 📧' : 'Instant Approve & E-Mail'}</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* 2b. Registered Providers Catalog */}
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                  <h3 className="font-serif text-lg font-bold text-[#14332B] flex items-center gap-2">
                    <Building className="w-5 h-5 text-emerald-600" />
                    <span>{isAr ? 'مستودع المتاجر ومزودي الخدمات المعتمدين' : 'Registered Providers Portfolio'}</span>
                  </h3>
                  <p className="text-xs text-[#6E6A63]">
                    {isAr ? 'قائمة بجميع المشاغل والشركاء المعتمدين في النظام. يمكنك إيقاف وتجميد الحسابات أو إعادة تفعيلها فورياً.' : 'Portfolio of live client hubs. Switch active status or lock systems instantly.'}
                  </p>
                </div>

                <div className="relative w-full sm:w-72">
                  <Search className="absolute left-3 top-2.5 w-4 h-4 text-[#6E6A63]" />
                  <input
                    type="text"
                    placeholder={isAr ? 'بحث باسم الصالون، المالكة، أو الإيميل...' : 'Filter by salon, owner, email...'}
                    value={providerSearch}
                    onChange={(e) => setProviderSearch(e.target.value)}
                    className="w-full bg-white border border-[#E9E7E2] text-xs px-4 py-2.5 pl-9 rounded-xl focus:outline-none focus:border-[#FF5A5F] text-[#1C1B18] shadow-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filteredProviders.map((p) => {
                  const isActive = p.status === 'active';
                  return (
                    <div 
                      key={p.id} 
                      className={`bg-white border rounded-2xl p-5 relative overflow-hidden flex flex-col justify-between transition-all shadow-sm ${
                        isActive ? 'border-[#E9E7E2] hover:border-[#FF5A5F]/40' : 'border-[#FF5A5F]/20 opacity-80'
                      }`}
                    >
                      <div className={`absolute top-0 left-0 right-0 h-1.5 ${isActive ? 'bg-emerald-500' : 'bg-red-500'}`} />

                      <div className="space-y-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-serif font-black text-[#14332B] text-base">{p.storeName}</h4>
                            <p className="text-[11px] text-teal-700 font-mono mt-0.5">🌐 {p.subdomain}.confirmed.sa</p>
                          </div>

                          <button
                            onClick={() => {
                              handleToggleProviderStatus(p.id);
                              alert(isActive 
                                ? (isAr ? 'تم تعليق هذا الحساب وحظر وصول الموظفات للوحة تحكم الصالون.' : 'Account suspended successfully. Locked out provider dashboard access.')
                                : (isAr ? 'تمت إعادة تفعيل حساب الصالون.' : 'Account status set to active successfully.')
                              );
                            }}
                            className={`px-3 py-1.5 rounded-xl text-[10px] font-bold border cursor-pointer transition-all ${
                              isActive 
                                ? 'bg-emerald-550/10 border-emerald-500/25 text-emerald-600 hover:bg-emerald-500/20' 
                                : 'bg-red-550/10 border-red-500/25 text-red-600 hover:bg-red-500/20'
                            }`}
                          >
                            <span className="flex items-center gap-1">
                              {isActive ? <Unlock className="w-3 h-3" /> : <Lock className="w-3 h-3" />}
                              {isActive ? (isAr ? 'حساب مفعّل' : 'Active') : (isAr ? 'حساب موقوف' : 'Suspended')}
                            </span>
                          </button>
                        </div>

                        <div className="bg-[#F6F6F4] p-3 rounded-xl text-xs font-mono text-[#1C1B18] space-y-2 border border-[#E9E7E2]">
                          <div className="flex justify-between">
                            <span className="text-[#6E6A63]">{isAr ? 'المالكة:' : 'Owner:'}</span>
                            <span className="text-[#14332B] font-bold">{p.ownerName}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-[#6E6A63]">{isAr ? 'البريد الإلكتروني:' : 'Email:'}</span>
                            <span className="text-[#1C1B18] font-bold truncate max-w-[170px]" title={p.email}>{p.email}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-[#6E6A63]">{isAr ? 'الجوال:' : 'Phone:'}</span>
                            <span className="text-[#FF5A5F] font-bold">{p.phone}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-[#6E6A63]">{isAr ? 'النشاط الأساسي:' : 'Activity:'}</span>
                            <span className="text-teal-700 font-semibold">{p.activity}</span>
                          </div>
                        </div>

                        {/* View Full Profile details CTA */}
                        <button
                          onClick={() => setSelectedProfileProvider(p)}
                          className="w-full mt-3 px-4 py-2.5 bg-slate-50 hover:bg-slate-100 border border-[#E9E7E2] rounded-xl text-[11px] font-bold text-[#14332B] flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs hover:border-[#FF5A5F]/40"
                        >
                          <span>ℹ️</span>
                          <span>{isAr ? 'عرض ملف مزود الخدمة بالكامل' : 'View Full Provider Profile'}</span>
                        </button>
                      </div>

                      <div className="pt-4 mt-4 border-t border-[#E9E7E2] flex items-center justify-between text-[11px] text-[#6E6A63] font-mono">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" />
                          {isAr ? 'منضم في: ' : 'Joined: '} {new Date(p.joinedAt).toLocaleDateString(isAr ? 'ar-SA' : 'en-US')}
                        </span>

                        {isActive ? (
                          <span className="text-emerald-600 font-sans font-bold flex items-center gap-1">
                            <ShieldCheck className="w-3.5 h-3.5" /> {isAr ? 'النظام يعمل' : 'Online'}
                          </span>
                        ) : (
                          <span className="text-red-600 font-sans font-bold flex items-center gap-1">
                            <ShieldAlert className="w-3.5 h-3.5" /> {isAr ? 'مغلق ومحجوب' : 'Locked'}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* ===== VIEW 3: PLATFORM ADMINISTRATIVE EMPLOYEES (HIERARCHY) ===== */}
        {activeSubTab === 'employees' && (
          <div className="space-y-6 animate-fadeIn">
            
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div>
                <h3 className="font-serif text-lg font-bold text-[#14332B] flex items-center gap-2">
                  <Briefcase className="w-5 h-5 text-[#FFAE34]" />
                  <span>{isAr ? 'إدارة طاقم عمل المنصة وتعيين الصلاحيات' : 'Platform Administrative Staff Command'}</span>
                </h3>
                <p className="text-xs text-[#6E6A63]">
                  {isAr ? 'قائمة بموظفي إدارة CONFIRMED السحابية. يمكنك توظيف فريق عمل وتحديد مستوياتهم وصلاحياتهم بحسب السلم الوظيفي.' : 'Workforce team managing operations. Assign staff roles, level tiers, and system privileges.'}
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto self-stretch">
                <div className="relative w-full sm:w-60">
                  <Search className="absolute left-3 top-2.5 w-4 h-4 text-[#6E6A63]" />
                  <input
                    type="text"
                    placeholder={isAr ? 'بحث بالاسم أو البريد...' : 'Filter administrative team...'}
                    value={employeeSearch}
                    onChange={(e) => setEmployeeSearch(e.target.value)}
                    className="w-full bg-white border border-[#E9E7E2] text-xs px-4 py-2.5 pl-9 rounded-xl focus:outline-none focus:border-[#FF5A5F] text-[#1C1B18] shadow-sm"
                  />
                </div>

                <button 
                  onClick={() => setShowAddEmpModal(true)}
                  className="bg-[#FF5A5F] hover:bg-[#E04B50] text-white font-bold text-xs sm:text-sm px-5 py-2.5 rounded-xl shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer whitespace-nowrap"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>{isAr ? 'تعيين موظف إداري جديد' : 'Hire Administrative Employee'}</span>
                </button>
              </div>
            </div>

            {/* Platform Employee Cards Catalog */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredEmployees.map((emp) => {
                const isActive = emp.status === 'active';
                return (
                  <div 
                    key={emp.id} 
                    className={`bg-white border rounded-2xl p-5 relative overflow-hidden flex flex-col justify-between transition-all shadow-sm ${
                      isActive ? 'border-[#E9E7E2]' : 'border-[#FF5A5F]/20 opacity-80 shadow-inner'
                    }`}
                  >
                    <div className="space-y-4">
                      {/* Top Header Card */}
                      <div className="flex justify-between items-start">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-base ${
                          isActive ? 'bg-[#FF5A5F]/10 text-[#FF5A5F] border border-[#FF5A5F]/20' : 'bg-[#F6F6F4] text-[#6E6A63] border border-[#E9E7E2]'
                        }`}>
                          {emp.name.charAt(0)}
                        </div>

                        {/* Status button */}
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => handleToggleEmpStatus(emp.id)}
                            className={`px-2.5 py-1 rounded-lg text-[9px] font-bold border transition-all cursor-pointer ${
                              isActive 
                                ? 'bg-emerald-555/10 border-emerald-500/20 text-emerald-600 hover:bg-emerald-500/20' 
                                : 'bg-red-555/10 border-red-500/20 text-red-600 hover:bg-red-500/20'
                            }`}
                            title={isAr ? 'تغيير حالة النشاط' : 'Toggle status'}
                          >
                            {isActive ? (isAr ? 'نشط' : 'Active') : (isAr ? 'معلق' : 'Suspended')}
                          </button>

                          {/* Delete */}
                          <button
                            onClick={() => handleDeleteEmployee(emp.id)}
                            className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-550 text-red-600 hover:text-white border border-red-500/20 hover:border-transparent transition-all cursor-pointer"
                            title={isAr ? 'حذف من المنصة' : 'Remove from team'}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Name & Levels */}
                      <div>
                        <h4 className="font-bold text-[#14332B] text-base">{emp.name}</h4>
                        <span className={`inline-block px-2.5 py-1 rounded-lg text-[10px] font-bold border mt-1.5 uppercase tracking-wide ${getRoleBadgeColor(emp.role)}`}>
                          {getRoleLabel(emp.role)}
                        </span>
                      </div>

                      {/* Credentials */}
                      <div className="space-y-1.5 font-mono text-[11px] text-[#1C1B18] bg-[#F6F6F4] p-3 rounded-xl border border-[#E9E7E2]">
                        <div className="flex justify-between">
                          <span className="text-[#6E6A63]">EMAIL:</span>
                          <span className="text-[#14332B] font-bold truncate max-w-[150px]">{emp.email}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-[#6E6A63]">PHONE:</span>
                          <span className="text-[#FF5A5F] font-bold">{emp.phone}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-[#6E6A63]">HIRED:</span>
                          <span className="text-[#1C1B18] font-semibold">{new Date(emp.joinedAt).toLocaleDateString(isAr ? 'ar-SA' : 'en-US')}</span>
                        </div>
                      </div>

                      {/* Permissions Checklist Tiers */}
                      <div className="space-y-2">
                        <span className="text-[10px] text-[#6E6A63] uppercase font-bold block">{isAr ? 'الصلاحيات الممنوحة من المالك:' : 'Assigned Level Permissions:'}</span>
                        <div className="flex flex-wrap gap-1">
                          {emp.permissions.map((p) => (
                            <span 
                              key={p} 
                              className="px-2 py-0.5 rounded-md bg-[#F6F6F4] border border-[#E9E7E2] text-[9px] font-mono text-teal-800 font-bold"
                            >
                              ✓ {p.toUpperCase().replace('_', ' ')}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Platform Employee Hierarchy Levels chart */}
            <div className="bg-white border border-[#E9E7E2] rounded-[32px] p-6 space-y-4 shadow-sm">
              <h4 className="font-serif text-base font-bold text-[#14332B] flex items-center gap-1.5">
                <Layers className="w-5 h-5 text-[#FF5A5F]" />
                <span>{isAr ? 'سلم الرتب الوظيفية المعتمد في منصة CONFIRMED' : 'Approved Platform Level Hierarchy'}</span>
              </h4>
              <p className="text-xs text-[#6E6A63] leading-normal">
                {isAr 
                  ? 'تم بناء النظام السحابي بنظام أمني صارم (RBAC). يتم تحديد صلاحيات الوصول لكل رتبة كالتالي لمنع تسريب بيانات المتاجر والعملاء:' 
                  : 'Role-Based Access Control (RBAC) governs the cloud console to prevent security breaches or data spills:'}
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-2">
                <div className="bg-[#F6F6F4] border border-[#E9E7E2] p-4 rounded-xl space-y-2 text-xs">
                  <span className="font-bold text-purple-750 block font-serif">1. {isAr ? 'أدمن أول / Senior Admin' : 'Senior Admin / Master'}</span>
                  <p className="text-[11px] text-[#6E6A63] leading-normal">
                    {isAr ? 'صلاحيات مطلقة لإضافة الموظفين وتعديلهم وبث الإشعارات وتجميد وتفعيل حسابات الصالونات.' : 'Absolute platform command. Hires admins, controls portal settings & broadcast.'}
                  </p>
                </div>
                
                <div className="bg-[#F6F6F4] border border-[#E9E7E2] p-4 rounded-xl space-y-2 text-xs">
                  <span className="font-bold text-blue-750 block font-serif">2. {isAr ? 'مشرف عمليات / Operations' : 'Operations Supervisor'}</span>
                  <p className="text-[11px] text-[#6E6A63] leading-normal">
                    {isAr ? 'الموافقة على طلبات مزودي الخدمة الجدد ومتابعة مستنداتهم وتجميد أو فك حظر حسابات المتاجر.' : 'Approves new client tickets, monitors onboarding registries & locks.'}
                  </p>
                </div>

                <div className="bg-[#F6F6F4] border border-[#E9E7E2] p-4 rounded-xl space-y-2 text-xs">
                  <span className="font-bold text-amber-700 block font-serif">3. {isAr ? 'مسؤول تسويق / Marketing' : 'Marketing Specialist'}</span>
                  <p className="text-[11px] text-[#6E6A63] leading-normal">
                    {isAr ? 'بث الإشعارات والرسائل النصية والبريدية، وإعداد وتوليد العروض الترويجية وخصومات الاشتراكات.' : 'Handles broadcast engines, creates discount campaign structures & offers.'}
                  </p>
                </div>

                <div className="bg-[#F6F6F4] border border-[#E9E7E2] p-4 rounded-xl space-y-2 text-xs">
                  <span className="font-bold text-slate-700 block font-serif">4. {isAr ? 'دعم فني / Tech Support' : 'Technical Support'}</span>
                  <p className="text-[11px] text-[#6E6A63] leading-normal">
                    {isAr ? 'حق الاطلاع على تقارير المشاكل الفنية ومساعدة أصحاب الصالونات، وتحديث التذاكر الفنية.' : 'Read-only statistics hub, manages customer complaints & assists.'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ===== VIEW 3B: FINANCIALS REVENUE & PAYOUT HUB ===== */}
        {activeSubTab === 'financials' && (() => {
          const totalGMV = registeredProviders.reduce((acc, curr) => acc + (curr.totalSales || 0), 0);
          const totalPlatformCommission = Math.round(totalGMV * 0.1);
          const totalSubscriptionRev = registeredProviders.reduce((acc, curr) => acc + (curr.subscriptionPrice || 0), 0) + 18500;
          const totalPendingPayout = registeredProviders.reduce((acc, curr) => acc + (curr.pendingPayout || 0), 0);
          const totalPaidOut = registeredProviders.reduce((acc, curr) => acc + (curr.paidOut || 0), 0);
          const selectedInsightProv = registeredProviders.find(p => p.id === selectedInsightProvId) || registeredProviders[0] || {
            id: '',
            storeName: '',
            ownerName: '',
            phone: '',
            email: '',
            activity: '',
            status: 'active',
            joinedAt: new Date().toISOString(),
            subdomain: '',
            totalSales: 0,
            paidOut: 0,
            pendingPayout: 0,
            subscriptionTier: 'starter',
            subscriptionPrice: 399,
            subscriptionStatus: 'active',
            staffCount: 0,
            bookingsCount: 0,
            rating: 5.0
          };

          return (
            <div className="space-y-6 animate-fadeIn">
              
              {/* Top description banner */}
              <div className="bg-[#14332B] text-[#E9E7E2] rounded-[32px] p-6 md:p-8 relative overflow-hidden shadow-md">
                <div className="absolute right-0 top-0 w-64 h-64 bg-emerald-850 rounded-full blur-3xl opacity-20 pointer-events-none -mr-20 -mt-20" />
                <div className="relative z-10 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 bg-[#FF5A5F] text-white text-[10px] font-bold rounded-lg uppercase tracking-wide">
                      {isAr ? 'المركز المالي' : 'FINANCIAL HUB'}
                    </span>
                    <span className="text-[11px] text-[#FFAE34] font-bold font-mono tracking-wider uppercase">
                      ★ ISO-27001 AUDITED
                    </span>
                  </div>
                  <h2 className="font-serif text-xl md:text-2xl font-bold text-white">
                    {isAr ? 'منظومة إدارة الإيرادات، العمولات، وتسوية مستحقات مزودي الخدمة' : 'Platform Commissions, Subscriptions & Settlement Ledger'}
                  </h2>
                  <p className="text-xs md:text-sm text-[#A8B2AF] max-w-3xl leading-relaxed">
                    {isAr 
                      ? 'متابعة لحظية لحجم المبيعات الإجمالي للمتاجر (GMV)، استقطاع نسبة المنصة التلقائية (10%)، تحصيل فواتير الاشتراكات السحابية، وصرف الأرباح المباشرة لشركائنا بضغطة زر واحدة مع توثيق السجلات المشفرة.' 
                      : 'Real-time monitoring of Gross Merchandise Volume (GMV), system commissions (10%), cloud subscription billing, and seamless settlement releases to active partners with secure, immutable audit logs.'}
                  </p>
                </div>
              </div>

              {/* Dynamic Financial KPIs */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="bg-white border border-[#E9E7E2] rounded-3xl p-5 md:p-6 space-y-4 shadow-sm relative overflow-hidden">
                  <div className="absolute -right-2 -bottom-2 opacity-5">
                    <TrendingUp className="w-24 h-24 text-[#14332B]" />
                  </div>
                  <span className="text-[10px] text-[#6E6A63] block uppercase font-mono tracking-wider font-bold">
                    {isAr ? 'حجم المبيعات الإجمالي (GMV)' : 'PLATFORM GROSS VOLUME (GMV)'}
                  </span>
                  <div className="flex items-baseline gap-1">
                    <span className="text-2xl md:text-3xl font-black text-[#14332B] font-mono">
                      {totalGMV.toLocaleString()}
                    </span>
                    <span className="text-xs font-bold text-[#6E6A63]">{isAr ? 'ريال' : 'SAR'}</span>
                  </div>
                  <div className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                    <span>{isAr ? 'مبيعات حية من الصالونات' : 'Active live flow from storefronts'}</span>
                  </div>
                </div>

                <div className="bg-white border border-[#E9E7E2] rounded-3xl p-5 md:p-6 space-y-4 shadow-sm relative overflow-hidden">
                  <div className="absolute -right-2 -bottom-2 opacity-5">
                    <DollarSign className="w-24 h-24 text-emerald-800" />
                  </div>
                  <span className="text-[10px] text-[#6E6A63] block uppercase font-mono tracking-wider font-bold">
                    {isAr ? 'حصة المنصة من العمولات (10%)' : 'SYSTEM COMMISSION (10%)'}
                  </span>
                  <div className="flex items-baseline gap-1">
                    <span className="text-2xl md:text-3xl font-black text-emerald-800 font-mono">
                      {totalPlatformCommission.toLocaleString()}
                    </span>
                    <span className="text-xs font-bold text-[#6E6A63]">{isAr ? 'ريال' : 'SAR'}</span>
                  </div>
                  <div className="text-[11px] text-[#6E6A63] font-semibold">
                    <span>{isAr ? 'المبلغ الصافي المستحق للمنصة' : 'Net calculated commission share'}</span>
                  </div>
                </div>

                <div className="bg-white border border-[#E9E7E2] rounded-3xl p-5 md:p-6 space-y-4 shadow-sm relative overflow-hidden">
                  <div className="absolute -right-2 -bottom-2 opacity-5">
                    <CreditCard className="w-24 h-24 text-teal-800" />
                  </div>
                  <span className="text-[10px] text-[#6E6A63] block uppercase font-mono tracking-wider font-bold">
                    {isAr ? 'إيرادات الاشتراكات المحصلة' : 'COLLECTED SUBSCRIPTION FEES'}
                  </span>
                  <div className="flex items-baseline gap-1">
                    <span className="text-2xl md:text-3xl font-black text-teal-800 font-mono">
                      {totalSubscriptionRev.toLocaleString()}
                    </span>
                    <span className="text-xs font-bold text-[#6E6A63]">{isAr ? 'ريال' : 'SAR'}</span>
                  </div>
                  <div className="text-[11px] text-[#FF5A5F] font-semibold">
                    <span>{isAr ? 'تحصيل شهري تلقائي مستمر' : 'SaaS monthly recurring fee base'}</span>
                  </div>
                </div>

                <div className="bg-white border border-[#E9E7E2] rounded-3xl p-5 md:p-6 space-y-4 shadow-sm relative overflow-hidden">
                  <div className="absolute -right-2 -bottom-2 opacity-5">
                    <Clock className="w-24 h-24 text-amber-700" />
                  </div>
                  <span className="text-[10px] text-[#6E6A63] block uppercase font-mono tracking-wider font-bold">
                    {isAr ? 'أرباح معلقة بانتظار التسوية' : 'PENDING PARTNER PAYOUTS'}
                  </span>
                  <div className="flex items-baseline gap-1">
                    <span className="text-2xl md:text-3xl font-black text-amber-700 font-mono">
                      {totalPendingPayout.toLocaleString()}
                    </span>
                    <span className="text-xs font-bold text-[#6E6A63]">{isAr ? 'ريال' : 'SAR'}</span>
                  </div>
                  <div className="text-[11px] text-[#FFAE34] font-semibold flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span>{isAr ? 'بانتظار الصرف اليدوي للأدمن' : 'Awaiting manual admin release'}</span>
                  </div>
                </div>
              </div>

              {/* Main Ledger & Interactive Detail Columns */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                
                {/* PARTNERS FINANCIAL LEDGER (Left - 7 cols) */}
                <div className="lg:col-span-7 bg-white border border-[#E9E7E2] rounded-[32px] p-6 space-y-6 shadow-sm">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                    <div>
                      <h3 className="font-serif text-base font-bold text-[#14332B]">
                        {isAr ? 'دفتر مستحقات الشركاء وتسوية مبيعات الفروع' : 'Partners Ledger & Settlement Sheet'}
                      </h3>
                      <p className="text-xs text-[#6E6A63]">
                        {isAr ? 'استعرض مبيعات الشركاء، النسبة المخصومة، المبالغ المحولة، والعمليات بضغطة واحدة.' : 'Monitor total sales, commission cuts, released funds, and process pending settlements.'}
                      </p>
                    </div>
                  </div>

                  <div className="overflow-x-auto border border-[#E9E7E2] rounded-2xl">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="bg-[#F6F6F4] text-[#6E6A63] font-bold font-mono border-b border-[#E9E7E2]">
                          <th className="p-3.5 text-right">{isAr ? 'الصالون ومستوى الاشتراك' : 'STORE / SUBSCRIPTION'}</th>
                          <th className="p-3.5 text-center font-mono">{isAr ? 'إجمالي المبيعات' : 'SALES (GMV)'}</th>
                          <th className="p-3.5 text-center font-mono">{isAr ? 'العمولة المستقطعة' : 'COMM. (10%)'}</th>
                          <th className="p-3.5 text-center font-mono">{isAr ? 'معلق للصرف' : 'PENDING'}</th>
                          <th className="p-3.5 text-center">{isAr ? 'الإجراء المالي' : 'ACTION'}</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#E9E7E2]">
                        {registeredProviders.map(prov => {
                          const totalSales = prov.totalSales || 0;
                          const comm = Math.round(totalSales * 0.1);
                          const pendingPayout = prov.pendingPayout || 0;
                          const subscriptionTier = prov.subscriptionTier || 'starter';
                          return (
                            <tr key={prov.id} className="hover:bg-[#F6F6F4]/50 transition-colors">
                              <td className="p-3.5 text-right">
                                <div className="space-y-1">
                                  <div className="font-bold text-[#14332B] text-xs flex items-center gap-1.5 justify-start">
                                    <span className={`w-2 h-2 rounded-full ${prov.status === 'active' ? 'bg-emerald-500' : 'bg-red-400'}`} />
                                    <span>{prov.storeName}</span>
                                  </div>
                                  <div className="flex gap-1.5 items-center">
                                    <span className="text-[10px] text-[#6E6A63] font-mono uppercase">
                                      {prov.subdomain}.confirmed.sa
                                    </span>
                                    <span className={`px-1.5 py-0.5 rounded text-[8px] font-bold uppercase ${
                                      subscriptionTier === 'enterprise' 
                                        ? 'bg-purple-100 text-purple-800 border border-purple-200' 
                                        : subscriptionTier === 'pro'
                                        ? 'bg-blue-100 text-blue-800 border border-blue-200'
                                        : 'bg-slate-100 text-slate-800 border border-slate-200'
                                    }`}>
                                      {subscriptionTier}
                                    </span>
                                  </div>
                                </div>
                              </td>
                              <td className="p-3.5 text-center font-mono font-bold text-[#1C1B18]">
                                {totalSales.toLocaleString()} {isAr ? 'ريال' : 'SAR'}
                              </td>
                              <td className="p-3.5 text-center font-mono text-[#6E6A63]">
                                {comm.toLocaleString()} {isAr ? 'ريال' : 'SAR'}
                              </td>
                              <td className="p-3.5 text-center font-mono">
                                <span className={pendingPayout > 0 ? 'text-amber-700 font-bold' : 'text-[#9E9E9E]'}>
                                  {pendingPayout.toLocaleString()} {isAr ? 'ريال' : 'SAR'}
                                </span>
                              </td>
                              <td className="p-3.5 text-center">
                                {pendingPayout > 0 ? (
                                  <button
                                    onClick={() => handleSettlePayout(prov.id)}
                                    className="bg-[#14332B] hover:bg-[#FF5A5F] text-[#E9E7E2] hover:text-white border border-transparent px-3 py-1.5 rounded-lg text-[11px] font-bold transition-all cursor-pointer shadow-sm flex items-center gap-1 mx-auto"
                                  >
                                    <RefreshCw className="w-3 h-3" />
                                    <span>{isAr ? 'تسوية المستحقات' : 'Settle'}</span>
                                  </button>
                                ) : (
                                  <span className="inline-flex items-center gap-1 text-emerald-600 font-bold text-[10px] bg-emerald-50 px-2 py-1 rounded-lg border border-emerald-100 justify-center">
                                    <Check className="w-3.5 h-3.5" />
                                    <span>{isAr ? 'تمت التسوية' : 'Settled'}</span>
                                  </span>
                                )}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>

                  {/* Financial Disclaimer Alert */}
                  <div className="bg-[#F6F6F4] border border-[#E9E7E2] p-4 rounded-2xl flex gap-3 items-start text-xs text-[#6E6A63] leading-normal">
                    <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                    <div className="space-y-1">
                      <span className="font-bold text-[#14332B] block">{isAr ? 'بروتوكول تحويل وحماية الأرباح المعتمد' : 'Provider Security & Vault Protocols'}</span>
                      <p>
                        {isAr 
                          ? 'يتم تنفيذ جميع التسويات المصرفية والتحويلات عبر بوابات دفع محلية مرخصة من البنك المركزي السعودي (SAMA). يتم ترحيل العمليات تلقائياً إلى نظام الفوترة والتحقق السحابي لمنع النزاعات.'
                          : 'All system payouts and cash movements are cleared through central banking protocols complying with Saudi Arabian Monetary Authority (SAMA) standards. Transactions write instantly into the cloud ledger to secure auditing.'}
                      </p>
                    </div>
                  </div>
                </div>

                {/* OPERATIONAL & SUBSCRIPTION INSIGHT ENGINE (Right - 5 cols) */}
                <div className="lg:col-span-5 bg-white border border-[#E9E7E2] rounded-[32px] p-6 space-y-6 shadow-sm">
                  <div>
                    <h3 className="font-serif text-base font-bold text-[#14332B] flex items-center gap-1.5">
                      <SlidersHorizontal className="w-5 h-5 text-[#FF5A5F]" />
                      <span>{isAr ? 'محرك استعراض المؤشرات والاشتراكات' : 'Operational & SaaS Controller'}</span>
                    </h3>
                    <p className="text-xs text-[#6E6A63] mt-1">
                      {isAr ? 'اختر أي شريك لاستعراض تفاصيله التشغيلية الدقيقة وتعديل خطة اشتراكه السحابي.' : 'Select any registered partner to oversee their health indices and update their SaaS subscription level.'}
                    </p>
                  </div>

                  {/* Select Dropdown */}
                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-[#1C1B18]">{isAr ? 'اختر مزود الخدمة المستهدف *' : 'Select Targeted Partner *'}</label>
                    <select
                      value={selectedInsightProvId}
                      onChange={(e) => setSelectedInsightProvId(e.target.value)}
                      className="w-full bg-[#F6F6F4] border border-[#E9E7E2] rounded-xl px-3.5 py-3 text-xs font-bold text-[#14332B] focus:outline-none focus:ring-1 focus:ring-[#FF5A5F] focus:border-[#FF5A5F]"
                    >
                      {registeredProviders.map(p => (
                        <option key={p.id} value={p.id}>{p.storeName}</option>
                      ))}
                    </select>
                  </div>

                  {/* Operational Health Bento Grid */}
                  <div className="bg-[#F6F6F4] border border-[#E9E7E2] p-5 rounded-2xl space-y-4">
                    <div className="flex justify-between items-start border-b border-[#E9E7E2] pb-3">
                      <div>
                        <h4 className="font-bold text-[#14332B] text-sm">{selectedInsightProv.storeName}</h4>
                        <span className="text-[10px] text-[#6E6A63] font-mono block mt-0.5">{isAr ? 'المالك:' : 'Owner:'} {selectedInsightProv.ownerName}</span>
                      </div>
                      <span className={`px-2.5 py-1 rounded-full text-[9px] font-mono font-bold uppercase border ${
                        selectedInsightProv.status === 'active' 
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-100' 
                          : 'bg-red-50 text-red-700 border-red-100'
                      }`}>
                        {selectedInsightProv.status}
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-3 text-center">
                      <div className="bg-white border border-[#E9E7E2] p-2.5 rounded-xl space-y-1">
                        <span className="text-[9px] text-[#6E6A63] block uppercase font-mono">{isAr ? 'طاقم العمل' : 'STAFF'}</span>
                        <span className="text-sm font-black text-[#14332B] font-mono">{selectedInsightProv.staffCount}</span>
                      </div>
                      <div className="bg-white border border-[#E9E7E2] p-2.5 rounded-xl space-y-1">
                        <span className="text-[9px] text-[#6E6A63] block uppercase font-mono">{isAr ? 'الحجوزات' : 'BOOKINGS'}</span>
                        <span className="text-sm font-black text-emerald-800 font-mono">{selectedInsightProv.bookingsCount}</span>
                      </div>
                      <div className="bg-white border border-[#E9E7E2] p-2.5 rounded-xl space-y-1">
                        <span className="text-[9px] text-[#6E6A63] block uppercase font-mono">{isAr ? 'التقييم' : 'RATING'}</span>
                        <span className="text-sm font-black text-[#FFAE34] font-mono">★ {selectedInsightProv.rating}</span>
                      </div>
                    </div>

                    <div className="space-y-1.5 text-[11px] text-[#6E6A63] font-mono pt-1">
                      <div className="flex justify-between">
                        <span>{isAr ? 'بريد المالك:' : 'OWNER EMAIL:'}</span>
                        <span className="text-[#1C1B18] font-bold">{selectedInsightProv.email}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>{isAr ? 'هاتف التواصل:' : 'CONTACT PHONE:'}</span>
                        <span className="text-[#1C1B18] font-bold">{selectedInsightProv.phone}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>{isAr ? 'تاريخ الانضمام:' : 'JOINED SINCE:'}</span>
                        <span className="text-[#1C1B18] font-bold">
                          {new Date(selectedInsightProv.joinedAt).toLocaleDateString(isAr ? 'ar-SA' : 'en-US')}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* ACTIVE SaaS SUBSCRIPTION ADJUSTER */}
                  <div className="space-y-4 border-t border-[#E9E7E2] pt-4">
                    <h4 className="font-bold text-[#14332B] text-xs uppercase tracking-wider flex items-center gap-1">
                      <CreditCard className="w-4 h-4 text-[#FF5A5F]" />
                      <span>{isAr ? 'تعديل باقة الاشتراك والفواتير السحابية' : 'Manage Subscription & Live SaaS Billing'}</span>
                    </h4>

                    {/* Subscription tier parameters */}
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] font-bold text-[#6E6A63] mb-1.5 uppercase font-mono">{isAr ? 'باقة الاشتراك' : 'SaaS Level Tier'}</label>
                        <select
                          value={selectedInsightProv.subscriptionTier}
                          onChange={(e) => handleUpdateSubscription(
                            selectedInsightProv.id, 
                            e.target.value as 'starter' | 'pro' | 'enterprise',
                            selectedInsightProv.subscriptionStatus
                          )}
                          className="w-full bg-[#F6F6F4] border border-[#E9E7E2] rounded-xl px-3.5 py-2.5 text-xs font-bold text-[#14332B] focus:outline-none"
                        >
                          <option value="starter">{isAr ? 'الباقة الأساسية (399 ريال)' : 'Starter Plan (399 SAR)'}</option>
                          <option value="pro">{isAr ? 'الباقة المتقدمة (799 ريال)' : 'Pro Plan (799 SAR)'}</option>
                          <option value="enterprise">{isAr ? 'باقة الشريك القيادي (1499 ريال)' : 'Enterprise Plan (1499 SAR)'}</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-[#6E6A63] mb-1.5 uppercase font-mono">{isAr ? 'حالة السداد والفوترة' : 'Billing Status'}</label>
                        <select
                          value={selectedInsightProv.subscriptionStatus}
                          onChange={(e) => handleUpdateSubscription(
                            selectedInsightProv.id, 
                            selectedInsightProv.subscriptionTier,
                            e.target.value as 'active' | 'overdue' | 'trial'
                          )}
                          className="w-full bg-[#F6F6F4] border border-[#E9E7E2] rounded-xl px-3.5 py-2.5 text-xs font-bold text-[#14332B] focus:outline-none"
                        >
                          <option value="active">✓ {isAr ? 'نشط ومدفوع' : 'Active / Paid'}</option>
                          <option value="overdue">⚠ {isAr ? 'متأخرات معلقة' : 'Overdue Billing'}</option>
                          <option value="trial">⚡ {isAr ? 'فترة تجريبية' : 'Trial Active'}</option>
                        </select>
                      </div>
                    </div>

                    {/* Direct broadcast trigger shortcut */}
                    <div className="pt-2">
                      <button
                        onClick={() => {
                          setBroadcastTarget('providers');
                          setBroadcastTitle(isAr ? `تحديث فوري لصالون ${selectedInsightProv.storeName}` : `Action Alert for ${selectedInsightProv.storeName}`);
                          setBroadcastMessage(isAr 
                            ? `تحية طيبة، تفخر منصة كُونفيرمد بشراكتكم. نود تذكيركم بأن خطة اشتراككم الحالية هي الباقة (${selectedInsightProv.subscriptionTier.toUpperCase()}) بفوترة قيمتها ${selectedInsightProv.subscriptionPrice} ريال.`
                            : `Hello, we highly value your partner relationship. A friendly update that your store currently rides on the ${selectedInsightProv.subscriptionTier.toUpperCase()} SaaS Tier billed at SAR ${selectedInsightProv.subscriptionPrice}/mo.`);
                          setActiveSubTab('broadcast');
                        }}
                        className="w-full text-center bg-white hover:bg-[#F6F6F4] text-[#14332B] border border-[#E9E7E2] hover:border-[#6E6A63] px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5"
                      >
                        <Megaphone className="w-3.5 h-3.5 text-[#FF5A5F]" />
                        <span>{isAr ? 'إرسال تنبيه فوترة فردي لهذا الصالون' : 'Send targeted alert to this salon'}</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* RECENT FINANCIAL TRANSACTIONS IMMUTABLE LOGS */}
              <div className="bg-white border border-[#E9E7E2] rounded-[32px] p-6 space-y-4 shadow-sm">
                <div className="flex justify-between items-center">
                  <h4 className="font-serif text-base font-bold text-[#14332B] flex items-center gap-1.5">
                    <FileText className="w-5 h-5 text-[#FF5A5F]" />
                    <span>{isAr ? 'سجل المعاملات والعمليات المالية والتحويلات السحابية' : 'Platform Financial Settlement Log'}</span>
                  </h4>
                  <span className="font-mono text-[10px] text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-100 font-bold">
                    ✓ {financialLogs.length} {isAr ? 'عمليات موثقة' : 'AUDITED LOGS'}
                  </span>
                </div>

                <div className="overflow-x-auto border border-[#E9E7E2] rounded-2xl">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-[#F6F6F4] text-[#6E6A63] font-bold font-mono border-b border-[#E9E7E2]">
                        <th className="p-3 text-right">{isAr ? 'المرجع والتحويل' : 'REFERENCE'}</th>
                        <th className="p-3 text-right">{isAr ? 'المزود / الصالون المستهدف' : 'TARGET PARTNER'}</th>
                        <th className="p-3 text-center">{isAr ? 'نوع المعاملة' : 'TRANSACTION TYPE'}</th>
                        <th className="p-3 text-center font-mono">{isAr ? 'المبلغ' : 'AMOUNT'}</th>
                        <th className="p-3 text-center font-mono">{isAr ? 'الوقت والتاريخ' : 'TIMESTAMP'}</th>
                        <th className="p-3 text-center">{isAr ? 'حالة القيد' : 'STATUS'}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#E9E7E2] font-mono text-[11px]">
                      {financialLogs.map((log: any) => (
                        <tr key={log.id} className="hover:bg-[#F6F6F4]/50">
                          <td className="p-3 text-right font-bold text-[#14332B]">{log.ref}</td>
                          <td className="p-3 text-right text-xs font-sans font-bold text-[#1C1B18]">{log.providerName}</td>
                          <td className="p-3 text-center font-sans">
                            {log.type === 'settlement' ? (
                              <span className="px-2 py-0.5 rounded bg-emerald-50 border border-emerald-200 text-emerald-800 text-[10px] font-bold">
                                {isAr ? 'صرف مستحقات' : 'Settlement Release'}
                              </span>
                            ) : log.type === 'subscription_change' ? (
                              <span className="px-2 py-0.5 rounded bg-purple-50 border border-purple-200 text-purple-800 text-[10px] font-bold">
                                {isAr ? 'تعديل الباقة السحابية' : 'Subscription Modified'}
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded bg-blue-50 border border-blue-200 text-blue-800 text-[10px] font-bold">
                                {isAr ? 'تجديد اشتراك تلقائي' : 'Recurring Subscription'}
                              </span>
                            )}
                          </td>
                          <td className="p-3 text-center font-bold text-[#1C1B18]">
                            {log.amount.toLocaleString()} {isAr ? 'ريال' : 'SAR'}
                          </td>
                          <td className="p-3 text-center text-[#6E6A63]">
                            {new Date(log.date).toLocaleString(isAr ? 'ar-SA' : 'en-US')}
                          </td>
                          <td className="p-3 text-center">
                            <span className="text-emerald-600 font-bold flex items-center gap-1 justify-center font-sans text-[10px]">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                              <span>{isAr ? 'مكتمل' : 'Cleared'}</span>
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          );
        })()}

        {/* ===== VIEW 4: BROADCAST COMMUNICATION CENTER ===== */}
        {activeSubTab === 'broadcast' && (
          <div className="space-y-6 animate-fadeIn grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Left broadcast dispatch form */}
            <div className="lg:col-span-7 bg-white border border-[#E9E7E2] rounded-[32px] p-6 md:p-8 space-y-6 shadow-sm">
              <div>
                <h3 className="font-serif text-lg font-bold text-[#14332B] flex items-center gap-1.5">
                  <Megaphone className="w-5 h-5 text-[#FF5A5F]" />
                  <span>{isAr ? 'بوابة البث المركزي وتوليد الحملات الإعلانية' : 'Central Broadcast Campaign Launcher'}</span>
                </h3>
                <p className="text-xs text-[#6E6A63] mt-1">
                  {isAr 
                    ? 'أرسلي تنبيهات، تحديثات، عروض، أو تنبيهات اشتراكات فورية للمزودين والعملاء مباشرة.' 
                    : 'Dispatch instant alerts, subscription reminders, or discount banners to targeted databases.'}
                </p>
              </div>

              <form onSubmit={handleSendBroadcast} className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-[#1C1B18] mb-2">{isAr ? 'الفئة المستهدفة *' : 'Target Database Audience *'}</label>
                    <select
                      value={broadcastTarget}
                      onChange={(e) => setBroadcastTarget(e.target.value as any)}
                      className="w-full bg-white border border-[#E9E7E2] text-xs px-4 py-3 rounded-xl focus:outline-none focus:border-[#FF5A5F] text-[#1C1B18] shadow-sm"
                    >
                      <option value="all">{isAr ? 'الجميع (المزودين + العميلات)' : 'All (Providers + Clients)'}</option>
                      <option value="providers">{isAr ? 'المزودين فقط (أصحاب الصالونات)' : 'Registered Providers Only'}</option>
                      <option value="clients">{isAr ? 'العميلات فقط (قاعدة بيانات الحجز)' : 'Beauty Clients Only'}</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#1C1B18] mb-2">{isAr ? 'قنوات الإرسال والبث *' : 'Delivery Gateway Channels *'}</label>
                    <select
                      value={broadcastChannel}
                      onChange={(e) => setBroadcastChannel(e.target.value as any)}
                      className="w-full bg-white border border-[#E9E7E2] text-xs px-4 py-3 rounded-xl focus:outline-none focus:border-[#FF5A5F] text-[#1C1B18] shadow-sm"
                    >
                      <option value="both">{isAr ? 'قناة مزدوجة (إيميل + رسائل نصية SMS)' : 'Dual Channel (Email + SMS)'}</option>
                      <option value="email">{isAr ? 'الحملات البريدية السحابية فقط (Email)' : 'Cloud Email Delivery Only'}</option>
                      <option value="sms">{isAr ? 'بث الرسائل النصية القصيرة فقط (SMS)' : 'SMS Phone Broadcast Only'}</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#1C1B18] mb-2">{isAr ? 'عنوان الحملة / التنبيه الموحد *' : 'Campaign Subject / Email Header *'}</label>
                  <input
                    type="text"
                    required
                    value={broadcastTitle}
                    onChange={(e) => setBroadcastTitle(e.target.value)}
                    placeholder={isAr ? "مثال: ترقية برمجية كبرى لنظام الكاشير اليوم الساعة ١ صباحاً" : "e.g. Scheduled Core Service Maintenance tonight at 1:00 AM"}
                    className="w-full bg-white border border-[#E9E7E2] text-xs px-4 py-3 rounded-xl focus:outline-none focus:border-[#FF5A5F] text-[#1C1B18] font-medium shadow-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#1C1B18] mb-2">
                    {isAr ? 'نص الرسالة / تفاصيل العرض الترويجي والتنبيه *' : 'SMS Nudge Message / Email Body Content *'}
                  </label>
                  <textarea
                    required
                    rows={4}
                    value={broadcastMessage}
                    onChange={(e) => setBroadcastMessage(e.target.value)}
                    placeholder={isAr ? "اكتبي محتوى الرسالة بدقة، يمكنك تزويدهم بأكواد الخصم أو تفاصيل الترقية..." : "Type clear details of your platform campaign or system alert..."}
                    className="w-full bg-white border border-[#E9E7E2] text-xs px-4 py-3 rounded-xl focus:outline-none focus:border-[#FF5A5F] text-[#1C1B18] leading-relaxed shadow-sm"
                  />
                  <p className="text-[10px] text-[#6E6A63] mt-1 font-medium">
                    * {isAr ? 'سيتم توليد تنبيهات مشفرة ومطابقة وإرسالها سحابياً فور إطلاق الحملة.' : 'Dispatched messages conform to security encryption compliance guidelines.'}
                  </p>
                </div>

                <button
                  type="submit"
                  className="w-full py-4 bg-gradient-to-r from-[#FF5A5F] to-[#FFAE34] hover:from-[#E04B50] hover:to-[#E59C2E] text-white font-bold text-sm rounded-xl shadow-lg shadow-[#FF5A5F]/10 hover:shadow-[#FF5A5F]/20 transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <Send className="w-4 h-4 text-white" />
                  <span>{isAr ? 'إطلاق وبث الحملة الإعلانية فوراً 🚀' : 'Launch Central Broadcast Campaign 🚀'}</span>
                </button>
              </form>
            </div>

            {/* Right real-time simulated devices log */}
            <div className="lg:col-span-5 space-y-6">
              
              {/* Campaign Dispatched History Log */}
              <div className="bg-white border border-[#E9E7E2] rounded-[32px] p-5 space-y-4 shadow-sm">
                <h4 className="font-serif text-sm font-bold text-[#14332B] flex items-center gap-1.5">
                  <Database className="w-4 h-4 text-indigo-650" />
                  <span>{isAr ? 'أرشيف وتاريخ الحملات الصادرة' : 'Issued Broadcast History'}</span>
                </h4>

                <div className="space-y-3 max-h-56 overflow-y-auto pr-1">
                  {campaignLogs.map((log) => (
                    <div key={log.id} className="bg-[#F6F6F4] border border-[#E9E7E2] p-3.5 rounded-xl space-y-2 text-xs">
                      <div className="flex justify-between items-start">
                        <span className="font-bold text-[#14332B] truncate max-w-[170px]" title={log.title}>{log.title}</span>
                        <span className="text-[9px] px-2 py-0.5 rounded bg-emerald-55/10 border border-emerald-500/20 text-emerald-700 font-mono font-bold">
                          {log.status.toUpperCase()}
                        </span>
                      </div>

                      <div className="flex justify-between items-center text-[10px] text-[#6E6A63] font-mono font-medium">
                        <span>👥 {log.target}</span>
                        <span>✉️ {log.channel}</span>
                      </div>

                      <div className="pt-2 border-t border-dashed border-[#E9E7E2] flex justify-between text-[10px] text-[#6E6A63] font-mono">
                        <span>{new Date(log.sentAt).toLocaleDateString(isAr ? 'ar-SA' : 'en-US')}</span>
                        <span className="text-emerald-700 font-bold">{isAr ? `المستلمين: ${log.count}` : `Recipients: ${log.count}`}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Simulated Device Live Mail/SMS Feeder */}
              {simulatedDispatch.length > 0 && (
                <div className="bg-white border border-emerald-500/20 rounded-[32px] p-5 space-y-3 relative overflow-hidden animate-fadeIn shadow-sm">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none" />
                  
                  <div className="flex justify-between items-center pb-2 border-b border-[#E9E7E2]">
                    <span className="text-xs font-bold text-emerald-700 flex items-center gap-1.5">
                      <Smartphone className="w-4 h-4 text-emerald-600" />
                      {isAr ? 'محاكي أجهزة المستلمين (مباشر)' : 'Recipient Sandbox Simulation (LIVE)'}
                    </span>
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                  </div>

                  <div className="space-y-3 max-h-60 overflow-y-auto font-mono text-[11px] pr-1">
                    {simulatedDispatch.map((disp, i) => (
                      <div key={i} className="p-3 rounded-xl bg-[#F6F6F4] border border-[#E9E7E2] space-y-1">
                        <div className="flex justify-between text-[#6E6A63] text-[10px] font-medium">
                          <span>{disp.type === 'sms' ? '💬 SMS GATEWAY' : '📧 SMTP MAIL'}</span>
                          <span>{disp.timestamp}</span>
                        </div>
                        <div className="text-[#FF5A5F] font-bold">TO: {disp.recipient}</div>
                        <p className="text-[#1C1B18] leading-relaxed font-sans">{disp.message}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ===== VIEW 3F: DYNAMIC SUBSCRIPTION PLAN CONFIGURATOR ===== */}
        {activeSubTab === 'packages' && (
          <div className="space-y-6 animate-fadeIn">
            {/* Top description banner */}
            <div className="bg-[#14332B] text-[#E9E7E2] rounded-[32px] p-6 md:p-8 relative overflow-hidden shadow-md">
              <div className="absolute right-0 top-0 w-64 h-64 bg-emerald-850 rounded-full blur-3xl opacity-20 pointer-events-none -mr-20 -mt-20" />
              <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 bg-[#FF5A5F] text-white text-[10px] font-bold rounded-lg uppercase tracking-wide">
                      {isAr ? 'عروض وباقات النظام' : 'SUBSCRIPTION OFFERINGS'}
                    </span>
                    <span className="text-[11px] text-[#FFAE34] font-bold font-mono tracking-wider uppercase">
                      ★ LIVE SYNC
                    </span>
                  </div>
                  <h2 className="font-serif text-xl md:text-2xl font-bold text-white">
                    {isAr ? 'إدارة وتخصيص باقات اشتراكات المنصة' : 'Subscription Plans Design & Calibration Portal'}
                  </h2>
                  <p className="text-xs md:text-sm text-[#A8B2AF] max-w-3xl leading-relaxed">
                    {isAr 
                      ? 'بصفتك مالك المنصة، يمكنك إضافة وتعديل باقات الاشتراك السحابية وتحديد ميزاتها الفنية وأسعارها بدقة عالية. أي تحديث للباقات سينعكس فوراً وتلقائياً على الصفحة الرئيسية في قسم الأسعار ليتمكن المستخدمون الجدد من تحديدها مباشرة والدفع والاشتراك.' 
                      : 'Create, edit, or retire SaaS subscription offerings. Instantly publish pricing tiers with complete control over descriptive feature catalogs, billing amounts, and badges. Changes propagate live on the public Landing Page pricing carousel.'}
                  </p>
                </div>

                <button
                  onClick={handleOpenAddPackage}
                  className="bg-[#FF5A5F] hover:bg-[#E04B50] text-white px-5 py-3 rounded-2xl text-xs font-bold transition-all cursor-pointer flex items-center gap-2 shrink-0 shadow-lg shadow-[#FF5A5F]/20"
                >
                  <Plus className="w-4 h-4 text-white" />
                  <span>{isAr ? 'إضافة باقة جديدة' : 'Add New Plan'}</span>
                </button>
              </div>
            </div>

            {/* Packages Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {packages?.map((pkg) => (
                <div 
                  key={pkg.id} 
                  className={`bg-white border rounded-[32px] p-6 space-y-6 shadow-sm relative flex flex-col justify-between transition-all hover:shadow-md ${
                    pkg.isPopular ? 'border-[#FF5A5F] ring-1 ring-[#FF5A5F]/35' : 'border-[#E9E7E2]'
                  }`}
                >
                  {pkg.isPopular && (
                    <span className="absolute -top-3.5 right-6 bg-[#FF5A5F] text-white text-[9px] font-bold px-3 py-1 rounded-full uppercase tracking-wider shadow-sm">
                      {isAr ? 'الأكثر طلباً' : 'MOST POPULAR'}
                    </span>
                  )}

                  {pkg.isEnterpriseContact && (
                    <span className="absolute -top-3.5 left-6 bg-[#14332B] text-white text-[9px] font-bold px-3 py-1 rounded-full uppercase tracking-wider shadow-sm">
                      {isAr ? 'تخصيص كامل' : 'ENTERPRISE'}
                    </span>
                  )}

                  <div className="space-y-4">
                    <div className="space-y-1">
                      <h3 className="font-serif text-lg font-bold text-[#14332B]">
                        {isAr ? pkg.nameAr : pkg.nameEn}
                      </h3>
                      <p className="text-xs text-[#6E6A63] leading-relaxed">
                        {isAr ? pkg.descriptionAr : pkg.descriptionEn}
                      </p>
                    </div>

                    <div className="border-t border-[#F6F6F4] pt-4 space-y-1">
                      <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider">
                        {isAr ? 'قيمة الاشتراك والتعرفة' : 'PLAN PLAN RATE'}
                      </span>
                      {pkg.isEnterpriseContact ? (
                        <div className="text-xl font-bold text-[#14332B] font-serif">
                          {isAr ? 'تواصل معنا' : 'Contact Us'}
                        </div>
                      ) : (
                        <div className="flex items-baseline gap-1">
                          <span className="text-2xl font-serif font-black text-[#FF5A5F] font-mono">
                            {pkg.priceMonthly}
                          </span>
                          <span className="text-xs text-[#6E6A63] font-bold">
                            {isAr ? 'ر.س' : 'SAR'} / {isAr ? 'شهر' : 'mo'}
                          </span>
                          <span className="text-[10px] text-slate-400 font-medium mr-1.5 rtl:mr-1.5">
                            ({isAr ? 'السنوي:' : 'Yearly:'} {pkg.priceYearly} {isAr ? 'ر.س/شهر' : 'SAR/mo'})
                          </span>
                        </div>
                      )}
                    </div>

                    <div className="border-t border-[#F6F6F4] pt-4 space-y-3">
                      <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider">
                        {isAr ? 'الميزات والخصائص التقنية' : 'INCLUDED IN PLAN'}
                      </span>
                      <ul className="space-y-2 text-xs text-slate-700">
                        {(isAr ? pkg.featuresAr : pkg.featuresEn)?.map((feat, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <Check className="w-3.5 h-3.5 text-[#FF5A5F] shrink-0 mt-0.5" />
                            <span>{feat}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="border-t border-[#F6F6F4] pt-4 flex gap-2.5">
                    <button
                      onClick={() => handleOpenEditPackage(pkg)}
                      className="flex-1 py-2.5 bg-[#F6F6F4] hover:bg-[#FF5A5F] text-[#14332B] hover:text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <span>{isAr ? 'تعديل الباقة' : 'Edit Plan'}</span>
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(isAr ? 'هل أنتِ متأكدة من حذف باقة الاشتراك هذه؟ سيتم إزالتها فوراً من الصفحة الرئيسية.' : 'Are you sure you want to permanently delete this plan? It will immediately disappear from the homepage pricing carousel.')) {
                          onDeletePackage(pkg.id);
                        }
                      }}
                      className="p-2.5 bg-red-50 hover:bg-red-500 text-red-600 hover:text-white rounded-xl text-xs font-bold transition-all cursor-pointer"
                      title={isAr ? 'حذف الباقة' : 'Delete Plan'}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* ===== 5. EMPLOYEE ADD PROGRESSIVE MODAL ===== */}
      {showAddEmpModal && (
        <div className="fixed inset-0 bg-[#000]/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-white border border-[#E9E7E2] text-[#1C1B18] rounded-[32px] w-full max-w-lg p-6 sm:p-8 shadow-2xl relative overflow-hidden">
            <button 
              onClick={() => setShowAddEmpModal(false)}
              className="absolute top-4 left-4 p-2 rounded-full hover:bg-[#F6F6F4] text-[#6E6A63] hover:text-[#14332B] cursor-pointer"
              title={isAr ? 'إغلاق' : 'Close'}
            >
              <Plus className="w-5 h-5 rotate-45" />
            </button>

            <div className="mb-6">
              <span className="text-[10px] font-bold text-[#FF5A5F] uppercase tracking-widest font-mono">
                {isAr ? 'السلم الوظيفي الموحد' : 'PLATFORM TIER WORKFORCE'}
              </span>
              <h3 className="font-serif text-xl sm:text-2xl font-bold text-[#14332B] mt-1">
                {isAr ? 'تعيين موظف إداري جديد' : 'Add Platform Administrator'}
              </h3>
              <p className="text-xs text-[#6E6A63] mt-1">
                {isAr 
                  ? 'قومي بتعبئة معلومات الموظف وتعيين رتبته وتوليد صلاحياته آلياً.' 
                  : 'Specify contact credentials and assign a role with dynamic permission mappings.'}
              </p>
            </div>

            <form onSubmit={handleAddEmployee} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-[#1C1B18] mb-1.5">{isAr ? 'اسم الموظف الثلاثي *' : 'Employee Full Name *'}</label>
                <input
                  type="text"
                  required
                  value={newEmpName}
                  onChange={(e) => setNewEmpName(e.target.value)}
                  placeholder={isAr ? "مثال: مروان يوسف الحميد" : "e.g. Marwan Al-Humaid"}
                  className="w-full bg-white border border-[#E9E7E2] text-xs px-4 py-2.5 rounded-xl focus:outline-none focus:border-[#FF5A5F] text-[#1C1B18]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-[#1C1B18] mb-1.5">{isAr ? 'البريد الإلكتروني المهني *' : 'Professional Email *'}</label>
                  <input
                    type="email"
                    required
                    value={newEmpEmail}
                    onChange={(e) => setNewEmpEmail(e.target.value)}
                    placeholder="name@confirmed.sa"
                    className="w-full bg-white border border-[#E9E7E2] text-xs px-4 py-2.5 rounded-xl focus:outline-none focus:border-[#FF5A5F] text-[#1C1B18]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-[#1C1B18] mb-1.5">{isAr ? 'رقم الجوال لتفعيل MFA *' : 'Active Phone (MFA OTP) *'}</label>
                  <input
                    type="tel"
                    required
                    value={newEmpPhone}
                    onChange={(e) => setNewEmpPhone(e.target.value)}
                    placeholder="05xxxxxxxx"
                    className="w-full bg-white border border-[#E9E7E2] text-xs px-4 py-2.5 rounded-xl focus:outline-none focus:border-[#FF5A5F] text-[#1C1B18] font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#1C1B18] mb-1.5">{isAr ? 'الرتبة الوظيفية (السلم الوظيفي) *' : 'Administrative Level *'}</label>
                <select
                  value={newEmpRole}
                  onChange={(e) => setNewEmpRole(e.target.value as any)}
                  className="w-full bg-white border border-[#E9E7E2] text-xs px-4 py-2.5 rounded-xl focus:outline-none focus:border-[#FF5A5F] text-[#1C1B18]"
                >
                  <option value="ops_supervisor">{isAr ? 'مشرف عمليات وبوابات (أمن متوسط)' : 'Operations Supervisor'}</option>
                  <option value="marketing_spec">{isAr ? 'مسؤول تسويق وحملات (ترويج وبث)' : 'Marketing Specialist'}</option>
                  <option value="tech_support">{isAr ? 'دعم فني وتواصل (صلاحيات مراجعة فقط)' : 'Technical Support'}</option>
                  <option value="senior_admin">{isAr ? 'أدمن أول / Senior Admin (صلاحيات مطلقة)' : 'Senior Admin / Master'}</option>
                </select>
              </div>

              <div className="p-4 bg-[#F6F6F4] border border-[#E9E7E2] rounded-2xl text-xs text-teal-800 leading-normal font-medium">
                💡 {isAr 
                  ? 'سيتم توليد الصلاحيات آلياً بحسب السلم الوظيفي المعتمد في الأنظمة الأمنية لـ CONFIRMED فور تعيين الموظف.' 
                  : 'Mapped permissions will update in real-time mapping to Confirmed security frameworks upon hiring.'}
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddEmpModal(false)}
                  className="px-5 py-3 border border-[#E9E7E2] text-[#6E6A63] hover:bg-[#F6F6F4] hover:text-[#14332B] font-bold text-xs sm:text-sm rounded-xl transition-all cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 bg-[#FF5A5F] hover:bg-[#E04B50] text-white font-bold text-xs sm:text-sm rounded-xl shadow-lg transition-all cursor-pointer flex items-center justify-center gap-1"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>{isAr ? 'توظيف وإطلاق الصلاحيات' : 'Complete Hiring & Map Permissions'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ===== DETAILED PROVIDER PROFILE MODAL ===== */}
      {selectedProfileProvider && (
        <div className="fixed inset-0 bg-[#1C1B18]/45 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl border border-[#E9E7E2] w-full max-w-2xl p-6 md:p-8 space-y-6 shadow-2xl relative my-8 animate-scaleIn" dir={dir}>
            
            {/* Close button */}
            <button 
              onClick={() => setSelectedProfileProvider(null)}
              className="absolute top-4 left-4 p-2 rounded-full hover:bg-slate-100 text-[#6E6A63] cursor-pointer"
              title={isAr ? 'إغلاق' : 'Close'}
            >
              <Check className="w-5 h-5 rotate-45" />
            </button>

            {/* Header / Business badge info */}
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 pb-4 border-b border-[#F6F6F4]">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#FF5A5F] to-[#FFAE34] text-white font-serif font-black text-2xl flex items-center justify-center shadow-md">
                {selectedProfileProvider.storeName.charAt(0)}
              </div>
              <div className="text-center sm:text-right space-y-1">
                <div className="flex flex-wrap items-center gap-2 justify-center sm:justify-start">
                  <h3 className="font-serif text-xl font-bold text-[#14332B]">{selectedProfileProvider.storeName}</h3>
                  <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-bold ${
                    selectedProfileProvider.status === 'active' 
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                      : 'bg-red-50 text-red-700 border border-red-200'
                  }`}>
                    {selectedProfileProvider.status === 'active' ? (isAr ? 'نشط ومعتمد' : 'Active Partner') : (isAr ? 'حساب معلق' : 'Suspended')}
                  </span>
                </div>
                <p className="text-xs text-teal-700 font-mono">🌐 {selectedProfileProvider.subdomain || 'sub'}.confirmed.sa</p>
                <p className="text-xs text-slate-500 font-medium">📍 {isAr ? 'المملكة العربية السعودية' : 'Saudi Arabia'}</p>
              </div>
            </div>

            {/* Grid stats overview */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-[#F8FAFC] border border-[#E9E7E2] p-3 rounded-xl text-center space-y-0.5">
                <span className="text-[10px] text-slate-400 block font-bold uppercase">{isAr ? 'إجمالي المبيعات' : 'Sales'}</span>
                <span className="text-[#14332B] text-sm font-black font-mono">{selectedProfileProvider.totalSales.toLocaleString()} {isAr ? 'ر.س' : 'SAR'}</span>
              </div>
              <div className="bg-[#F8FAFC] border border-[#E9E7E2] p-3 rounded-xl text-center space-y-0.5">
                <span className="text-[10px] text-slate-400 block font-bold uppercase">{isAr ? 'الصافي المدفوع' : 'Paid Out'}</span>
                <span className="text-[#14332B] text-sm font-black font-mono">{selectedProfileProvider.paidOut.toLocaleString()} {isAr ? 'ر.س' : 'SAR'}</span>
              </div>
              <div className="bg-[#F8FAFC] border border-[#E9E7E2] p-3 rounded-xl text-center space-y-0.5">
                <span className="text-[10px] text-slate-400 block font-bold uppercase">{isAr ? 'الرصيد المعلق' : 'Pending'}</span>
                <span className="text-[#FF5A5F] text-sm font-black font-mono">{selectedProfileProvider.pendingPayout.toLocaleString()} {isAr ? 'ر.س' : 'SAR'}</span>
              </div>
              <div className="bg-[#F8FAFC] border border-[#E9E7E2] p-3 rounded-xl text-center space-y-0.5">
                <span className="text-[10px] text-slate-400 block font-bold uppercase">{isAr ? 'مستوى الخدمة' : 'Rating'}</span>
                <span className="text-amber-600 text-sm font-black">⭐ {selectedProfileProvider.rating || '5.0'}</span>
              </div>
            </div>

            {/* Detail Tabs / Sections */}
            <div className="space-y-4">
              
              {/* Info Column 1: Profile & Contacts */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 md:p-5 space-y-4">
                <h4 className="font-sans font-bold text-[#14332B] text-sm border-b border-slate-200 pb-2 flex items-center gap-1.5">
                  <span className="p-1 bg-[#FFF0F0] text-[#FF5A5F] rounded-lg">👤</span>
                  <span>{isAr ? 'بيانات المالك والاتصال المباشر' : 'Owner & Direct Contact Profile'}</span>
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="space-y-1">
                    <span className="text-slate-400 block">{isAr ? 'مالك المنشأة المسؤول:' : 'Managing Director / Owner:'}</span>
                    <span className="text-slate-800 font-bold block text-sm">{selectedProfileProvider.ownerName}</span>
                  </div>

                  <div className="space-y-1">
                    <span className="text-slate-400 block">{isAr ? 'النشاط الأساسي المرخص:' : 'Authorized Business Niche:'}</span>
                    <span className="text-teal-700 font-bold block text-sm">{selectedProfileProvider.activity}</span>
                  </div>

                  <div className="space-y-1">
                    <span className="text-slate-400 block">{isAr ? 'رقم الهاتف المعتمد:' : 'Verified Contact Phone:'}</span>
                    <span className="text-[#FF5A5F] font-bold block text-sm font-mono">{selectedProfileProvider.phone}</span>
                  </div>

                  <div className="space-y-1">
                    <span className="text-slate-400 block">{isAr ? 'البريد الإلكتروني للعمليات:' : 'Operational Email Address:'}</span>
                    <span className="text-slate-800 font-bold block text-sm font-mono truncate">{selectedProfileProvider.email}</span>
                  </div>
                </div>
              </div>

              {/* Info Column 2: Subscription & Scale */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 md:p-5 space-y-4">
                <h4 className="font-sans font-bold text-[#14332B] text-sm border-b border-slate-200 pb-2 flex items-center gap-1.5">
                  <span className="p-1 bg-[#FFF0F0] text-[#FF5A5F] rounded-lg">💼</span>
                  <span>{isAr ? 'الاشتراك ومقاييس الأداء للمزود' : 'Subscription Metrics & Workforce Scale'}</span>
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="space-y-1">
                    <span className="text-slate-400 block">{isAr ? 'باقة النظام والتعرفة:' : 'SaaS Plan & License Tier:'}</span>
                    <span className="text-slate-800 font-black block text-sm uppercase">
                      {selectedProfileProvider.subscriptionTier === 'enterprise' 
                        ? (isAr ? 'سلاسل صالونات (Enterprise)' : 'Enterprise License') 
                        : selectedProfileProvider.subscriptionTier === 'pro' 
                        ? (isAr ? 'باقة احترافية (Pro)' : 'Professional Plan') 
                        : (isAr ? 'باقة البداية (Starter)' : 'Starter Tier')} 
                      {' '} ({selectedProfileProvider.subscriptionPrice} {isAr ? 'ر.س/شهري' : 'SAR/mo'})
                    </span>
                  </div>

                  <div className="space-y-1">
                    <span className="text-slate-400 block">{isAr ? 'حالة دفع الاشتراك:' : 'Billing & Payment Status:'}</span>
                    <span className={`font-bold block text-xs ${
                      selectedProfileProvider.subscriptionStatus === 'active' ? 'text-emerald-600' : 'text-amber-600'
                    }`}>
                      {selectedProfileProvider.subscriptionStatus === 'active' ? (isAr ? '✓ مدفوع ومجدد' : 'Active & Paid') : (isAr ? 'متأخرات الدفع' : 'Overdue')}
                    </span>
                  </div>

                  <div className="space-y-1">
                    <span className="text-slate-400 block">{isAr ? 'حجم طاقم العمل بالصالون:' : 'Active Staff / Specialists:'}</span>
                    <span className="text-slate-800 font-bold block text-sm">{selectedProfileProvider.staffCount} {isAr ? 'مصففات / خبيرات تجميل' : 'Registered Experts'}</span>
                  </div>

                  <div className="space-y-1">
                    <span className="text-slate-400 block">{isAr ? 'مجموع الحجوزات المنجزة:' : 'Cumulative Bookings Tracked:'}</span>
                    <span className="text-[#14332B] font-bold block text-sm font-mono">{selectedProfileProvider.bookingsCount} {isAr ? 'عملية حجز رقمية' : 'Bookings processed'}</span>
                  </div>
                </div>
              </div>

              {/* Legal info & Regulatory Certs */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 md:p-5 space-y-3 text-[11px] text-[#6E6A63] font-mono leading-normal">
                <span className="font-sans font-bold text-slate-800 text-xs block mb-1">{isAr ? 'التراخيص الضريبية والتجاري للمزود:' : 'Legal Registries:'}</span>
                <p>• {isAr ? 'رقم السجل التجاري الموثق في غسيل الأموال والامتثال: 1010892749' : 'Registered Commercial Certificate Number: 1010892749'}</p>
                <p>• {isAr ? 'الرقم الضريبي VAT المعتمد لهيئة الزكاة والضريبة: 310023948500003' : 'Unified Tax (VAT ID) Registered: 310023948500003'}</p>
                <p>• {isAr ? 'ساعات العمل الافتراضية للفرع الرئيسي: طوال الأسبوع من 10:00 ص إلى 10:00 م' : 'Operational Schedule: Mon-Sun from 10:00 AM to 10:00 PM'}</p>
              </div>

            </div>

            {/* Quick Actions Footer inside Modal */}
            <div className="flex flex-wrap gap-3 pt-4 border-t border-[#F6F6F4]">
              <a
                href={`mailto:${selectedProfileProvider.email}`}
                className="py-3 px-4 bg-slate-100 hover:bg-slate-200 text-[#14332B] rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5"
              >
                <Mail className="w-4 h-4 text-[#FF5A5F]" />
                <span>{isAr ? 'مراسلة البريد' : 'Email Salon'}</span>
              </a>

              <a
                href={`https://wa.me/${selectedProfileProvider.phone}`}
                target="_blank"
                rel="noreferrer"
                className="py-3 px-4 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5"
              >
                <span>💬</span>
                <span>{isAr ? 'محادثة واتساب' : 'WhatsApp'}</span>
              </a>

              <button
                type="button"
                onClick={() => {
                  handleToggleProviderStatus(selectedProfileProvider.id);
                  const updatedStatus = selectedProfileProvider.status === 'active' ? 'suspended' : 'active';
                  setSelectedProfileProvider(prev => prev ? { ...prev, status: updatedStatus } : null);
                  alert(selectedProfileProvider.status === 'active' 
                    ? (isAr ? 'تم تعليق هذا الحساب فوراً.' : 'Account suspended immediately.')
                    : (isAr ? 'تم تفعيل الحساب بنجاح.' : 'Account activated successfully.')
                  );
                }}
                className={`py-3 px-4 rounded-xl text-xs font-bold transition-all ml-auto ${
                  selectedProfileProvider.status === 'active'
                    ? 'bg-red-50 hover:bg-red-100 text-red-600 border border-red-200'
                    : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-600 border border-emerald-200'
                }`}
              >
                {selectedProfileProvider.status === 'active' ? (isAr ? '🔒 تعليق الحساب السحابي' : '🔒 Suspend Access') : (isAr ? '🔓 تفعيل الحساب' : '🔓 Activate Access')}
              </button>

              <button
                type="button"
                onClick={() => setSelectedProfileProvider(null)}
                className="py-3 px-5 border border-[#E9E7E2] text-[#6E6A63] hover:bg-[#F6F6F4] rounded-xl text-xs font-bold transition-all"
              >
                {isAr ? 'إغلاق' : 'Close'}
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ===== 6F: DYNAMIC SUBSCRIPTION PLAN BUILDER MODAL ===== */}
      {showPackageModal && (
        <div className="fixed inset-0 bg-[#000]/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-white border border-[#E9E7E2] text-[#1C1B18] rounded-[32px] w-full max-w-2xl p-6 sm:p-8 shadow-2xl relative max-h-[90vh] overflow-y-auto" dir={dir}>
            <button 
              onClick={() => {
                setShowPackageModal(false);
                setEditingPackage(null);
              }}
              className="absolute top-4 left-4 p-2 rounded-full hover:bg-[#F6F6F4] text-[#6E6A63] hover:text-[#14332B] cursor-pointer"
              title={isAr ? 'إغلاق' : 'Close'}
            >
              <Plus className="w-5 h-5 rotate-45" />
            </button>

            <div className="mb-6">
              <span className="text-[10px] font-bold text-[#FF5A5F] uppercase tracking-widest font-mono">
                {isAr ? 'تحديث عروض الاشتراك' : 'SAAS OFFERINGS CONTROLLER'}
              </span>
              <h3 className="font-serif text-xl sm:text-2xl font-bold text-[#14332B] mt-1">
                {editingPackage ? (isAr ? 'تعديل باقة اشتراك' : 'Edit Subscription Package') : (isAr ? 'إضافة باقة اشتراك جديدة' : 'Create New Subscription Package')}
              </h3>
              <p className="text-xs text-[#6E6A63] mt-1">
                {isAr 
                  ? 'قومي بتهيئة التسعير والخصائص الفنية للباقة. التغييرات ستنعكس فوراً على واجهة تسجيل مزودي الخدمة.' 
                  : 'Design core functional capabilities, pricing cycles, and branding features.'}
              </p>
            </div>

            <form onSubmit={handleSavePackage} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-[#1C1B18] mb-1.5">{isAr ? 'اسم الباقة (بالعربية) *' : 'Plan Name (Arabic) *'}</label>
                  <input
                    type="text"
                    required
                    value={pkgNameAr}
                    onChange={(e) => setPkgNameAr(e.target.value)}
                    placeholder="مثال: الباقة الأساسية"
                    className="w-full bg-white border border-[#E9E7E2] text-xs px-3.5 py-2.5 rounded-xl focus:outline-none focus:border-[#FF5A5F] text-[#1C1B18] shadow-sm font-medium"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-[#1C1B18] mb-1.5">{isAr ? 'اسم الباقة (بالإنجليزية) *' : 'Plan Name (English) *'}</label>
                  <input
                    type="text"
                    required
                    value={pkgNameEn}
                    onChange={(e) => setPkgNameEn(e.target.value)}
                    placeholder="e.g. Basic Starter Plan"
                    className="w-full bg-white border border-[#E9E7E2] text-xs px-3.5 py-2.5 rounded-xl focus:outline-none focus:border-[#FF5A5F] text-[#1C1B18] shadow-sm font-medium"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-[#1C1B18] mb-1.5">{isAr ? 'الوصف (بالعربية) *' : 'Description (Arabic) *'}</label>
                  <textarea
                    required
                    rows={2}
                    value={pkgDescAr}
                    onChange={(e) => setPkgDescAr(e.target.value)}
                    placeholder="مثال: مناسبة للصالونات الصغيرة والمبتدئة بفرع واحد"
                    className="w-full bg-white border border-[#E9E7E2] text-xs px-3.5 py-2.5 rounded-xl focus:outline-none focus:border-[#FF5A5F] text-[#1C1B18] shadow-sm font-medium"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-[#1C1B18] mb-1.5">{isAr ? 'الوصف (بالإنجليزية) *' : 'Description (English) *'}</label>
                  <textarea
                    required
                    rows={2}
                    value={pkgDescEn}
                    onChange={(e) => setPkgDescEn(e.target.value)}
                    placeholder="e.g. Perfect for small beauty studios with 1 branch"
                    className="w-full bg-white border border-[#E9E7E2] text-xs px-3.5 py-2.5 rounded-xl focus:outline-none focus:border-[#FF5A5F] text-[#1C1B18] shadow-sm font-medium"
                  />
                </div>
              </div>

              {/* Enterprise Contact Toggle */}
              <div className="flex items-center gap-3 bg-[#F6F6F4] p-3 rounded-2xl border border-[#E9E7E2]">
                <input
                  type="checkbox"
                  id="isEnterpriseContact"
                  checked={pkgIsEnterprise}
                  onChange={(e) => {
                    setPkgIsEnterprise(e.target.checked);
                    if (e.target.checked) {
                      setPkgPriceMonthly(0);
                      setPkgPriceYearly(0);
                    }
                  }}
                  className="w-4 h-4 text-[#FF5A5F] border-gray-300 rounded focus:ring-[#FF5A5F]"
                />
                <label htmlFor="isEnterpriseContact" className="text-xs font-bold text-[#14332B] cursor-pointer">
                  {isAr ? 'هذه الباقة خاصة بالمؤسسات الكبرى (يظهر "تواصل معنا" كالسعر)' : 'Enterprise contact model (displays "Contact Us" instead of numerical prices)'}
                </label>
              </div>

              {!pkgIsEnterprise && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-[#1C1B18] mb-1.5">{isAr ? 'السعر الشهري (ريال/شهر) *' : 'Monthly Price (SAR/mo) *'}</label>
                    <input
                      type="number"
                      required
                      min={0}
                      value={pkgPriceMonthly}
                      onChange={(e) => setPkgPriceMonthly(parseInt(e.target.value) || 0)}
                      placeholder="149"
                      className="w-full bg-white border border-[#E9E7E2] text-xs px-3.5 py-2.5 rounded-xl focus:outline-none focus:border-[#FF5A5F] text-[#1C1B18] shadow-sm font-mono font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-[#1C1B18] mb-1.5">{isAr ? 'السعر السنوي المحسوب شهرياً (ريال/شهر) *' : 'Yearly Price Billed Monthly (SAR/mo) *'}</label>
                    <input
                      type="number"
                      required
                      min={0}
                      value={pkgPriceYearly}
                      onChange={(e) => setPkgPriceYearly(parseInt(e.target.value) || 0)}
                      placeholder="119"
                      className="w-full bg-white border border-[#E9E7E2] text-xs px-3.5 py-2.5 rounded-xl focus:outline-none focus:border-[#FF5A5F] text-[#1C1B18] shadow-sm font-mono font-bold"
                    />
                  </div>
                </div>
              )}

              {/* Is Popular Toggle */}
              <div className="flex items-center gap-3 bg-[#F6F6F4] p-3 rounded-2xl border border-[#E9E7E2]">
                <input
                  type="checkbox"
                  id="isPopular"
                  checked={pkgIsPopular}
                  onChange={(e) => setPkgIsPopular(e.target.checked)}
                  className="w-4 h-4 text-[#FF5A5F] border-gray-300 rounded focus:ring-[#FF5A5F]"
                />
                <label htmlFor="isPopular" className="text-xs font-bold text-[#14332B] cursor-pointer">
                  {isAr ? 'تمييز الباقة كباقة شائعة/أكثر طلباً (Popular Badge)' : 'Mark plan as Recommended/Most Popular (Popular Badge)'}
                </label>
              </div>

              {/* Dynamic Features List Area */}
              <div className="border border-[#E9E7E2] rounded-2xl p-4 space-y-4">
                <div className="flex justify-between items-center">
                  <h4 className="text-xs font-bold text-[#14332B]">{isAr ? 'المميزات والخصائص المشمولة' : 'Included Plan Features'}</h4>
                  <button
                    type="button"
                    onClick={handleAddFeatureInput}
                    className="px-3 py-1 bg-[#14332B] text-[#E9E7E2] text-[10px] font-bold rounded-lg hover:bg-[#FF5A5F] hover:text-white transition-colors cursor-pointer flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{isAr ? 'إضافة ميزة' : 'Add Feature'}</span>
                  </button>
                </div>

                <div className="space-y-3 max-h-48 overflow-y-auto pr-1">
                  {pkgFeatures.map((feat, index) => (
                    <div key={index} className="grid grid-cols-12 gap-2 items-center">
                      <div className="col-span-5">
                        <input
                          type="text"
                          required
                          value={feat.ar}
                          onChange={(e) => handleFeatureInputChange(index, 'ar', e.target.value)}
                          placeholder={isAr ? "الميزة بالعربية" : "Feature (Arabic)"}
                          className="w-full bg-white border border-[#E9E7E2] text-[11px] px-2.5 py-1.5 rounded-lg focus:outline-none text-[#1C1B18] shadow-sm font-medium"
                        />
                      </div>
                      <div className="col-span-6">
                        <input
                          type="text"
                          required
                          value={feat.en}
                          onChange={(e) => handleFeatureInputChange(index, 'en', e.target.value)}
                          placeholder={isAr ? "الميزة بالإنجليزية" : "Feature (English)"}
                          className="w-full bg-white border border-[#E9E7E2] text-[11px] px-2.5 py-1.5 rounded-lg focus:outline-none text-[#1C1B18] shadow-sm font-medium"
                        />
                      </div>
                      <div className="col-span-1 text-center">
                        <button
                          type="button"
                          onClick={() => handleRemoveFeatureInput(index)}
                          disabled={pkgFeatures.length <= 1}
                          className="p-1.5 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg disabled:opacity-30 cursor-pointer flex items-center justify-center"
                          title={isAr ? 'حذف' : 'Remove'}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex gap-3 pt-4 border-t border-[#F6F6F4]">
                <button
                  type="button"
                  onClick={() => {
                    setShowPackageModal(false);
                    setEditingPackage(null);
                  }}
                  className="px-5 py-3 border border-[#E9E7E2] text-[#6E6A63] hover:bg-[#F6F6F4] hover:text-[#14332B] font-bold text-xs sm:text-sm rounded-xl transition-all cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 bg-[#FF5A5F] hover:bg-[#E04B50] text-white font-bold text-xs sm:text-sm rounded-xl shadow-lg transition-all cursor-pointer flex items-center justify-center gap-1"
                >
                  <Check className="w-4 h-4" />
                  <span>{isAr ? 'حفظ الباقة ونشرها' : 'Publish Subscription Package'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-white py-6 px-6 border-t border-[#E9E7E2] text-xs text-[#6E6A63] text-center flex flex-col sm:flex-row justify-between items-center gap-4 shadow-inner">
        <span className="font-medium">© ٢٠٢٦ منصة CONFIRMED السحابية — جميع الحقوق محفوظة لمالك المنصة.</span>
        <span className="font-mono text-[10px] text-emerald-700 font-bold">⚡ COMPLIANT UNDER THE SAUDI ELECTRONIC TRANSACTIONS LAW</span>
      </footer>

    </div>
  );
}
