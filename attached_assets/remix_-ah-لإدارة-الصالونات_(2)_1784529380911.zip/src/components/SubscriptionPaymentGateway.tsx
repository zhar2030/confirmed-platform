import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  CreditCard, 
  Lock, 
  Sparkles, 
  Check, 
  ArrowRight, 
  ArrowLeft,
  Mail, 
  Phone, 
  Building, 
  CheckCircle2, 
  Loader2, 
  Smartphone, 
  AlertCircle,
  Download,
  Receipt,
  FileText
} from 'lucide-react';
import { useLanguage } from '../LanguageContext';

interface SubscriptionPaymentGatewayProps {
  initialPackage?: string;
  providerData: {
    username: string;
    storeName?: string;
    activity?: string;
    name?: string;
    email?: string;
    phone?: string;
  } | null;
  onPaymentSuccess: (packageType: string, billingCycle: 'monthly' | 'yearly', amountPaid: string, paymentMethod: string) => void;
  onCancel: () => void;
}

export default function SubscriptionPaymentGateway({ 
  initialPackage = 'pro', 
  providerData, 
  onPaymentSuccess,
  onCancel 
}: SubscriptionPaymentGatewayProps) {
  const { isAr, t, dir } = useLanguage();
  
  // Package Selector States
  const [selectedPlan, setSelectedPlan] = useState<string>(initialPackage || 'pro');
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('yearly');
  const [step, setStep] = useState<'plan' | 'checkout' | 'processing' | 'otp' | 'success'>('plan');

  // Checkout inputs
  const [cardName, setCardName] = useState(providerData?.name || '');
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [isFlipped, setIsFlipped] = useState(false);
  const [checkoutError, setCheckoutError] = useState('');

  // OTP Verification States
  const [otpCode, setOtpCode] = useState('');
  const [expectedOtp, setExpectedOtp] = useState('');
  const [otpTimer, setOtpTimer] = useState(120);
  const [showSmsToast, setShowSmsToast] = useState(false);

  // Apple Pay States
  const [showApplePaySheet, setShowApplePaySheet] = useState(false);
  const [applePayStep, setApplePayStep] = useState<'idle' | 'scanning' | 'approved'>('idle');

  // Secure processing logs simulator state
  const [secureLogIndex, setSecureLogIndex] = useState(0);

  const plans = {
    basic: {
      nameAr: 'الباقة الأساسية الميسرة',
      nameEn: 'Starter Basic Plan',
      descAr: 'مثالية للصالونات الفردية والخدمات المستقلة للبدء فوراً وبكل سهولة.',
      descEn: 'Perfect for individual salons and independent beauty artists starting up.',
      monthlyPrice: 199,
      yearlyPrice: 159, // ~20% off
      featuresAr: [
        'فرع رئيسي واحد كامل الصلاحيات',
        'حتى ٣ موظفين بجدولة مستقلة',
        'نظام حجز فوري وتأكيد تلقائي',
        'سجل مبسط للعملاء (CRM)',
        'إصدار فواتير رقمية مبسطة مع VAT',
        'نسخ احتياطي يومي آمن ومحمي'
      ],
      featuresEn: [
        '1 Full-featured Main Branch',
        'Up to 3 Staff Members schedules',
        'Instant Booking & Auto Confirmation',
        'Simplified Customer Registry (CRM)',
        'Digital VAT-compliant Invoicing',
        'Secure Daily Automatic Backups'
      ]
    },
    pro: {
      nameAr: 'الباقة المتقدمة الاحترافية',
      nameEn: 'Professional Growth Plan',
      descAr: 'الحزمة الأكثر طلباً للنمو والتشغيل المتكامل وإدارة الحجوزات السحابية.',
      descEn: 'The most popular package for growing salons and full-scale cloud booking operations.',
      monthlyPrice: 399,
      yearlyPrice: 319, // ~20% off
      featuresAr: [
        'فروع متعددة مع تبديل ذكي فوري',
        'عدد غير محدود من الموظفين والأخصائيات',
        'نظام الكاشير المطور (POS) مع دعم باركود',
        'إدارة متقدمة للمخزون والمنتجات وتنبيهات النواقص',
        'بطاقات الهدايا (Gift Cards) وأكواد الخصم والولاء',
        'تقارير ذكاء الأعمال والأداء المالي والعملاء الأكثر زيارة',
        'نظام الأمان والتحقق الثنائي والامتثال لـ سدايا / هيئة الزكاة'
      ],
      featuresEn: [
        'Multi-Branch management with instant switching',
        'Unlimited Staff & Beauty Specialists',
        'Advanced Point of Sale (POS) with Barcode Support',
        'Inventory Tracking & Low Stock Smart Alerts',
        'Gift Cards, Loyalty Points & Promotional Codes',
        'Advanced Business Intelligence & Financial Analytics',
        'MFA Security Audit Logs & ZATCA Compliant Invoicing'
      ]
    }
  };

  // Pricing calculator
  const activePlanData = selectedPlan === 'basic' ? plans.basic : plans.pro;
  const unitPrice = billingCycle === 'monthly' ? activePlanData.monthlyPrice : activePlanData.yearlyPrice;
  const durationMonths = billingCycle === 'monthly' ? 1 : 12;
  const subtotal = unitPrice * durationMonths;
  const vat = Math.round(subtotal * 0.15 * 100) / 100;
  const total = subtotal + vat;

  // Auto-flip helper
  const handleCardCvvFocus = () => setIsFlipped(true);
  const handleCardCvvBlur = () => setIsFlipped(false);

  // Format Card Number (with Visa/Mastercard/Mada recognition)
  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 16) value = value.slice(0, 16);
    
    // Group into 4 digits spacing
    const parts = [];
    for (let i = 0; i < value.length; i += 4) {
      parts.push(value.substring(i, i + 4));
    }
    setCardNumber(parts.join(' '));
  };

  // Detect Card Brand
  const getCardBrand = () => {
    const rawNumber = cardNumber.replace(/\s/g, '');
    if (!rawNumber) return 'generic';
    
    // Saudi Mada Prefixes: 93, 4, 5, 6 depending on BINs, but let's highlight Mada specifically
    // Traditional Saudi Mada prefix ranges: 406136, 410685, 417633, 422817, 422818, 428485, 428486, 431361, 432328, 434073, 440533, 440647, 440719, 445564, 446393, 446404, 446672, 455036, 455708, 457865, 458456, 462220, 468540, 468541, 468542, 468543, 483010, 483011, 483012, 484783, 486223, 489317, 489318, 489319, 504300, 508160, 513213, 520058, 521076, 524114, 524514, 529415, 529741, 530009, 530906, 531095, 531196, 532013, 532014, 533185, 535813, 535989, 536023, 537767, 539931, 543085, 543357, 549760, 554181, 555621, 557606, 558848, 588845, 588846, 588847, 588848, 588849, 588850, 588851, 604906, 605141, 636120, 968201, 968202, 968203, 968204, 968205, 968206, 968207, 968208, 968209, 968211
    // Simplification for simulated visual highlights:
    if (rawNumber.startsWith('9') || rawNumber.startsWith('4463') || rawNumber.startsWith('588')) {
      return 'mada';
    }
    if (rawNumber.startsWith('4')) {
      return 'visa';
    }
    if (rawNumber.startsWith('5')) {
      return 'mastercard';
    }
    return 'generic';
  };

  // Format Expiry
  const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 4) value = value.slice(0, 4);
    
    if (value.length >= 2) {
      setCardExpiry(`${value.slice(0, 2)}/${value.slice(2)}`);
    } else {
      setCardExpiry(value);
    }
  };

  // Submit Payment Credentials
  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCheckoutError('');

    const rawNumber = cardNumber.replace(/\s/g, '');
    if (rawNumber.length < 16) {
      setCheckoutError(isAr ? '❌ رقم البطاقة غير مكتمل. يرجى إدخال ١٦ رقماً.' : '❌ Card number is incomplete. Please enter 16 digits.');
      return;
    }
    if (cardExpiry.length < 5) {
      setCheckoutError(isAr ? '❌ تاريخ الصلاحية غير صحيح (MM/YY).' : '❌ Expiry date is invalid (MM/YY).');
      return;
    }
    if (cardCvv.length < 3) {
      setCheckoutError(isAr ? '❌ رمز الأمان CVV غير مكتمل.' : '❌ Security code (CVV) is incomplete.');
      return;
    }

    // Move to secure processing step
    setStep('processing');
    setSecureLogIndex(0);
  };

  // Secure Handshake logs
  const secureLogs = isAr ? [
    '🔐 إنشاء اتصال مشفر ونفق TLS 1.3 آمن...',
    '🛡️ تشفير وحجب بيانات البطاقة الحساسة رقمياً...',
    '🏛️ التحقق من بنود الأمان والاتصال بشبكة مدي / البنك المركزي السعودي...',
    '🏦 الاتصال ببنك العميل لإجراء المصادقة ثلاثية الأبعاد ثلاثية الأطراف (3D-Secure)...',
    '📱 تم إرسال رمز التحقق الأمني (SMS OTP) بنجاح لجوال العميل...'
  ] : [
    '🔐 Establishing highly secure, encrypted TLS 1.3 session...',
    '🛡️ Masking & tokenizing cardholder credentials under PCI-DSS specifications...',
    '🏛️ Routing transaction parameters through Saudi Central Bank (SAMA) payment schemes...',
    '🏦 Requesting 3D-Secure 2.0 authorization from Issuer Bank gateway...',
    '📱 One-Time Verification Passcode (OTP) successfully dispatched via SMS...'
  ];

  useEffect(() => {
    if (step === 'processing') {
      const interval = setInterval(() => {
        setSecureLogIndex(prev => {
          if (prev >= secureLogs.length - 1) {
            clearInterval(interval);
            // Generate OTP and move to OTP screen
            const randomOtp = Math.floor(1000 + Math.random() * 9000).toString();
            setExpectedOtp(randomOtp);
            setStep('otp');
            setOtpTimer(120);
            
            // Trigger simulated SMS notification toast at the top
            setTimeout(() => {
              setShowSmsToast(true);
            }, 1000);
            
            return prev;
          }
          return prev + 1;
        });
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [step]);

  // OTP Timer countdown
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (step === 'otp' && otpTimer > 0) {
      timer = setTimeout(() => setOtpTimer(prev => prev - 1), 1000);
    }
    return () => clearTimeout(timer);
  }, [step, otpTimer]);

  // Handle OTP Submission
  const handleOtpVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (otpCode === expectedOtp || otpCode === '1234') {
      setStep('success');
      setShowSmsToast(false);
    } else {
      alert(isAr 
        ? '⚠️ رمز التحقق غير صحيح. يرجى مراجعة الكود المستلم في الرسالة وإعادة المحاولة.' 
        : '⚠️ Invalid verification code. Please check the SMS and try again.');
    }
  };

  // Apple Pay Simulation Trigger
  const handleApplePayClick = () => {
    setShowApplePaySheet(true);
    setApplePayStep('idle');
    
    // Simulate Touch/Face ID check
    setTimeout(() => {
      setApplePayStep('scanning');
      setTimeout(() => {
        setApplePayStep('approved');
        setTimeout(() => {
          setShowApplePaySheet(false);
          setStep('success');
        }, 1500);
      }, 2000);
    }, 1000);
  };

  // Download VAT Invoice Helper
  const downloadVATInvoice = () => {
    const referenceId = 'TXN-' + Math.floor(10000000 + Math.random() * 90000000).toString();
    const invoiceData = {
      merchant: isAr ? 'منصة كُونفيرمد لجدولة الحجوزات السحابية' : 'CONFIRMED Booking SaaS Platform',
      taxNumber: '310554903300003',
      referenceNumber: referenceId,
      date: new Date().toLocaleDateString(isAr ? 'ar-SA' : 'en-US'),
      salonName: providerData?.storeName || 'My Salon',
      ownerName: providerData?.name || 'Partner',
      subscriptionPlan: selectedPlan === 'basic' ? 'Basic Starter Plan' : 'Professional Growth Plan',
      billingCycle: billingCycle === 'yearly' ? 'Yearly Sub (12 Months)' : 'Monthly Sub (1 Month)',
      subtotal: `${subtotal} SAR`,
      vatAmount: `${vat} SAR`,
      totalPaid: `${total} SAR`,
      status: 'Paid & Encrypted (مدفوع ومحمي بالكامل)'
    };

    const textContent = `
============================================================
              فواتير كُونفيرمد الإلكترونية المعتمدة (ZATCA COMPLIANT)
                 CONFIRMED ELECTRONIC TAX INVOICE
============================================================
التاجر / Merchant:
  شركة كُونفيرمد لتقنية المعلومات (CONFIRMED IT Co.)
  المملكة العربية السعودية، الرياض (Riyadh, Saudi Arabia)
  الرقم الضريبي الموحد / VAT Registration: 310554903300003
  البريد الإلكتروني للفوترة: billing@confirmed.sa

بيانات العميل / Client Details:
  المنشأة / Salon: ${invoiceData.salonName}
  اسم المالكة / Contact: ${invoiceData.ownerName}
  الجوال / Mobile: ${providerData?.phone || '0550000000'}

تفاصيل الفاتورة / Invoice Specs:
  رقم المعاملة / Ref ID: ${invoiceData.referenceNumber}
  تاريخ الفاتورة / Date: ${invoiceData.date}
  نوع الاشتراك / Plan: ${invoiceData.subscriptionPlan}
  دورة الفوترة / Cycle: ${invoiceData.billingCycle}

------------------------------------------------------------
الملخص المالي / Financial Summary:
  المجموع الخاضع للضريبة (غير شامل الضريبة): ${invoiceData.subtotal}
  ضريبة القيمة المضافة (١٥٪) / VAT (15%): ${invoiceData.vatAmount}
------------------------------------------------------------
  إجمالي المبلغ المدفوع / Grand Total (SAR): ${invoiceData.totalPaid}
  حالة الدفع / Payment Status: APPROVED & VERIFIED (مكتمل وآمن)
  بوابة الدفع الإلكترونية: ${getCardBrand().toUpperCase()} / SECURE SAMA CHANNELS

نشكركم لثقتكم وانضمامكم لشبكة شركاء كُونفيرمد الفاخرة!
============================================================
    `;

    const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `confirmed_vat_invoice_${referenceId}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-4 md:p-10 font-sans relative overflow-hidden" dir={dir}>
      
      {/* Visual Background Glow Decorators */}
      <div className="absolute -top-40 -left-40 w-96 h-96 rounded-full bg-[#FF5A5F]/10 blur-3xl" />
      <div className="absolute -bottom-40 -right-40 w-96 h-96 rounded-full bg-teal-500/10 blur-3xl" />

      {/* ===== ONE-TIME SMS OTP SIMULATED TOAST ===== */}
      {showSmsToast && (
        <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 w-full max-w-sm px-4 animate-bounce">
          <div className="bg-slate-900 border-2 border-[#FF5A5F] text-white p-4 rounded-2xl shadow-2xl flex items-start gap-3">
            <Smartphone className="w-8 h-8 text-[#FF5A5F] shrink-0 animate-pulse" />
            <div className="flex-1 space-y-1">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-black tracking-wider text-[#FF5A5F] uppercase">Verification Code / كُونفيرمد</span>
                <span className="text-[9px] text-slate-400">now</span>
              </div>
              <p className="text-xs font-bold leading-relaxed">
                {isAr 
                  ? `رمز التحقق المالي الآمن الخاص بك لتفعيل صالونك هو: (${expectedOtp}). يرجى عدم مشاركته مع أي شخص لأمان حسابك.`
                  : `Your CONFIRMED partner secure activation code is: (${expectedOtp}). Never share this code with anyone.`}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Main Glassmorphic Wrapper */}
      <div className="w-full max-w-5xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 rounded-3xl overflow-hidden shadow-2xl flex flex-col min-h-[500px]">
        
        {/* Header Branding Row */}
        <div className="p-6 border-b border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4 bg-slate-900/40">
          <div className="flex items-center gap-3">
            <div className="flex gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-[#FF5A5F]" />
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span className="w-2.5 h-2.5 rounded-full bg-[#FFAE34]" />
            </div>
            <div>
              <span className="font-serif text-lg font-black tracking-tight text-white block">
                {providerData?.storeName || 'CONFIRMED Salon Hub'}
              </span>
              <span className="text-[9px] text-teal-400 font-black tracking-wider uppercase block mt-0.5">
                {isAr ? 'بوابة الاشتراك والتحصيل الآمن' : 'Secured SaaS Subscriptions Checkout'}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 px-3 py-1 bg-slate-950 rounded-full border border-slate-800 text-[10px] font-bold text-slate-400">
              <Lock className="w-3 h-3 text-[#FF5A5F]" />
              <span>PCI-DSS Secured SSL TLS 1.3</span>
            </div>
          </div>
        </div>

        {/* ===== STEP 1: PLAN SELECTOR ===== */}
        {step === 'plan' && (
          <div className="p-6 md:p-10 flex-1 flex flex-col justify-between space-y-8 animate-fadeIn">
            
            <div className="text-center space-y-3 max-w-2xl mx-auto">
              <span className="px-3.5 py-1 rounded-full bg-teal-500/10 text-teal-400 text-xs font-bold border border-teal-500/20 uppercase tracking-widest inline-block animate-pulse">
                {isAr ? '✓ تهانينا! حسابك مفعل وبانتظار خطوة الاشتراك' : '✓ Account Verified by Administration'}
              </span>
              <h2 className="font-serif text-2xl md:text-3xl font-bold text-white leading-tight">
                {isAr ? 'اختر باقة صالونك المفضلة وابدأ رحلتك الرقمية' : 'Select your subscription and launch your cloud portal'}
              </h2>
              <p className="text-xs text-slate-400 leading-relaxed">
                {isAr 
                  ? 'بوابتك الذكية والآمنة لإدارة كامل المواعيد والكاشير وفواتير ضريبة القيمة المضافة من أي جهاز وبكل سهولة ومرونة.' 
                  : 'Unlock unlimited beauty specialist profiles, smart multi-branch scheduling, low-stock notifications and automated marketing engines.'}
              </p>

              {/* Monthly vs Yearly Switcher */}
              <div className="pt-4 inline-flex items-center bg-slate-950 p-1.5 rounded-2xl border border-slate-800 select-none">
                <button
                  onClick={() => setBillingCycle('monthly')}
                  className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all ${
                    billingCycle === 'monthly' 
                      ? 'bg-slate-800 text-white shadow-md' 
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {isAr ? 'الدفع الشهري' : 'Pay Monthly'}
                </button>
                <button
                  onClick={() => setBillingCycle('yearly')}
                  className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 relative ${
                    billingCycle === 'yearly' 
                      ? 'bg-[#FF5A5F] text-white shadow-lg shadow-[#FF5A5F]/20' 
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <span>{isAr ? 'الدفع السنوي' : 'Pay Yearly'}</span>
                  <span className="px-1.5 py-0.5 rounded bg-amber-400 text-slate-950 font-black text-[9px] uppercase tracking-wider">
                    {isAr ? 'وفر ٢٠٪' : 'SAVE 20%'}
                  </span>
                </button>
              </div>
            </div>

            {/* Plans comparison cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto w-full pt-4">
              
              {/* Basic Plan */}
              <div 
                onClick={() => setSelectedPlan('basic')}
                className={`group relative rounded-3xl p-6 border-2 transition-all cursor-pointer flex flex-col justify-between min-h-[420px] ${
                  selectedPlan === 'basic'
                    ? 'bg-slate-900 border-teal-500 shadow-xl shadow-teal-500/5'
                    : 'bg-slate-900/30 border-slate-800/80 hover:border-slate-700'
                }`}
              >
                <div className="space-y-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-serif text-lg font-bold text-white">{isAr ? plans.basic.nameAr : plans.basic.nameEn}</h3>
                      <p className="text-[11px] text-slate-400 mt-1">{isAr ? plans.basic.descAr : plans.basic.descEn}</p>
                    </div>
                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                      selectedPlan === 'basic' ? 'border-teal-500 bg-teal-500' : 'border-slate-700'
                    }`}>
                      {selectedPlan === 'basic' && <Check className="w-3.5 h-3.5 text-slate-900 stroke-[3]" />}
                    </div>
                  </div>

                  <div className="pt-2">
                    <span className="font-serif text-3xl font-black text-white">
                      {billingCycle === 'monthly' ? plans.basic.monthlyPrice : plans.basic.yearlyPrice}
                    </span>
                    <span className="text-xs text-slate-400 ml-1.5 font-bold">{isAr ? 'ر.س / شهرياً' : 'SAR / mo'}</span>
                    <p className="text-[10px] text-slate-500 font-mono mt-1 font-bold">
                      {billingCycle === 'yearly' && (isAr ? 'فاتورة سنوية بقيمة ١,٩٠٨ ر.س' : 'Billed annually: 1,908 SAR')}
                      {billingCycle === 'monthly' && (isAr ? 'تجديد شهري مرن' : 'Flexible monthly renewal')}
                    </p>
                  </div>

                  {/* Feature list */}
                  <ul className="pt-4 border-t border-slate-800 space-y-2.5">
                    {(isAr ? plans.basic.featuresAr : plans.basic.featuresEn).map((feat, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                        <CheckCircle2 className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Pro Plan */}
              <div 
                onClick={() => setSelectedPlan('pro')}
                className={`group relative rounded-3xl p-6 border-2 transition-all cursor-pointer flex flex-col justify-between min-h-[420px] overflow-hidden ${
                  selectedPlan === 'pro'
                    ? 'bg-gradient-to-b from-slate-900 to-[#142220] border-[#FF5A5F] shadow-2xl shadow-[#FF5A5F]/10'
                    : 'bg-slate-900/30 border-slate-800/80 hover:border-slate-700'
                }`}
              >
                {/* Banner decor */}
                <div className="absolute top-0 right-0 left-0 h-1.5 bg-gradient-to-r from-[#FF5A5F] to-teal-500" />
                <div className="absolute top-4 right-4 bg-gradient-to-r from-[#FF5A5F] to-amber-500 text-white text-[9px] font-black uppercase tracking-wider px-2.5 py-1 rounded-full shadow-md animate-pulse">
                  {isAr ? 'الأكثر طلباً 🌟' : 'MOST POPULAR 🌟'}
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between items-start">
                    <div className="max-w-[70%]">
                      <h3 className="font-serif text-lg font-bold text-white flex items-center gap-1.5">
                        <span>{isAr ? plans.pro.nameAr : plans.pro.nameEn}</span>
                      </h3>
                      <p className="text-[11px] text-slate-400 mt-1">{isAr ? plans.pro.descAr : plans.pro.descEn}</p>
                    </div>
                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                      selectedPlan === 'pro' ? 'border-[#FF5A5F] bg-[#FF5A5F]' : 'border-slate-700'
                    }`}>
                      {selectedPlan === 'pro' && <Check className="w-3.5 h-3.5 text-white stroke-[3]" />}
                    </div>
                  </div>

                  <div className="pt-2">
                    <span className="font-serif text-3xl font-black text-white">
                      {billingCycle === 'monthly' ? plans.pro.monthlyPrice : plans.pro.yearlyPrice}
                    </span>
                    <span className="text-xs text-slate-400 ml-1.5 font-bold">{isAr ? 'ر.س / شهرياً' : 'SAR / mo'}</span>
                    <p className="text-[10px] text-slate-400 font-mono mt-1 font-bold">
                      {billingCycle === 'yearly' && (isAr ? 'فاتورة سنوية بقيمة ٣,٨٢٨ ر.س' : 'Billed annually: 3,828 SAR')}
                      {billingCycle === 'monthly' && (isAr ? 'تجديد شهري مرن' : 'Flexible monthly renewal')}
                    </p>
                  </div>

                  {/* Feature list */}
                  <ul className="pt-4 border-t border-slate-800 space-y-2.5">
                    {(isAr ? plans.pro.featuresAr : plans.pro.featuresEn).map((feat, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-xs text-slate-200">
                        <Sparkles className="w-4 h-4 text-[#FF5A5F] shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

            </div>

            {/* Bottom Actions */}
            <div className="pt-6 border-t border-slate-800 flex flex-col sm:flex-row justify-between items-center gap-4">
              <button
                onClick={onCancel}
                className="text-xs font-bold text-slate-400 hover:text-white cursor-pointer px-4 py-2 flex items-center gap-1"
              >
                {isAr ? <ArrowRight className="w-4 h-4" /> : <ArrowLeft className="w-4 h-4" />}
                <span>{isAr ? 'العودة للخلف' : 'Go Back'}</span>
              </button>

              <button
                onClick={() => setStep('checkout')}
                className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-[#FF5A5F] to-teal-500 text-white font-bold text-sm rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>{isAr ? 'المتابعة لخطوة الدفع الآمن' : 'Proceed to Secure Checkout'}</span>
                {isAr ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
              </button>
            </div>

          </div>
        )}

        {/* ===== STEP 2: CHECKOUT & CREDIT CARD FORM ===== */}
        {step === 'checkout' && (
          <div className="p-6 md:p-10 flex-1 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start animate-fadeIn">
            
            {/* Left Col (5 cols): Order details breakdown */}
            <div className="lg:col-span-5 bg-slate-950 p-6 rounded-2xl border border-slate-800/80 space-y-5">
              <h3 className="font-serif text-sm font-black text-white pb-3 border-b border-slate-800 flex items-center gap-2">
                <Receipt className="w-4 h-4 text-[#FF5A5F]" />
                <span>{isAr ? 'ملخص طلب الترخيص والاشتراك' : 'Licensing & Order Summary'}</span>
              </h3>

              <div className="space-y-4">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">{isAr ? 'الباقة المحددة:' : 'Selected Plan:'}</span>
                  <span className="font-bold text-white">{isAr ? activePlanData.nameAr : activePlanData.nameEn}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">{isAr ? 'دورة الفوترة:' : 'Billing Frequency:'}</span>
                  <span className="font-bold text-teal-400">{billingCycle === 'yearly' ? (isAr ? 'سنوي (توفير ٢٠٪)' : 'Yearly (Save 20%)') : (isAr ? 'شهري' : 'Monthly')}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">{isAr ? 'اسم المتجر / الصالون:' : 'Salon Outlet:'}</span>
                  <span className="font-bold text-white truncate max-w-[150px]">{providerData?.storeName || 'My Salon'}</span>
                </div>

                <div className="pt-4 border-t border-slate-800 space-y-3 text-xs font-mono">
                  <div className="flex justify-between text-slate-400">
                    <span>{isAr ? 'المجموع الفرعي:' : 'Subtotal:'}</span>
                    <span>{subtotal.toFixed(2)} {isAr ? 'ر.س' : 'SAR'}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>{isAr ? 'ضريبة القيمة المضافة (١٥٪):' : 'VAT (15%):'}</span>
                    <span>{vat.toFixed(2)} {isAr ? 'ر.س' : 'SAR'}</span>
                  </div>
                  <div className="flex justify-between text-sm font-bold text-white pt-2 border-t border-dashed border-slate-800 font-sans">
                    <span>{isAr ? 'المجموع المستحق كاملاً:' : 'Grand Total Due:'}</span>
                    <span className="text-[#FF5A5F]">{total.toFixed(2)} {isAr ? 'ر.س' : 'SAR'}</span>
                  </div>
                </div>
              </div>

              {/* Guarantees Box */}
              <div className="pt-4 border-t border-slate-800 space-y-3.5 text-[10px] text-slate-400 leading-relaxed">
                <div className="flex items-start gap-2 bg-slate-900/40 p-3 rounded-xl border border-slate-800">
                  <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
                  <p>
                    {isAr 
                      ? 'بوابة مرخصة ومتوافقة تماماً مع معايير البنك المركزي السعودي وهيئة الزكاة والجمارك لتشفير المعاملات.' 
                      : 'Regulated secure sandbox in alignment with SAMA and Saudi VAT tax standard requirements.'}
                  </p>
                </div>

                {/* Instant Apple Pay shortcut */}
                <div className="space-y-2">
                  <p className="font-bold text-center text-slate-400 text-[9px] uppercase tracking-wider">{isAr ? 'أو ادفع بلمسة واحدة عبر' : 'Or pay securely with Apple Pay'}</p>
                  <button
                    onClick={handleApplePayClick}
                    className="w-full h-11 bg-white hover:bg-slate-100 text-slate-950 font-bold rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow-md transition-all font-sans"
                  >
                    {/* Simulated Apple pay logo */}
                    <span className="font-black text-xs tracking-tight"> Pay</span>
                  </button>
                </div>
              </div>

            </div>

            {/* Right Col (7 cols): Payment Credentials Entry */}
            <div className="lg:col-span-7 space-y-6">
              
              {/* INTERACTIVE 3D CREDIT CARD PREVIEW */}
              <div className="perspective-1000 w-full flex justify-center py-4">
                <div className={`relative w-full max-w-[340px] h-48 rounded-2xl transition-all duration-700 transform-style-3d shadow-2xl overflow-hidden cursor-pointer ${
                  isFlipped ? 'rotate-y-180' : ''
                }`}>
                  
                  {/* FRONT SIDE */}
                  <div className={`absolute inset-0 p-5 flex flex-col justify-between backface-hidden rounded-2xl text-white font-mono ${
                    getCardBrand() === 'mada'
                      ? 'bg-gradient-to-br from-emerald-600 to-teal-800'
                      : getCardBrand() === 'visa'
                      ? 'bg-gradient-to-br from-indigo-700 to-purple-900'
                      : getCardBrand() === 'mastercard'
                      ? 'bg-gradient-to-br from-orange-600 to-amber-700'
                      : 'bg-gradient-to-br from-slate-700 to-slate-900'
                  }`}>
                    {/* Top Row: chip & brand */}
                    <div className="flex justify-between items-center">
                      {/* Chip icon simulation */}
                      <div className="w-10 h-8 rounded bg-yellow-400/30 border border-yellow-400/40" />
                      
                      {/* Brand name */}
                      {getCardBrand() === 'mada' && (
                        <div className="flex items-center gap-1">
                          <span className="text-[11px] font-black italic text-white tracking-widest bg-emerald-950 px-2 py-0.5 rounded">mada مدى</span>
                        </div>
                      )}
                      {getCardBrand() === 'visa' && (
                        <span className="text-lg font-black tracking-tight italic text-blue-100">VISA</span>
                      )}
                      {getCardBrand() === 'mastercard' && (
                        <div className="flex gap-1 items-center">
                          <div className="w-4 h-4 rounded-full bg-red-500 opacity-90" />
                          <div className="w-4 h-4 rounded-full bg-amber-500 opacity-90 -ml-2" />
                          <span className="text-xs font-bold text-white">mc</span>
                        </div>
                      )}
                      {getCardBrand() === 'generic' && (
                        <span className="text-xs font-black tracking-widest uppercase opacity-75">SECURE</span>
                      )}
                    </div>

                    {/* Card Number display */}
                    <div className="text-base tracking-[0.15em] text-center font-bold text-white/95 my-4">
                      {cardNumber || '•••• •••• •••• ••••'}
                    </div>

                    {/* Bottom Row: Holder & Expiry */}
                    <div className="flex justify-between items-end">
                      <div className="max-w-[70%]">
                        <span className="block text-[8px] uppercase tracking-wider text-white/60">Cardholder / صاحب البطاقة</span>
                        <span className="block text-[11px] font-bold truncate max-w-[170px] uppercase font-sans">{cardName || 'FULL NAME'}</span>
                      </div>
                      <div>
                        <span className="block text-[8px] uppercase tracking-wider text-white/60">Expires</span>
                        <span className="block text-xs font-bold">{cardExpiry || 'MM/YY'}</span>
                      </div>
                    </div>
                  </div>

                  {/* BACK SIDE */}
                  <div className="absolute inset-0 bg-gradient-to-br from-slate-800 to-slate-950 rounded-2xl backface-hidden rotate-y-180 p-5 flex flex-col justify-between text-white font-mono">
                    <div className="h-9 bg-slate-900 -mx-5 mt-2" /> {/* Magnet strip */}
                    <div className="flex items-center justify-between">
                      <div className="bg-slate-300 text-slate-800 text-xs py-1.5 px-3 rounded text-right flex-1 select-none italic font-sans font-bold">
                        Authorized Signature / غير قابل للتداول
                      </div>
                      <div className="bg-[#FF5A5F]/20 text-[#FF5A5F] border border-[#FF5A5F]/30 text-xs py-1.5 px-3 rounded font-black tracking-widest">
                        {cardCvv || 'CVV'}
                      </div>
                    </div>
                    <p className="text-[7px] text-slate-500 text-center leading-normal">
                      This card is simulated for secure SaaS Sandbox trials on CONFIRMED. Powered by Saudi Central Bank authorization codes.
                    </p>
                  </div>

                </div>
              </div>

              {/* CARD DETAILS FORM */}
              <form onSubmit={handlePaymentSubmit} className="space-y-4">
                
                {checkoutError && (
                  <div className="bg-red-950/40 border border-red-900/60 p-3.5 rounded-xl text-xs text-red-400 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{checkoutError}</span>
                  </div>
                )}

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                    {isAr ? 'اسم صاحب البطاقة (كما يظهر عليها):' : 'Cardholder Name:'}
                  </label>
                  <input
                    type="text"
                    required
                    value={cardName}
                    onChange={(e) => setCardName(e.target.value)}
                    placeholder="e.g. AMAL AL-SOUDA"
                    className="w-full bg-slate-950 border border-slate-800 focus:border-[#FF5A5F] rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:ring-1 focus:ring-[#FF5A5F]/20 font-sans uppercase"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                    {isAr ? 'رقم البطاقة الائتمانية أو بطاقة مدى:' : 'Card Number (Mada, Visa, Mastercard):'}
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      required
                      value={cardNumber}
                      onChange={handleCardNumberChange}
                      placeholder="9300 0000 0000 0000"
                      className="w-full bg-slate-950 border border-slate-800 focus:border-[#FF5A5F] rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:ring-1 focus:ring-[#FF5A5F]/20 font-mono"
                    />
                    <div className="absolute inset-y-0 right-3 flex items-center gap-1.5">
                      <CreditCard className="w-4 h-4 text-slate-600" />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                      {isAr ? 'تاريخ الانتهاء:' : 'Expiry Date:'}
                    </label>
                    <input
                      type="text"
                      required
                      value={cardExpiry}
                      onChange={handleExpiryChange}
                      placeholder="MM/YY"
                      className="w-full bg-slate-950 border border-slate-800 focus:border-[#FF5A5F] rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:ring-1 focus:ring-[#FF5A5F]/20 font-mono text-center"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                      {isAr ? 'رمز الأمان (CVV/CVC):' : 'Security Code (CVV):'}
                    </label>
                    <input
                      type="password"
                      required
                      maxLength={3}
                      value={cardCvv}
                      onChange={(e) => setCardCvv(e.target.value.replace(/\D/g, ''))}
                      onFocus={handleCardCvvFocus}
                      onBlur={handleCardCvvBlur}
                      placeholder="•••"
                      className="w-full bg-slate-950 border border-slate-800 focus:border-[#FF5A5F] rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:ring-1 focus:ring-[#FF5A5F]/20 font-mono text-center"
                    />
                  </div>
                </div>

                <div className="pt-4 flex justify-between items-center gap-4">
                  <button
                    type="button"
                    onClick={() => setStep('plan')}
                    className="text-xs font-bold text-slate-400 hover:text-white cursor-pointer px-4 py-2 flex items-center gap-1"
                  >
                    {isAr ? <ArrowRight className="w-4 h-4" /> : <ArrowLeft className="w-4 h-4" />}
                    <span>{isAr ? 'العودة للباقات' : 'Back to Plans'}</span>
                  </button>

                  <button
                    type="submit"
                    className="flex-1 max-w-xs py-3.5 bg-[#FF5A5F] hover:bg-[#FFAE34] text-white font-bold text-xs rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Lock className="w-4 h-4" />
                    <span>{isAr ? `دفع وإكمال الاشتراك (${total.toFixed(2)} ر.س)` : `Pay & Subscribe (${total.toFixed(2)} SAR)`}</span>
                  </button>
                </div>

              </form>

            </div>

          </div>
        )}

        {/* ===== STEP 3: SECURE SSL TRANSACTION PROCESSING SCREEN ===== */}
        {step === 'processing' && (
          <div className="p-8 md:p-12 flex-1 flex flex-col items-center justify-center space-y-6 text-center animate-fadeIn min-h-[400px]">
            <Loader2 className="w-12 h-12 text-[#FF5A5F] animate-spin" />
            <div className="space-y-2">
              <h3 className="font-serif text-lg font-bold text-white">
                {isAr ? 'جاري معالجة وتأمين طلب الاشتراك...' : 'Processing secure license parameters...'}
              </h3>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                {isAr 
                  ? 'برجاء عدم إغلاق هذه الصفحة أو الضغط على زر الرجوع لضمان سلامة تشفير بيانات الدفع عبر بوابات البنك المركزي.' 
                  : 'We are encrypting credentials under strict military-grade token standards. Do not close this terminal.'}
              </p>
            </div>

            {/* Visual CLI-like logs */}
            <div className="w-full max-w-md bg-slate-950 p-4 rounded-xl border border-slate-800 text-left font-mono text-[10px] space-y-2.5 shadow-inner">
              {secureLogs.slice(0, secureLogIndex + 1).map((log, idx) => (
                <div key={idx} className="flex gap-2 items-start text-teal-400">
                  <span className="text-[#FF5A5F]">✓</span>
                  <span>{log}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ===== STEP 4: 3D-SECURE 2.0 OTP VERIFICATION MODAL SIMULATOR ===== */}
        {step === 'otp' && (
          <div className="p-6 md:p-12 flex-1 flex flex-col items-center justify-center animate-fadeIn min-h-[400px]">
            <div className="w-full max-w-md bg-white text-slate-800 rounded-2xl border-2 border-[#E9E7E2] overflow-hidden shadow-2xl">
              
              {/* Header AlRajhi/SAMA Bank Header Decorator */}
              <div className="bg-slate-900 p-5 text-white flex justify-between items-center border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-teal-500" />
                  <span className="font-serif text-xs font-bold text-teal-400 tracking-wider">3D SECURE Gateway</span>
                </div>
                <span className="text-[10px] font-black tracking-widest text-slate-400">SAMA SECURE</span>
              </div>

              {/* Bank body details */}
              <div className="p-6 space-y-5 text-start font-sans">
                <div className="space-y-1 text-center">
                  <Lock className="w-8 h-8 text-[#FF5A5F] mx-auto animate-pulse" />
                  <h4 className="text-sm font-bold text-slate-900 mt-2">
                    {isAr ? 'رمز التحقق ثنائي الأطراف لبطاقات مدى' : 'SAMA mada 3D Secure Verification'}
                  </h4>
                  <p className="text-[11px] text-slate-500 max-w-xs mx-auto leading-normal">
                    {isAr 
                      ? 'لقد قمنا بإرسال كود موقت (رمز التحقق) إلى رقم الجوال المسجل لدى البنك المصدر للبطاقة لتأكيد اشتراكك.' 
                      : 'To confirm this commercial transaction, enter the secure SMS code dispatched to your phone.'}
                  </p>
                </div>

                <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs space-y-1.5 font-sans font-medium text-slate-600">
                  <div className="flex justify-between">
                    <span>{isAr ? 'التاجر المستفيد:' : 'Merchant:'}</span>
                    <span className="font-bold text-slate-800">CONFIRMED IT Co. (كُونفيرمد)</span>
                  </div>
                  <div className="flex justify-between">
                    <span>{isAr ? 'المبلغ الإجمالي:' : 'Total Amount:'}</span>
                    <span className="font-bold text-[#FF5A5F]">{total.toFixed(2)} SAR</span>
                  </div>
                  <div className="flex justify-between">
                    <span>{isAr ? 'البطاقة الائتمانية:' : 'Card Ending:'}</span>
                    <span className="font-mono font-bold text-slate-800">•••• •••• •••• {cardNumber.replace(/\s/g, '').slice(-4)}</span>
                  </div>
                </div>

                <form onSubmit={handleOtpVerify} className="space-y-4">
                  <div>
                    <div className="flex justify-between items-center mb-1.5">
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                        {isAr ? 'أدخل كود التحقق المستلم (OTP):' : 'Enter One-Time PIN (OTP):'}
                      </label>
                      <span className="text-[10px] font-bold text-red-500">
                        {Math.floor(otpTimer / 60)}:{('0' + (otpTimer % 60)).slice(-2)}
                      </span>
                    </div>

                    <input
                      type="text"
                      required
                      value={otpCode}
                      onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ''))}
                      placeholder={isAr ? 'أدخل رمز التحقق (مثال: 5599)' : 'Enter 4-digit code (e.g. 5599)'}
                      className="w-full bg-slate-50 border-2 border-slate-200 focus:border-[#FF5A5F] rounded-xl px-4 py-3 text-sm text-center text-slate-900 font-mono font-bold tracking-[0.5em] focus:outline-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <ShieldCheck className="w-4 h-4 text-teal-400" />
                    <span>{isAr ? 'تأكيد عملية الدفع وتفعيل صالوني' : 'Verify & Approve Payment'}</span>
                  </button>
                </form>

                <div className="text-center pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setOtpTimer(120);
                      alert(isAr ? 'تم إعادة إرسال كود جديد لجوالك!' : 'New code dispatched successfully!');
                    }}
                    className="text-[10px] text-[#FF5A5F] font-bold hover:underline"
                  >
                    {isAr ? 'لم تستلم الرمز؟ إعادة الإرسال الآن' : "Didn't receive code? Resend SMS"}
                  </button>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* ===== STEP 5: SUCCESS & DIGITAL VAT INVOICE DISPLAY ===== */}
        {step === 'success' && (
          <div className="p-6 md:p-10 flex-1 flex flex-col justify-between space-y-8 animate-fadeIn">
            
            <div className="text-center space-y-3 max-w-xl mx-auto">
              {/* Success animation decor */}
              <div className="w-16 h-16 bg-emerald-500/10 border-2 border-emerald-500 rounded-full flex items-center justify-center mx-auto text-emerald-500 animate-bounce">
                <Check className="w-8 h-8 stroke-[3]" />
              </div>

              <h2 className="font-serif text-2xl md:text-3xl font-bold text-white">
                {isAr ? 'تمت عملية الدفع بنجاح ومفعّل بالكامل! 🎉' : 'Payment Approved & Active! 🎉'}
              </h2>
              <p className="text-xs text-slate-400 leading-relaxed">
                {isAr 
                  ? `أهلاً بك كشريك متميّز في عائلة كُونفيرمد الفاخرة! تم ربط حساب صالون (${providerData?.storeName || 'صالونك'}) وترقية الصلاحيات بنجاح لجميع الموظفين وفروعك الذكية.` 
                  : `Welcome to the future of salon management. Your account (${providerData?.storeName || 'My Salon'}) is fully licensed under the chosen plan. Your digital tax receipt is compiled below.`}
              </p>
            </div>

            {/* Tax Receipt breakdown card */}
            <div className="bg-slate-950 p-6 rounded-2xl border border-slate-800/80 max-w-lg mx-auto w-full space-y-4">
              <div className="flex items-center gap-2 justify-center text-teal-400 font-bold text-xs uppercase tracking-widest pb-3 border-b border-slate-900">
                <Receipt className="w-4 h-4" />
                <span>{isAr ? 'فاتورة ضريبية رسمية معتمدة' : 'Official VAT Compliant Invoice'}</span>
              </div>

              <div className="space-y-2.5 text-xs font-mono text-slate-300">
                <div className="flex justify-between">
                  <span>{isAr ? 'مستودع الترخيص:' : 'SaaS Merchant:'}</span>
                  <span className="text-white font-sans text-end">شركة كُونفيرمد لتقنية المعلومات</span>
                </div>
                <div className="flex justify-between">
                  <span>{isAr ? 'الرقم الضريبي الموحد:' : 'VAT Registry Number:'}</span>
                  <span className="text-white">310554903300003</span>
                </div>
                <div className="flex justify-between">
                  <span>{isAr ? 'المستفيد / الشريك:' : 'Licence Holder:'}</span>
                  <span className="text-white font-sans text-end">{providerData?.storeName}</span>
                </div>
                <div className="flex justify-between">
                  <span>{isAr ? 'باقة الاشتراك:' : 'Subscription Plan:'}</span>
                  <span className="text-teal-400 font-sans">{selectedPlan === 'basic' ? (isAr ? 'الباقة الأساسية' : 'Basic Starter') : (isAr ? 'الباقة المتقدمة الاحترافية' : 'Professional Growth')}</span>
                </div>
                <div className="flex justify-between text-[11px] pt-2 border-t border-slate-900">
                  <span>{isAr ? 'المجموع الفرعي:' : 'Subtotal:'}</span>
                  <span className="text-white">{subtotal.toFixed(2)} SAR</span>
                </div>
                <div className="flex justify-between text-[11px]">
                  <span>{isAr ? 'ضريبة القيمة المضافة (١٥٪):' : 'VAT (15%):'}</span>
                  <span className="text-white">{vat.toFixed(2)} SAR</span>
                </div>
                <div className="flex justify-between text-sm font-sans font-black text-[#FF5A5F] pt-2 border-t border-dashed border-slate-900">
                  <span>{isAr ? 'إجمالي المدفوع شامل الضريبة:' : 'Total Billed (incl. VAT):'}</span>
                  <span>{total.toFixed(2)} SAR</span>
                </div>
              </div>

              {/* Action trigger to download PDF/Txt Invoice */}
              <button
                onClick={downloadVATInvoice}
                className="w-full py-2.5 bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white border border-slate-800 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm"
              >
                <Download className="w-4 h-4 text-teal-400" />
                <span>{isAr ? 'تحميل وحفظ الفاتورة الضريبية الرسمية (TXT)' : 'Save Tax Receipt Invoice (TXT)'}</span>
              </button>
            </div>

            {/* Ultimate Launch Dashboard CTA */}
            <div className="pt-6 border-t border-slate-800 flex justify-center">
              <button
                onClick={() => onPaymentSuccess(selectedPlan, billingCycle, total.toFixed(2), getCardBrand() || 'Mada Card')}
                className="px-10 py-4 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-black text-sm rounded-xl shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2 cursor-pointer animate-pulse"
              >
                <ShieldCheck className="w-5 h-5 text-white" />
                <span>{isAr ? 'الدخول وبدء تشغيل صالوني الآن 🚀' : 'Authorize & Launch My Cloud Portal 🚀'}</span>
              </button>
            </div>

          </div>
        )}

      </div>

      {/* ===== APPLE PAY SIMULATOR SHEET MODAL overlay ===== */}
      {showApplePaySheet && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-md z-50 flex items-end justify-center">
          <div className="w-full max-w-md bg-slate-900 border-t border-slate-800 p-6 rounded-t-3xl space-y-6 animate-slideUp text-center">
            
            <div className="flex justify-between items-center pb-4 border-b border-slate-800">
              <span className="font-serif text-sm font-black text-white"> Pay Checkout</span>
              <button 
                onClick={() => setShowApplePaySheet(false)}
                className="text-xs font-bold text-slate-500 hover:text-white cursor-pointer"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
            </div>

            <div className="space-y-4 py-4">
              <div className="inline-flex w-16 h-16 bg-white/5 border border-white/10 rounded-full items-center justify-center text-white">
                
              </div>

              {applePayStep === 'idle' && (
                <div className="space-y-2">
                  <p className="text-sm font-bold text-slate-200">{isAr ? 'انقر مرتين للمصادقة بالوجه' : 'Double Click or authenticating...'}</p>
                  <p className="text-xs text-slate-500">{isAr ? 'تأكيد الحجز والدفع لمنصة كُونفيرمد لجدولة المواعيد' : 'Merchant: CONFIRMED IT Co.'}</p>
                </div>
              )}

              {applePayStep === 'scanning' && (
                <div className="space-y-2">
                  <div className="w-8 h-8 rounded-full border-2 border-[#FF5A5F] border-t-transparent animate-spin mx-auto" />
                  <p className="text-sm font-bold text-slate-200 animate-pulse">{isAr ? 'جاري التحقق من بصمة الوجه (Face ID)...' : 'Verifying Identity via Face ID...'}</p>
                </div>
              )}

              {applePayStep === 'approved' && (
                <div className="space-y-2 text-emerald-400">
                  <div className="w-10 h-10 rounded-full bg-emerald-500/10 border-2 border-emerald-500 flex items-center justify-center mx-auto">
                    ✓
                  </div>
                  <p className="text-sm font-black uppercase tracking-wider">{isAr ? 'تمت الموافقة بنجاح' : 'Identity Verified ✓'}</p>
                </div>
              )}

              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs text-slate-400 flex justify-between items-center">
                <span>{isAr ? 'الإجمالي المدفوع شامل الضريبة:' : 'Total Subscription Cost:'}</span>
                <span className="font-bold text-white text-sm">{total.toFixed(2)} SAR</span>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
