import React, { useState, useEffect } from 'react';
import { Menu, X, ArrowUpRight, Check, CheckCircle2, Heart, Sparkles, LogIn, Mail, Phone, Calendar, User, ShoppingBag, ShieldCheck, Lock, Unlock, ShieldAlert, Key, Smartphone, RefreshCw, Eye, EyeOff, Building, Briefcase, Plus, CreditCard, ChevronDown } from 'lucide-react';
import { useLanguage } from '../LanguageContext';
import PrivacyPolicyModal from './PrivacyPolicyModal';
import RoadmapManager from './RoadmapManager';
import { sanitizeInput, logSecurityEvent } from '../lib/security';

interface LandingPageProps {
  onLogin: (isPlatformAdmin?: boolean, providerData?: any) => void;
  onAddProviderRequest?: (newRequest: any) => void;
  providerRequests?: any[];
  packages?: any[];
}

export default function LandingPage({ onLogin, onAddProviderRequest, providerRequests = [], packages = [] }: LandingPageProps) {
  const { lang, toggleLanguage, t, dir, isAr } = useLanguage();
  const [activeView, setActiveView] = useState<'home' | 'roadmap'>('home');
  const [isMobile, setIsMobile] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [billing, setBilling] = useState<'monthly' | 'yearly'>('monthly');
  const [formSent, setFormSent] = useState(false);
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);
  const [showPartnerDropdown, setShowPartnerDropdown] = useState(false);

  // Service Provider Registration State
  const [showRegisterModal, setShowRegisterModal] = useState(false);
  const [registerStep, setRegisterStep] = useState<1 | 2 | 3 | 4>(1);
  const [regName, setRegName] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regStoreName, setRegStoreName] = useState('');
  const [regActivity, setRegActivity] = useState('صالون شعر وتجميل');
  const [regCustomActivity, setRegCustomActivity] = useState('');
  const [regFormError, setRegFormError] = useState('');

  // New States for Secure Package Booking & Checkout Flow
  const [selectedPackage, setSelectedPackage] = useState<string | null>(packages[1]?.id || packages[0]?.id || 'pro');
  const [paymentMethod, setPaymentMethod] = useState<'mada' | 'credit' | 'applepay'>('mada');
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [cardName, setCardName] = useState('');
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);

  // Secure Multi-Factor Authentication System States
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [loginStep, setLoginStep] = useState<1 | 2>(1);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [attemptsLeft, setAttemptsLeft] = useState(4);
  const [isLockedOut, setIsLockedOut] = useState(false);
  const [lockoutTimer, setLockoutTimer] = useState(0);
  const [errorMessage, setErrorMessage] = useState('');
  const [generatedOTP, setGeneratedOTP] = useState('');
  const [enteredOTP, setEnteredOTP] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otpError, setOtpError] = useState('');
  const [showMfaSandbox, setShowMfaSandbox] = useState(false);

  // Simulated Notification states for OTP delivery (directly to mobile or email)
  const [activeNotification, setActiveNotification] = useState<{
    type: 'sms' | 'email';
    recipient: string;
    code: string;
    visible: boolean;
  } | null>(null);

  const triggerSimulatedNotification = (type: 'sms' | 'email', recipient: string, code: string) => {
    setActiveNotification({
      type,
      recipient,
      code,
      visible: true
    });
  };

  // Mock SHA-256 client hashing visualizer helper
  const getSHA256Mock = (str: string) => {
    if (!str) return 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855';
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash = hash & hash;
    }
    const hex = Math.abs(hash).toString(16).padStart(8, '0');
    return (hex + '8f7d93b1a2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9').substring(0, 64);
  };

  // Lockdown countdown effect
  useEffect(() => {
    if (lockoutTimer > 0) {
      const timer = setTimeout(() => setLockoutTimer(prev => prev - 1), 1000);
      return () => clearTimeout(timer);
    } else if (lockoutTimer === 0 && isLockedOut) {
      setIsLockedOut(false);
      setAttemptsLeft(4);
      setErrorMessage('');
    }
  }, [lockoutTimer, isLockedOut]);

  // Notification auto-dismiss effect
  useEffect(() => {
    if (activeNotification && activeNotification.visible) {
      const timer = setTimeout(() => {
        setActiveNotification(prev => prev ? { ...prev, visible: false } : null);
      }, 9000);
      return () => clearTimeout(timer);
    }
  }, [activeNotification]);

  const handleCredentialsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isLockedOut) return;

    // Securely sanitize fields to prevent script/SQL injections
    const sanitizedUser = sanitizeInput(username);
    const sanitizedPass = sanitizeInput(password);

    if (attemptsLeft <= 1) {
      setAttemptsLeft(0);
      setIsLockedOut(true);
      setLockoutTimer(60); // 60 seconds lockout
      
      logSecurityEvent(
        sanitizedUser || 'anonymous',
        isAr 
          ? 'تم حظر اتصال IP مؤقتاً لتخطي الحد الأقصى لمحاولات تسجيل الدخول (Brute-Force Lockout)' 
          : 'IP address temporarily blocked due to exceeding max login retries (Brute-Force Protection)',
        'Blocked'
      );

      setErrorMessage(isAr 
        ? '⚠️ تم قفل الحساب مؤقتاً لمدة 60 ثانية بسبب تجاوز الحد الأقصى للمحاولات (4 محاولات) لمنع التخمين.' 
        : '⚠️ Account temporarily locked for 60s due to reaching max attempts (4) to prevent brute-force.');
      return;
    }

    const validUsers = ['amal.hair', 'dalal.spa', 'shahad.nail', 'admin', 'jawahir.mua'];
    const cleanUser = sanitizedUser.trim().toLowerCase();

    // Check if user matches a custom provider request
    const matchedRequest = providerRequests.find((r: any) => 
      r.email?.trim().toLowerCase() === cleanUser || 
      r.phone?.trim() === cleanUser || 
      r.storeName?.trim().toLowerCase() === cleanUser
    );

    const isApprovedNewProvider = matchedRequest && matchedRequest.status === 'approved';
    const isPendingNewProvider = matchedRequest && matchedRequest.status === 'pending';

    if (isPendingNewProvider) {
      logSecurityEvent(
        cleanUser,
        isAr 
          ? 'محاولة دخول مرفوضة - الحساب لا يزال تحت التدقيق والمراجعة' 
          : 'Login attempt denied - Account is pending approval',
        'Warning'
      );

      setErrorMessage(isAr 
        ? '⚠️ حساب صالونك قيد المراجعة والموافقة من قبل إدارة المنصة حالياً. ستصلك رسالة فور تفعيل حسابك.'
        : '⚠️ Your salon account is currently pending review & activation by the administration. You will be notified immediately once approved.');
      return;
    }

    if ((validUsers.includes(cleanUser) || cleanUser === 'admin@confirmed.sa' || isApprovedNewProvider) && sanitizedPass === 'password123') {
      setErrorMessage('');
      const randomCode = Math.floor(100000 + Math.random() * 900000).toString();
      setGeneratedOTP(randomCode);
      setLoginStep(2);
      setOtpSent(true);
      setShowMfaSandbox(false);

      logSecurityEvent(
        cleanUser,
        isAr 
          ? 'تخطي مرحلة التحقق من كلمة المرور - إرسال رمز التحقق الثنائي (OTP)' 
          : 'Primary credentials verified - Dispatched 2FA security OTP token',
        'Passed'
      );

      // Trigger high-fidelity notification
      const isEmail = cleanUser.includes('@') || cleanUser === 'admin' || (isApprovedNewProvider && matchedRequest?.email?.includes('@'));
      const deliveryType = isEmail ? 'email' : 'sms';
      let target = cleanUser;
      if (cleanUser === 'admin') {
        target = 'admin@confirmed.sa';
      } else if (cleanUser === 'amal.hair') {
        target = '0550000123';
      } else if (cleanUser === 'dalal.spa') {
        target = '0550000456';
      } else if (cleanUser === 'shahad.nail') {
        target = '0550000789';
      } else if (isApprovedNewProvider && matchedRequest) {
        target = matchedRequest.email || matchedRequest.phone || '0550000000';
      }
      triggerSimulatedNotification(deliveryType, target, randomCode);
    } else {
      const remaining = attemptsLeft - 1;
      setAttemptsLeft(remaining);

      logSecurityEvent(
        cleanUser || 'anonymous',
        isAr 
          ? `فشل التحقق من الهوية - كلمة المرور غير مطابقة. محاولات متبقية: ${remaining}` 
          : `Identity verification failed - incorrect credentials. Retries left: ${remaining}`,
        'Warning'
      );

      // VAGUE ERROR MESSAGE: Do not specify whether email or password is wrong
      setErrorMessage(isAr 
        ? `❌ خطأ: اسم المستخدم أو كلمة المرور غير صحيحة. يرجى المحاولة مرة أخرى. (المحاولات المتبقية: ${remaining})`
        : `❌ Error: Invalid username or password. Please try again. (${remaining} attempts remaining)`);
    }
  };

  const handleOTPSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const sanitizedOtp = sanitizeInput(enteredOTP);
    const cleanUser = sanitizeInput(username).trim().toLowerCase();

    if (sanitizedOtp === generatedOTP) {
      const isPlatformAdmin = cleanUser === 'admin' || cleanUser === 'admin@confirmed.sa';
      
      // Let's formulate the custom provider data if any
      const matchedRequest = providerRequests.find((r: any) => 
        r.email?.trim().toLowerCase() === cleanUser || 
        r.phone?.trim() === cleanUser || 
        r.storeName?.trim().toLowerCase() === cleanUser
      );

      let providerData = null;
      if (matchedRequest) {
        providerData = {
          id: matchedRequest.id,
          username: cleanUser,
          storeName: matchedRequest.storeName,
          activity: matchedRequest.activity,
          name: matchedRequest.name,
          email: matchedRequest.email,
          phone: matchedRequest.phone,
          paymentStatus: matchedRequest.paymentStatus || 'pending',
          selectedPackage: matchedRequest.selectedPackage || 'pro',
          billingCycle: matchedRequest.billingCycle || 'yearly'
        };
      } else if (cleanUser === 'amal.hair') {
        providerData = { username: cleanUser, storeName: isAr ? 'صالون أمل للشعر' : 'Amal Hair Salon', activity: 'شعر وتجميل', name: 'أمل', paymentStatus: 'paid_verified' };
      } else if (cleanUser === 'dalal.spa') {
        providerData = { username: cleanUser, storeName: isAr ? 'سبا دلال الاسترخائي' : 'Dalal Relaxation Spa', activity: 'سبا ومساج', name: 'دلال', paymentStatus: 'paid_verified' };
      } else if (cleanUser === 'shahad.nail') {
        providerData = { username: cleanUser, storeName: isAr ? 'صالون شهد للأظافر' : 'Shahad Nail Lounge', activity: 'عناية بالأظافر', name: 'شهد', paymentStatus: 'paid_verified' };
      } else if (cleanUser === 'jawahir.mua') {
        providerData = { username: cleanUser, storeName: isAr ? 'استوديو جواهر للتجميل' : 'Jawahir Makeup Studio', activity: 'مكياج وتجميل', name: 'جواهر', paymentStatus: 'paid_verified' };
      }

      logSecurityEvent(
        cleanUser,
        isAr 
          ? 'تم التحقق من بروتوكول المصادقة الثنائية بنجاح - الدخول الآمن للوحة النظام' 
          : 'Multi-Factor verification successful - authorized access granted to workstation',
        'Passed'
      );

      setShowLoginModal(false);
      setLoginStep(1);
      setUsername('');
      setPassword('');
      setAttemptsLeft(4);
      setEnteredOTP('');
      setOtpSent(false);
      setShowMfaSandbox(false);
      onLogin(isPlatformAdmin, providerData); // Proceed to system dashboard
    } else {
      logSecurityEvent(
        cleanUser,
        isAr 
          ? 'فشل إدخال رمز التحقق (OTP)' 
          : 'Invalid 2FA OTP code submitted',
        'Warning'
      );

      setOtpError(isAr 
        ? '❌ رمز التحقق غير صحيح. يرجى إدخال الكود المستلم في البريد أو الجوال.' 
        : '❌ Incorrect 2FA verification code. Check the simulated SMS or Email notifications.');
    }
  };

  const handleAutoFillDemo = (user: string) => {
    setUsername(user);
    setPassword('password123');
    setErrorMessage('');
  };
  
  // Contact Form State
  const [contactName, setContactName] = useState('');
  const [facilityType, setFacilityType] = useState('صالون نسائي');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Securely sanitize inputs to prevent injection attacks
    const sanitizedName = sanitizeInput(regName);
    const sanitizedPhone = sanitizeInput(regPhone);
    const sanitizedEmail = sanitizeInput(regEmail);
    const sanitizedStoreName = sanitizeInput(regStoreName);
    const sanitizedActivity = sanitizeInput(regActivity);
    const sanitizedCustomActivity = sanitizeInput(regCustomActivity);

    if (!sanitizedName || !sanitizedPhone || !sanitizedEmail) {
      setRegFormError(isAr ? 'الرجاء تعبئة جميع الحقول المطلوبة في الخطوة الأولى' : 'Please fill in all required fields in step 1');
      return;
    }
    if (!sanitizedStoreName) {
      setRegFormError(isAr ? 'الرجاء تعبئة اسم المتجر أو الشركة في الخطوة الثانية' : 'Please fill in the store or company name in step 2');
      return;
    }
    
    const finalActivity = sanitizedActivity === 'أخرى' && sanitizedCustomActivity ? sanitizedCustomActivity : sanitizedActivity;

    const newRequest = {
      id: 'req-' + Math.random().toString(36).substring(2, 9),
      name: sanitizedName,
      phone: sanitizedPhone,
      email: sanitizedEmail,
      storeName: sanitizedStoreName,
      activity: finalActivity,
      status: 'pending',
      requestedAt: new Date().toISOString()
    };
    
    logSecurityEvent(
      sanitizedEmail,
      isAr 
        ? `طلب تسجيل شريك جديد خضع للتنقية والفلترة السيبرانية بنجاح للمنشأة: ${sanitizedStoreName}` 
        : `New partner registration request successfully sanitized & audited for: ${sanitizedStoreName}`,
      'Passed'
    );

    if (onAddProviderRequest) {
      onAddProviderRequest(newRequest);
    }
    
    setRegisterStep(4); // Move to success step!
    setRegFormError('');
  };

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 1200);
      if (window.innerWidth > 1200) setMobileOpen(false);
    };
    
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    window.addEventListener('scroll', handleScroll);

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSent(true);
  };

  const basicPrice = billing === 'monthly' ? '149' : '119';
  const proPrice = billing === 'monthly' ? '299' : '239';
  
  const periodLabel = isAr 
    ? (billing === 'monthly' ? 'شهرياً' : 'شهرياً (فوترة سنوية)') 
    : (billing === 'monthly' ? '/ mo' : '/ mo (billed annually)');

  return (
    <div className="min-h-screen bg-[#F6F6F4] text-[#1C1B18] selection:bg-[#FF5A5F]/20 selection:text-[#FF5A5F]" dir={dir}>
      {/* ===== HEADER ===== */}
      <header 
        className={`sticky top-0 z-50 transition-all duration-300 ${
          scrolled 
            ? 'bg-white/90 backdrop-blur-md border-b border-[#E9E7E2] shadow-sm' 
            : 'bg-transparent border-b border-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-6">
          <button 
            onClick={() => {
              setActiveView('home');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex items-center gap-3 hover:opacity-90 transition-all text-left rtl:text-right cursor-pointer border-none bg-transparent shrink-0"
          >
            <div className="flex flex-col gap-1">
              <div className="flex gap-1.5 items-center">
                <span className="w-2.5 h-2.5 rounded-full bg-[#FF5A5F] shadow-sm animate-pulse" />
                <span className="w-2.5 h-2.5 rounded-full bg-[#9E9E9E] shadow-sm" />
                <span className="w-2.5 h-2.5 rounded-full bg-[#FFAE34] shadow-sm" />
              </div>
              <span className="font-sans text-lg font-black tracking-[0.2em] text-slate-900 leading-none select-none uppercase">CONFIRMED</span>
              <span className="text-[8px] font-semibold text-slate-400 tracking-wider leading-none block uppercase">{isAr ? 'سهولة الحجز' : 'EASY TO BOOK'}</span>
            </div>
          </button>

          {/* Desktop Navigation */}
          {!isMobile && (
            <nav className="flex items-center gap-4 xl:gap-8 shrink-0">
              <a href="#features" onClick={() => setActiveView('home')} className="text-[14px] xl:text-[15px] font-medium text-[#1C1B18]/80 hover:text-[#FF5A5F] transition-colors whitespace-nowrap">{isAr ? 'المميزات' : 'Features'}</a>
              <a href="#how" onClick={() => setActiveView('home')} className="text-[14px] xl:text-[15px] font-medium text-[#1C1B18]/80 hover:text-[#FF5A5F] transition-colors whitespace-nowrap">{isAr ? 'كيف يعمل' : 'How It Works'}</a>
              <a href="#pricing" onClick={() => setActiveView('home')} className="text-[14px] xl:text-[15px] font-medium text-[#1C1B18]/80 hover:text-[#FF5A5F] transition-colors whitespace-nowrap">{isAr ? 'الأسعار' : 'Pricing'}</a>
              <a href="#faq" onClick={() => setActiveView('home')} className="text-[14px] xl:text-[15px] font-medium text-[#1C1B18]/80 hover:text-[#FF5A5F] transition-colors whitespace-nowrap">{isAr ? 'الأسئلة الشائعة' : 'FAQ'}</a>
              <a href="#contact" onClick={() => setActiveView('home')} className="text-[14px] xl:text-[15px] font-medium text-[#1C1B18]/80 hover:text-[#FF5A5F] transition-colors whitespace-nowrap">{isAr ? 'اتصلي بنا' : 'Contact Us'}</a>
              <button
                onClick={() => {
                  setActiveView('roadmap');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className={`text-[14px] xl:text-[15px] font-semibold transition-colors cursor-pointer flex items-center gap-1 bg-transparent border-none shrink-0 whitespace-nowrap ${
                  activeView === 'roadmap' ? 'text-[#FF5A5F]' : 'text-[#1C1B18]/80 hover:text-[#FF5A5F]'
                }`}
              >
                <Sparkles className="w-4 h-4 text-[#FF5A5F]" />
                <span>{isAr ? 'خارطة الطريق (AI)' : 'Roadmap (AI)'}</span>
              </button>
            </nav>
          )}

          {/* Action Buttons */}
          <div className="flex items-center gap-2.5 xl:gap-4 shrink-0">
            {/* Language Toggle with Flag */}
            <button
              onClick={toggleLanguage}
              className="px-2.5 py-2 rounded-xl bg-white border border-[#E9E7E2] text-xs font-bold text-[#FF5A5F] hover:bg-[#FF5A5F]/5 transition-all cursor-pointer flex items-center gap-1.5 shrink-0 whitespace-nowrap"
            >
              <span>{isAr ? '🇺🇸 English' : '🇸🇦 العربية'}</span>
            </button>

            {/* Partners Dropdown Portal */}
            <div className="relative">
              <button 
                onClick={() => setShowPartnerDropdown(!showPartnerDropdown)}
                className="flex items-center gap-1.5 text-[14px] xl:text-[15px] font-semibold text-[#FF5A5F] hover:text-[#E04B50] px-3 py-2 rounded-xl hover:bg-[#FF5A5F]/5 transition-all duration-200 cursor-pointer whitespace-nowrap shrink-0"
              >
                <Building className="w-4 h-4" />
                <span>{isAr ? 'بوابة الشركاء' : 'Partners Portal'}</span>
                <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-300 ${showPartnerDropdown ? 'rotate-180' : ''}`} />
              </button>

              {showPartnerDropdown && (
                <>
                  <div 
                    className="fixed inset-0 z-40 bg-transparent" 
                    onClick={() => setShowPartnerDropdown(false)}
                  />
                  <div className={`absolute ${isAr ? 'left-0' : 'right-0'} mt-2 w-72 bg-white border border-[#E9E7E2] rounded-2xl shadow-xl z-50 py-2 animate-fadeIn`}>
                    <div className="px-4 py-2 border-b border-[#F6F6F4] mb-1">
                      <p className="text-[10px] font-bold text-[#6E6A63] tracking-wider uppercase">
                        {isAr ? 'خدمات شركاء CONFIRMED' : 'CONFIRMED PARTNER SERVICES'}
                      </p>
                    </div>

                    <button
                      onClick={() => {
                        setShowPartnerDropdown(false);
                        setShowLoginModal(true);
                        setLoginStep(1);
                        setErrorMessage('');
                      }}
                      className="w-full flex items-center gap-3 px-4 py-3 text-right rtl:text-right text-xs font-semibold text-[#1C1B18] hover:bg-[#FF5A5F]/5 hover:text-[#FF5A5F] transition-all cursor-pointer border-none bg-transparent"
                    >
                      <LogIn className="w-4 h-4 text-[#FF5A5F] shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="font-bold text-[#14332B] hover:text-[#FF5A5F] transition-colors">{isAr ? 'بوابة تسجيل دخول الشركاء' : 'Partner Sign In Gateway'}</p>
                        <p className="text-[10px] text-[#6E6A63] font-normal truncate">{isAr ? 'تسجيل الدخول للوحة تحكم صالونك' : 'Access your salon dashboard'}</p>
                      </div>
                    </button>

                    <button
                      onClick={() => {
                        setShowPartnerDropdown(false);
                        setShowRegisterModal(true);
                        setRegisterStep(1);
                        setRegFormError('');
                      }}
                      className="w-full flex items-center gap-3 px-4 py-3 text-right rtl:text-right text-xs font-semibold text-[#1C1B18] hover:bg-[#FF5A5F]/5 hover:text-[#FF5A5F] transition-all cursor-pointer border-none bg-transparent"
                    >
                      <Briefcase className="w-4 h-4 text-[#FF5A5F] shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="font-bold text-[#14332B] hover:text-[#FF5A5F] transition-colors">{isAr ? 'طلب تسجيل كشريك جديد' : 'Register New Partner Account'}</p>
                        <p className="text-[10px] text-[#6E6A63] font-normal truncate">{isAr ? 'انضمي إلينا كمزود خدمة في المنصة' : 'Join as a service provider'}</p>
                      </div>
                    </button>
                  </div>
                </>
              )}
            </div>

            {isMobile && (
              <button 
                onClick={() => setMobileOpen(!mobileOpen)}
                className="p-2 rounded-xl border border-[#E9E7E2] bg-white text-[#FF5A5F] cursor-pointer shrink-0"
              >
                {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            )}
          </div>
        </div>

        {/* Mobile Navigation Panel */}
        {isMobile && mobileOpen && (
          <div className="bg-white border-b border-[#E9E7E2] px-6 py-6 flex flex-col gap-3 animate-fadeIn">
            <a href="#features" onClick={() => { setMobileOpen(false); setActiveView('home'); }} className="text-[16px] py-2 text-[#1C1B18] font-medium border-b border-[#F6F6F4]">{isAr ? 'المميزات' : 'Features'}</a>
            <a href="#how" onClick={() => { setMobileOpen(false); setActiveView('home'); }} className="text-[16px] py-2 text-[#1C1B18] font-medium border-b border-[#F6F6F4]">{isAr ? 'كيف يعمل' : 'How It Works'}</a>
            <a href="#pricing" onClick={() => { setMobileOpen(false); setActiveView('home'); }} className="text-[16px] py-2 text-[#1C1B18] font-medium border-b border-[#F6F6F4]">{isAr ? 'الأسعار' : 'Pricing'}</a>
            <a href="#faq" onClick={() => { setMobileOpen(false); setActiveView('home'); }} className="text-[16px] py-2 text-[#1C1B18] font-medium border-b border-[#F6F6F4]">{isAr ? 'الأسئلة الشائعة' : 'FAQ'}</a>
            <a href="#contact" onClick={() => { setMobileOpen(false); setActiveView('home'); }} className="text-[16px] py-2 text-[#1C1B18] font-medium border-b border-[#F6F6F4]">{isAr ? 'اتصلي بنا' : 'Contact Us'}</a>
            <button 
              onClick={() => {
                setMobileOpen(false);
                setActiveView('roadmap');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }} 
              className="text-[16px] py-2 text-[#FF5A5F] font-semibold border-b border-[#F6F6F4] text-left rtl:text-right flex items-center gap-1 bg-transparent border-none cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-[#FF5A5F]" />
              <span>{isAr ? 'خارطة الطريق (AI)' : 'Roadmap (AI)'}</span>
            </button>
            <button 
              onClick={() => { setMobileOpen(false); setShowLoginModal(true); setLoginStep(1); setErrorMessage(''); }}
              className="mt-4 w-full py-3 border border-[#FF5A5F] text-[#FF5A5F] rounded-xl font-bold text-center text-[15px] cursor-pointer"
            >
              {isAr ? 'بوابة تسجيل الدخول للشركاء 🔑' : 'Partner Login Gateway 🔑'}
            </button>
            <button 
              onClick={() => { setMobileOpen(false); setShowRegisterModal(true); setRegisterStep(1); setRegFormError(''); }}
              className="w-full py-3 bg-[#14332B] text-white rounded-xl font-bold text-center text-[15px] cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Sparkles className="w-4 h-4 text-[#FF5A5F]" />
              <span>{isAr ? 'تسجيل كمزود خدمة 🌟' : 'Register as Provider 🌟'}</span>
            </button>
          </div>
        )}
      </header>

      {activeView === 'roadmap' ? (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="mb-8 flex justify-between items-center">
            <button
              onClick={() => {
                setActiveView('home');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="flex items-center gap-2 text-sm font-semibold text-[#FF5A5F] hover:text-[#E04B50] transition-colors cursor-pointer bg-white px-4 py-2 rounded-xl border border-[#E9E7E2] shadow-sm"
            >
              <span>{isAr ? '← العودة للرئيسية' : '← Back to Home'}</span>
            </button>
          </div>
          <RoadmapManager isAr={isAr} />
        </div>
      ) : (
        <>
          {/* ===== HERO ===== */}
          <section className="py-16 md:py-24 overflow-hidden bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#FFF0F0] border border-[#E9E7E2] text-xs font-semibold text-[#FF5A5F]">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>{isAr ? 'مصمّم خصيصاً لصالونات ومراكز السبا في السعودية 🇸🇦' : 'Tailored for Salons & Spas in Saudi Arabia 🇸🇦'}</span>
              </div>
              <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl text-[#14332B] font-bold leading-[1.2]">
                {isAr ? (
                  <>
                    صالونك يشتغل بنظام..<br />
                    وأنتِ تركّزين على <span className="text-[#FF5A5F] font-semibold underline decoration-wavy decoration-[#FF5A5F]/30">الإبداع</span>
                  </>
                ) : (
                  <>
                    Your Salon on Autopilot..<br />
                    While You Focus on <span className="text-[#FF5A5F] font-semibold underline decoration-wavy decoration-[#FF5A5F]/30">Creativity</span>
                  </>
                )}
              </h1>
              <p className="text-lg md:text-xl text-[#6E6A63] font-normal leading-relaxed max-w-2xl">
                {isAr 
                  ? 'نظام CONFIRMED السحابي يدير الحجوزات، الكاشير ونقاط البيع، الفواتير الإلكترونية المعتمدة وقاعدة بيانات عميلاتك من مكان واحد—عشان يقل الغياب عن المواعيد، وتزيد مبيعاتك بنسبة تفوق 30٪.'
                  : 'CONFIRMED cloud-based platform manages bookings, smart cash drawer POS, compliant electronic billing, and client history in one single hub—cutting down no-shows and driving sales by up to 30%.'}
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <a 
                  href="#pricing" 
                  className="bg-[#FF5A5F] hover:bg-[#E04B50] text-white text-base font-bold px-8 py-4 rounded-xl shadow-xl shadow-[#FF5A5F]/20 hover:shadow-[#FF5A5F]/30 text-center transition-all duration-200"
                >
                  {isAr ? 'ابدئي تجربتك المجانية (١٤ يوماً)' : 'Start Your 14-Day Free Trial'}
                </a>
                <a 
                  href="#contact" 
                  className="border-2 border-[#FF5A5F] hover:bg-[#FF5A5F]/5 text-[#FF5A5F] text-base font-bold px-8 py-4 rounded-xl text-center transition-all duration-200"
                >
                  {isAr ? 'اطلبي عرضاً توضيحياً' : 'Request a Live Demo'}
                </a>
              </div>

              <div className="flex items-center gap-6 text-sm text-[#6E6A63] pt-4">
                <span className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                  <span>{isAr ? 'لا يتطلب بطاقة ائتمانية' : 'No credit card required'}</span>
                </span>
                <span className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                  <span>{isAr ? 'إلغاء في أي وقت' : 'Cancel anytime'}</span>
                </span>
              </div>
            </div>

            {/* Visual Hero Mockup widget */}
            <div className="lg:col-span-5">
              <div className="relative bg-white border border-[#E9E7E2] rounded-3xl shadow-2xl p-6 md:p-8 overflow-hidden max-w-md mx-auto">
                <div className="absolute top-0 left-0 right-0 h-1.5 bg-[#FF5A5F]" />
                
                <div className="flex justify-between items-center mb-6 gap-3">
                  <div>
                    <h3 className="font-bold text-lg text-[#1C1B18]">{isAr ? 'جدول مواعيد اليوم' : "Today's Appointment Board"}</h3>
                    <p className="text-xs text-[#6E6A63]">{isAr ? 'الثلاثاء، ١٤ ذو الحجة ١٤٤٧' : 'Tuesday, 14 Dhu al-Hijjah 1447'}</p>
                  </div>
                  <span className="bg-emerald-50 text-emerald-700 text-xs font-semibold px-2.5 py-1 rounded-full border border-emerald-100 whitespace-nowrap">
                    {isAr ? 'فرع الرياض - التخصصي' : 'Riyadh Branch'}
                  </span>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center gap-4 p-3 rounded-2xl bg-[#F6F6F4] border border-[#E9E7E2]">
                    <span className="text-sm font-bold text-[#FF5A5F] min-w-[50px] font-mono">10:00 AM</span>
                    <div className="flex-1">
                      <p className="text-sm font-bold text-[#1C1B18]">{isAr ? 'سارة المطيري' : 'Sara Al-Mutairi'}</p>
                      <p className="text-xs text-[#6E6A63]">{isAr ? 'قص وسشوار مع أمل' : 'Cut & Blowdry with Amal'}</p>
                    </div>
                    <span className="bg-emerald-50 text-emerald-700 text-[11px] font-semibold px-2 py-0.5 rounded-full">
                      {isAr ? 'مؤكد' : 'Confirmed'}
                    </span>
                  </div>

                  <div className="flex items-center gap-4 p-3 rounded-2xl bg-[#F6F6F4] border border-[#E9E7E2]">
                    <span className="text-sm font-bold text-[#FF5A5F] min-w-[50px] font-mono">11:30 AM</span>
                    <div className="flex-1">
                      <p className="text-sm font-bold text-[#1C1B18]">{isAr ? 'نوف العتيبي' : 'Nouf Al-Otaibi'}</p>
                      <p className="text-xs text-[#6E6A63]">{isAr ? 'عناية بالأظافر مع شهد' : 'Nails Spa with Shahad'}</p>
                    </div>
                    <span className="bg-emerald-50 text-emerald-700 text-[11px] font-semibold px-2 py-0.5 rounded-full">
                      {isAr ? 'مؤكد' : 'Confirmed'}
                    </span>
                  </div>

                  <div className="flex items-center gap-4 p-3 rounded-2xl bg-[#FFF0F0] border border-[#FF5A5F]/20">
                    <span className="text-sm font-bold text-[#FF5A5F] min-w-[50px] font-mono">01:00 PM</span>
                    <div className="flex-1">
                      <p className="text-sm font-bold text-[#1C1B18]">{isAr ? 'حصة الكثيري' : 'Hessa Al-Katheeri'}</p>
                      <p className="text-xs text-[#FF5A5F]">{isAr ? 'جلسة سبا ٩٠ دقيقة (أونلاين)' : '90 Min Spa Treatment (Online)'}</p>
                    </div>
                    <span className="bg-[#FF5A5F] text-white text-[11px] font-semibold px-2 py-0.5 rounded-full">
                      {isAr ? 'جديد' : 'New'}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3 mt-6 pt-6 border-t border-[#E9E7E2] text-center">
                  <div className="p-2.5 bg-[#F6F6F4] rounded-xl border border-[#E9E7E2]">
                    <p className="text-xl font-serif font-bold text-[#FF5A5F]">7</p>
                    <p className="text-[10px] text-[#6E6A63]">{isAr ? 'حجوزات مؤكدة' : 'Confirmed Bookings'}</p>
                  </div>
                  <div className="p-2.5 bg-[#F6F6F4] rounded-xl border border-[#E9E7E2]">
                    <p className="text-xl font-serif font-bold text-[#FF5A5F]">1,280</p>
                    <p className="text-[10px] text-[#6E6A63]">{isAr ? 'إجمالي مبيعات (ر.س)' : 'Total Sales (SAR)'}</p>
                  </div>
                  <div className="p-2.5 bg-[#F6F6F4] rounded-xl border border-[#E9E7E2]">
                    <p className="text-xl font-serif font-bold text-emerald-600">98٪</p>
                    <p className="text-[10px] text-[#6E6A63]">{isAr ? 'حضور المواعيد' : 'Attendance Rate'}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== TRUST BAR ===== */}
      <div className="py-10 bg-[#F6F6F4] border-t border-b border-[#E9E7E2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-sm font-semibold tracking-wide text-[#FF5A5F] uppercase mb-4">
            {isAr ? 'تثق بنا صالونات ومراكز سبا كبرى في المملكة العربية السعودية 🇸🇦' : 'TRUSTED BY LEADING SALONS & CLINICS IN SAUDI ARABIA 🇸🇦'}
          </p>
          <div className="flex flex-wrap justify-center items-center gap-x-12 gap-y-6 text-[#6E6A63] text-lg font-serif">
            <span className="font-bold hover:text-[#FF5A5F] transition-colors cursor-pointer">{isAr ? 'لُجَين سبا' : 'Lujain Spa'}</span>
            <span className="font-bold hover:text-[#FF5A5F] transition-colors cursor-pointer">{isAr ? 'مرايا بيوتي لاونج' : 'Maraya Lounge'}</span>
            <span className="font-bold hover:text-[#FF5A5F] transition-colors cursor-pointer">{isAr ? 'دار الغيم للعناية' : 'Dar Al-Ghaim'}</span>
            <span className="font-bold hover:text-[#FF5A5F] transition-colors cursor-pointer">{isAr ? 'تالة لاونج' : 'Tala Care'}</span>
            <span className="font-bold hover:text-[#FF5A5F] transition-colors cursor-pointer">{isAr ? 'وتين التجميل' : 'Wateen Beauty'}</span>
          </div>
        </div>
      </div>

      {/* ===== FEATURES SECTIONS ===== */}
      <section id="features" className="py-20 md:py-28 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
            <h2 className="font-serif text-3xl sm:text-4xl text-[#14332B] font-bold leading-tight">
              {isAr ? 'كل الأدوات اللي تحتاجينها لإدارة صالونك باحترافية كاملة' : 'Complete toolkit to manage your salon professionally'}
            </h2>
            <p className="text-base sm:text-lg text-[#6E6A63]">
              {isAr 
                ? 'بنينا نظام CONFIRMED ليلبي تطلعات رائدات الأعمال في مجال التجميل، ليريحك من جداول الإكسل والواتساب المشتت.'
                : 'We built CONFIRMED to meet the growing ambitions of beauty center owners, freeing you from chaotic WhatsApp schedules and Excel spreadsheets.'}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Card 1 */}
            <div className="bg-white border border-[#E9E7E2] rounded-2xl p-6 hover:shadow-xl transition-all duration-300 group">
              <div className="w-12 h-12 rounded-xl bg-[#FFF0F0] text-[#FF5A5F] flex items-center justify-center mb-5 group-hover:bg-[#FF5A5F] group-hover:text-white transition-all duration-300">
                <Calendar className="w-6 h-6" />
              </div>
              <h3 className="font-serif text-xl font-bold text-[#1C1B18] mb-2">{isAr ? 'إدارة الحجوزات والتقويم' : 'Bookings & Dynamic Calendar'}</h3>
              <p className="text-sm text-[#6E6A63] leading-relaxed">
                {isAr 
                  ? 'تقويم تفاعلي مرن يسجل الحجوزات، يعيد جدولتها بالسحب والإفلات، ويظهر أوقات انشغال وخلو خبيرات التجميل في الصالون بدقة.'
                  : 'Flexible interactive calendar to schedule bookings, drag-and-drop slots, and easily visualize real-time stylist availability.'}
              </p>
            </div>

            {/* Card 2 */}
            <div className="bg-white border border-[#E9E7E2] rounded-2xl p-6 hover:shadow-xl transition-all duration-300 group">
              <div className="w-12 h-12 rounded-xl bg-[#FFF0F0] text-[#FF5A5F] flex items-center justify-center mb-5 group-hover:bg-[#FF5A5F] group-hover:text-white transition-all duration-300">
                <ShoppingBag className="w-6 h-6" />
              </div>
              <h3 className="font-serif text-xl font-bold text-[#1C1B18] mb-2">{isAr ? 'نقاط البيع والفاتورة الإلكترونية' : 'POS Checkout & Compliant E-Billing'}</h3>
              <p className="text-sm text-[#6E6A63] leading-relaxed">
                {isAr 
                  ? 'كاشير مبيعات متكامل للخدمات والمنتجات، يدعم تطبيق ضريبة القيمة المضافة ومستوفٍ لمتطلبات هيئة الزكاة والضريبة والجمارك (Fatoorah).'
                  : 'Robust checkout cashier for salon services and retail, applying VAT with fully compliant ZATCA Phase-II e-invoicing.'}
              </p>
            </div>

            {/* Card 3 */}
            <div className="bg-white border border-[#E9E7E2] rounded-2xl p-6 hover:shadow-xl transition-all duration-300 group">
              <div className="w-12 h-12 rounded-xl bg-[#FFF0F0] text-[#FF5A5F] flex items-center justify-center mb-5 group-hover:bg-[#FF5A5F] group-hover:text-white transition-all duration-300">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="font-serif text-xl font-bold text-[#1C1B18] mb-2">{isAr ? 'إدارة المخزون والتنبيهات' : 'Smart Stock Alerts & Inventory'}</h3>
              <p className="text-sm text-[#6E6A63] leading-relaxed">
                {isAr 
                  ? 'تتبعي المنتجات والمواد الاستهلاكية للصالون. تنبيهات ذكية تخبرك بنقص المنتجات قبل نفادها لتتفادي أي انقطاع في تقديم الخدمات.'
                  : 'Track backbar supplies and commercial retail products. Receive automatic flags when items reach minimal safety stock levels.'}
              </p>
            </div>

            {/* Card 4 */}
            <div className="bg-white border border-[#E9E7E2] rounded-2xl p-6 hover:shadow-xl transition-all duration-300 group">
              <div className="w-12 h-12 rounded-xl bg-[#FFF0F0] text-[#FF5A5F] flex items-center justify-center mb-5 group-hover:bg-[#FF5A5F] group-hover:text-white transition-all duration-300">
                <User className="w-6 h-6" />
              </div>
              <h3 className="font-serif text-xl font-bold text-[#1C1B18] mb-2">{isAr ? 'إدارة العميلات وعلاقاتهن (CRM)' : 'CRM & Rich Client Profiles'}</h3>
              <p className="text-sm text-[#6E6A63] leading-relaxed">
                {isAr 
                  ? 'ملف خاص لكل عميلة يشمل تفضيلات صبغ الشعر، حساسية البشرة، عدد الزيارات، ومجموع مبيعاتها لمكافأتها على ولائها لصالونك.'
                  : 'Dedicated customer database logging custom hair dye preferences, skin allergies, total visits, and spent history for loyalty.'}
              </p>
            </div>

            {/* Card 5 */}
            <div className="bg-white border border-[#E9E7E2] rounded-2xl p-6 hover:shadow-xl transition-all duration-300 group">
              <div className="w-12 h-12 rounded-xl bg-[#FFF0F0] text-[#FF5A5F] flex items-center justify-center mb-5 group-hover:bg-[#FF5A5F] group-hover:text-white transition-all duration-300">
                <Mail className="w-6 h-6" />
              </div>
              <h3 className="font-serif text-xl font-bold text-[#1C1B18] mb-2">{isAr ? 'أدوات تسويق وعروض ذكية' : 'Smart Marketing & SMS'}</h3>
              <p className="text-sm text-[#6E6A63] leading-relaxed">
                {isAr 
                  ? 'أرسلي حملات تسويق آلية ومخصصة عبر الواتساب والـ SMS للعميلات في المناسبات والأعياد، وصممي كوبونات خصم لزيادة الإقبال.'
                  : 'Launch target marketing campaigns over SMS & WhatsApp, issue discount promo codes and reward repeat visits.'}
              </p>
            </div>

            {/* Card 6 */}
            <div className="bg-white border border-[#E9E7E2] rounded-2xl p-6 hover:shadow-xl transition-all duration-300 group">
              <div className="w-12 h-12 rounded-xl bg-[#FFF0F0] text-[#FF5A5F] flex items-center justify-center mb-5 group-hover:bg-[#FF5A5F] group-hover:text-white transition-all duration-300">
                <Heart className="w-6 h-6" />
              </div>
              <h3 className="font-serif text-xl font-bold text-[#1C1B18] mb-2">{isAr ? 'بطاقات الهدايا والعضويات' : 'Gift Cards & Memberships'}</h3>
              <p className="text-sm text-[#6E6A63] leading-relaxed">
                {isAr 
                  ? 'أصدري بطاقات هدايا الكترونية مميزة وباقات عضوية اشتراك شهري لضمان إيراد متكرر وبناء ولاء عميق مع العميلات المترددات.'
                  : 'Issue digital electronic gift certificates and monthly membership packages to secure stable predictable recurring revenue.'}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ===== HOW IT WORKS SECTION ===== */}
      <section id="how" className="py-20 md:py-28 bg-gradient-to-r from-[#F1F5F9] to-[#E2E8F0] text-[#1E293B] border-y border-slate-200/60 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-[#FF5A5F]/5 rounded-full blur-3xl -mr-20 -mt-20"></div>
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-blue-400/5 rounded-full blur-2xl -ml-40 -mb-40"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
            <h2 className="font-serif text-3xl sm:text-4xl text-slate-900 font-normal leading-tight">
              {isAr ? 'سهل ومرن.. تبدئين وتطلقين عملك خلال دقائق' : 'Simple & fast.. Set up and launch in minutes'}
            </h2>
            <p className="text-slate-600 text-base">
              {isAr 
                ? 'لا داعي للقلق من التثبيت أو التعقيد التقني. صممنا واجهات النظام لتكون بسيطة ومريحة للموظفات.'
                : 'No complex installations or local database setup required. Fully designed for immediate adoption by salon employees.'}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white/85 backdrop-blur-sm border border-slate-200 rounded-2xl p-8 space-y-4 relative shadow-sm">
              <div className="w-10 h-10 rounded-full bg-[#FF5A5F] text-white text-lg font-serif font-bold flex items-center justify-center">
                {isAr ? '١' : '1'}
              </div>
              <h3 className="font-serif text-xl font-bold text-slate-900">{isAr ? 'إنشاء حسابك وتخصيصه' : 'Configure Salon Profile'}</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                {isAr 
                  ? 'سجّلي صالونك، أدخلي قائمة الخدمات والأسعار، وحددي خبيرات التجميل وساعات عملهن بسهولة تامة.'
                  : 'Register your business, enter your service treatments and prices, and assign working shifts to beauticians.'}
              </p>
            </div>

            <div className="bg-white/85 backdrop-blur-sm border border-slate-200 rounded-2xl p-8 space-y-4 relative shadow-sm">
              <div className="w-10 h-10 rounded-full bg-[#FF5A5F] text-white text-lg font-serif font-bold flex items-center justify-center">
                {isAr ? '٢' : '2'}
              </div>
              <h3 className="font-serif text-xl font-bold text-slate-900">{isAr ? 'تفعيل رابط الحجز الذاتي' : 'Activate Online Bookings'}</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                {isAr 
                  ? 'سيكون لديك صفحة حجوزات أنيقة مخصصة بهوية صالونك لتقوم عميلاتك بالحجز واختيار الخدمات والوقت المناسب لهن.'
                  : 'Get a clean, premium self-service booking page customized with your branding so clients can book 24/7.'}
              </p>
            </div>

            <div className="bg-white/85 backdrop-blur-sm border border-slate-200 rounded-2xl p-8 space-y-4 relative shadow-sm">
              <div className="w-10 h-10 rounded-full bg-[#FF5A5F] text-white text-lg font-serif font-bold flex items-center justify-center">
                {isAr ? '٣' : '3'}
              </div>
              <h3 className="font-serif text-xl font-bold text-slate-900">{isAr ? 'تشغيل الكاشير والتذكيرات' : 'Enable POS & Auto Reminders'}</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                {isAr 
                  ? 'سيبدأ النظام تلقائياً بإرسال رسائل تذكير للعميلات قبل موعدهن لتقليل الغيابات، وتتمكنين من محاسبتهن وإصدار فواتير ذكية.'
                  : 'Automated WhatsApp alerts trigger prior to appointments. Run checkout tickets and issue certified tax receipts.'}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ===== PRICING SECTION ===== */}
      <section id="pricing" className="py-20 md:py-28 bg-[#F6F6F4]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
            <h2 className="font-serif text-3xl sm:text-4xl text-[#1E293B] font-normal leading-tight">
              {isAr ? 'باقات تناسب جميع الصالونات ومراكز السبا' : 'Flexible pricing packages for any salon size'}
            </h2>
            <p className="text-[#6E6A63] text-base mb-8">
              {isAr 
                ? 'لا توجد رسوم خفية. جربي أي باقة مجاناً لمدة ١٤ يوماً دون الحاجة لبطاقة ائتمان.'
                : 'No hidden setup fees. Try any tier for 14 days for free with absolutely zero obligation.'}
            </p>
            
            <div className="inline-flex items-center gap-1 bg-white border border-[#E9E7E2] rounded-full p-1 shadow-inner">
              <button 
                onClick={() => setBilling('monthly')}
                className={`text-xs font-bold px-4 py-2 rounded-full transition-all duration-200 cursor-pointer ${
                  billing === 'monthly' ? 'bg-[#FF5A5F] text-white' : 'text-[#6E6A63]'
                }`}
              >
                {isAr ? 'الدفع شهرياً' : 'Monthly'}
              </button>
              <button 
                onClick={() => setBilling('yearly')}
                className={`text-xs font-bold px-4 py-2 rounded-full transition-all duration-200 cursor-pointer ${
                  billing === 'yearly' ? 'bg-[#FF5A5F] text-white' : 'text-[#6E6A63]'
                }`}
              >
                {isAr ? 'الدفع سنوياً (توفير ٢٠٪)' : 'Yearly (Save 20%)'}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 items-stretch justify-center">
            {packages.map((pkg: any) => {
              const displayPrice = billing === 'monthly' ? pkg.priceMonthly : pkg.priceYearly;
              return (
                <div 
                  key={pkg.id}
                  className={`bg-white border rounded-3xl p-8 flex flex-col justify-between shadow-lg relative transition-all duration-200 ${
                    pkg.isPopular 
                      ? 'border-[#FF5A5F] ring-1 ring-[#FF5A5F]/20 scale-100 lg:scale-105 z-10' 
                      : 'border-[#E9E7E2]'
                  }`}
                >
                  {pkg.isPopular && (
                    <span className="absolute -top-3.5 right-6 bg-[#FF5A5F] text-white text-[11px] font-bold px-3 py-1 rounded-full border border-[#FF5A5F]">
                      {isAr ? 'الباقة الأكثر طلباً واختياراً' : 'Most Popular Plan'}
                    </span>
                  )}
                  {pkg.isEnterpriseContact && (
                    <span className="absolute -top-3.5 left-6 bg-[#14332B] text-white text-[11px] font-bold px-3 py-1 rounded-full border border-[#14332B]">
                      {isAr ? 'سلاسل ومؤسسات' : 'Enterprise'}
                    </span>
                  )}

                  <div>
                    <h3 className="font-serif text-xl font-bold text-[#14332B] mb-2">
                      {isAr ? pkg.nameAr : pkg.nameEn}
                    </h3>
                    <p className="text-[#6E6A63] text-xs mb-6">
                      {isAr ? pkg.descriptionAr : pkg.descriptionEn}
                    </p>
                    
                    <div className="mb-6">
                      {pkg.isEnterpriseContact ? (
                        <div>
                          <span className="font-serif text-3xl font-bold text-[#14332B]">{isAr ? 'تواصل معنا' : 'Contact Us'}</span>
                          <p className="text-xs text-[#6E6A63] mt-1">{isAr ? 'تخصيص كامل وحلول مخصصة' : 'Custom integrations & custom ERP systems'}</p>
                        </div>
                      ) : (
                        <div>
                          <span className="font-serif text-4xl font-bold text-[#FF5A5F]">{displayPrice}</span>
                          <span className="text-xs text-[#6E6A63] font-medium mr-1">{t('currency')} {periodLabel}</span>
                        </div>
                      )}
                    </div>

                    <div className="w-full h-px bg-[#E9E7E2] my-6" />

                    <ul className="space-y-4 text-sm text-[#1C1B18]/90">
                      {(isAr ? pkg.featuresAr : pkg.featuresEn)?.map((feat: string, idx: number) => (
                        <li key={idx} className="flex items-start gap-2">
                          <Check className="w-4 h-4 text-[#FF5A5F] mt-0.5 shrink-0" />
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="pt-8">
                    {pkg.isEnterpriseContact ? (
                      <a 
                        href="#contact" 
                        className="block w-full py-3.5 border-2 border-slate-700 text-slate-700 hover:bg-slate-700 hover:text-white text-center font-bold text-sm rounded-xl transition-all duration-200"
                      >
                        {isAr ? 'اطلبي عرضاً توضيحياً' : 'Request Demo Details'}
                      </a>
                    ) : (
                      <button 
                        onClick={() => {
                          setSelectedPackage(pkg.id);
                          setShowRegisterModal(true);
                          setRegisterStep(1);
                          setRegFormError('');
                        }}
                        className={`w-full py-3.5 font-bold text-sm rounded-xl transition-all duration-200 cursor-pointer ${
                          pkg.isPopular 
                            ? 'bg-[#FF5A5F] hover:bg-[#FFAE34] text-white shadow-lg shadow-[#FF5A5F]/20' 
                            : 'border-2 border-[#FF5A5F] text-[#FF5A5F] hover:bg-[#FF5A5F] hover:text-white'
                        }`}
                      >
                        {isAr ? 'ابدئي تجربتك المجانية' : 'Start Free Trial'}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ===== TESTIMONIALS SECTION ===== */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
            <h2 className="font-serif text-3xl text-[#14332B] font-bold">{isAr ? 'صاحبات صالونات يتكلمن عن CONFIRMED' : 'Success Stories from CONFIRMED Partners'}</h2>
            <p className="text-[#6E6A63] text-sm">{isAr ? 'نحن نفخر بالنمو مع عائلتنا المتنامية من صالونات التجميل في السعودية.' : 'We are proud to grow alongside hundreds of beauty establishments in Saudi Arabia.'}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-[#F6F6F4] border border-[#E9E7E2] rounded-3xl p-8 space-y-6 flex flex-col justify-between">
              <p className="text-[15px] text-[#1C1B18]/90 italic leading-relaxed">
                {isAr 
                  ? '"قبل CONFIRMED كنا نواجه مشكلة كبيرة في غياب العميلات أو تأخرهن عن المواعيد، مما يؤثر على دخل الصالون. الآن بفضل تذكيرات الواتساب التلقائية انخفضت نسبة الغياب لقرابة الصفر!"'
                  : '"Before CONFIRMED we struggled constantly with client no-shows and delayed slots, affecting our revenue. Now with automatic WhatsApp reminders, our no-show rate is virtually zero!"'}
              </p>
              <div className="flex items-center gap-3 pt-4 border-t border-[#E9E7E2]">
                <div className="w-10 h-10 rounded-full bg-[#FF5A5F] flex items-center justify-center text-white font-serif font-bold text-sm">
                  {isAr ? 'ع' : 'O'}
                </div>
                <div>
                  <h4 className="font-bold text-sm text-[#1C1B18]">{isAr ? 'عهود الشلوي' : 'Ohood Al-Shalawi'}</h4>
                  <p className="text-[11px] text-[#6E6A63]">{isAr ? 'مالكة صالون عهود بيوتي لاونج - الرياض' : 'Owner, Ohood Beauty Lounge - Riyadh'}</p>
                </div>
              </div>
            </div>

            <div className="bg-[#F6F6F4] border border-[#E9E7E2] rounded-3xl p-8 space-y-6 flex flex-col justify-between">
              <p className="text-[15px] text-[#1C1B18]/90 italic leading-relaxed">
                {isAr 
                  ? '"نقاط البيع والفواتير الإلكترونية سريعة وممتازة، النظام مرخص ومطابق لمتطلبات هيئة الزكاة والضريبة والجمارك والتقرير المالي أسبوعي ريحنا كثير في حساب الأرباح ونسب الموظفات."'
                  : '"The POS cashier and electronic billing are incredibly fast. The software is fully compliant with ZATCA rules and the weekly PDF sales report makes calculating stylist commissions and net profits painless."'}
              </p>
              <div className="flex items-center gap-3 pt-4 border-t border-[#E9E7E2]">
                <div className="w-10 h-10 rounded-full bg-[#FF5A5F] flex items-center justify-center text-white font-serif font-bold text-sm">
                  {isAr ? 'ن' : 'N'}
                </div>
                <div>
                  <h4 className="font-bold text-sm text-[#1C1B18]">{isAr ? 'نورة الفهيد' : 'Noura Al-Faheed'}</h4>
                  <p className="text-[11px] text-[#6E6A63]">{isAr ? 'مديرة سبا ومركز العناية بالبشرة - جدة' : 'Director, Skin Spa Center - Jeddah'}</p>
                </div>
              </div>
            </div>

            <div className="bg-[#F6F6F4] border border-[#E9E7E2] rounded-3xl p-8 space-y-6 flex flex-col justify-between">
              <p className="text-[15px] text-[#1C1B18]/90 italic leading-relaxed">
                {isAr 
                  ? '"صفحة الحجز الذاتي بهوية صالوننا ريحت عميلاتنا، صاروا يحجزون بالليل والشارع مسكر وحنا نايمين، ونجي الصبح نلقى الجدول مليان خدمات ممتازة جداً!"'
                  : '"The branded self-booking page is a hit with our clients. They can schedule their nails and treatments in the middle of the night, and we wake up to a beautifully organized schedule."'}
              </p>
              <div className="flex items-center gap-3 pt-4 border-t border-[#E9E7E2]">
                <div className="w-10 h-10 rounded-full bg-[#FF5A5F] flex items-center justify-center text-white font-serif font-bold text-sm">
                  {isAr ? 'م' : 'M'}
                </div>
                <div>
                  <h4 className="font-bold text-sm text-[#1C1B18]">{isAr ? 'منى القحطاني' : 'Mona Al-Qahtani'}</h4>
                  <p className="text-[11px] text-[#6E6A63]">{isAr ? 'صاحبة مركز تالة سبا النسائي - الدمام' : 'Founder, Tala Spa & Wellness - Dammam'}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== FAQ SECTION ===== */}
      <section id="faq" className="py-20 bg-[#F6F6F4]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 space-y-3">
            <h2 className="font-serif text-3xl text-[#14332B] font-bold">{isAr ? 'الأسئلة الشائعة' : 'Frequently Asked Questions'}</h2>
            <p className="text-[#6E6A63] text-sm">{isAr ? 'كل ما تودين معرفته حول نظام CONFIRMED لإدارة الصالونات' : 'Everything you need to know about CONFIRMED Salon software'}</p>
          </div>

          <div className="space-y-4">
            <details className="bg-white border border-[#E9E7E2] rounded-2xl p-5 group cursor-pointer">
              <summary className="font-bold text-[#14332B] text-[15px] flex justify-between items-center list-none">
                <span>{isAr ? 'هل الفاتورة الإلكترونية الصادرة معتمدة رسميًا؟' : 'Is the e-invoice officially certified by ZATCA?'}</span>
                <span className="text-[#FF5A5F] font-bold text-lg group-open:rotate-45 transition-transform duration-200">+</span>
              </summary>
              <p className="mt-3 text-sm text-[#6E6A63] leading-relaxed">
                {isAr 
                  ? 'نعم بالتأكيد، نظام CONFIRMED مهيأ ومتطابق بالكامل مع شروط هيئة الزكاة والضريبة والجمارك (المرحلة الأولى والمرحلة الثانية للربط والتكامل)، ويقوم بإصدار فاتورة إلكترونية مبسطة تحتوي على الـ QR Code المطلوب نظاماً.'
                  : 'Yes, absolutely. CONFIRMED is fully compliant with ZATCA (Phase 1 and Phase 2 integration), issuing compliant simplified electronic invoices containing the legally mandated QR codes.'}
              </p>
            </details>

            <details className="bg-white border border-[#E9E7E2] rounded-2xl p-5 group cursor-pointer">
              <summary className="font-bold text-[#14332B] text-[15px] flex justify-between items-center list-none">
                <span>{isAr ? 'هل أحتاج إلى شراء أجهزة خاصة لاستخدام CONFIRMED؟' : 'Do I need specific custom hardware to run CONFIRMED?'}</span>
                <span className="text-[#FF5A5F] font-bold text-lg group-open:rotate-45 transition-transform duration-200">+</span>
              </summary>
              <p className="mt-3 text-sm text-[#6E6A63] leading-relaxed">
                {isAr 
                  ? 'لا، نظام CONFIRMED سحابي بالكامل (Cloud-based). يمكنك تشغيله من أي جهاز متصل بالإنترنت—سواء كان آيباد (iPad)، تابلت، جوال، أو كمبيوتر مكتبي عادي، ولا يتطلب تركيب برمجيات معقدة.'
                  : 'No. CONFIRMED is 100% cloud-based. You can access and manage it from any browser-equipped device, including iPads, tablets, mobiles, or standard PCs, without installing any software.'}
              </p>
            </details>

            <details className="bg-white border border-[#E9E7E2] rounded-2xl p-5 group cursor-pointer">
              <summary className="font-bold text-[#14332B] text-[15px] flex justify-between items-center list-none">
                <span>{isAr ? 'هل تدعمون نقل العميلات والبيانات من نظام قديم؟' : 'Can you migrate our clients from our old legacy POS system?'}</span>
                <span className="text-[#FF5A5F] font-bold text-lg group-open:rotate-45 transition-transform duration-200">+</span>
              </summary>
              <p className="mt-3 text-sm text-[#6E6A63] leading-relaxed">
                {isAr 
                  ? 'نعم، فريق دعم CONFIRMED يساعدك مجاناً في استيراد ونقل قائمة عبييلتك، وقائمة الخدمات والأسعار من ملفات Excel أو أي نظام قديم لتبدئي العمل دون أي تشتت أو ضياع للبيانات.'
                  : 'Yes, our onboarding team provides free data migration. We will help import your clients, services menu, and pricing sheets directly from Excel spreadsheets or legacy programs.'}
              </p>
            </details>

            <details className="bg-white border border-[#E9E7E2] rounded-2xl p-5 group cursor-pointer">
              <summary className="font-bold text-[#14332B] text-[15px] flex justify-between items-center list-none">
                <span>{isAr ? 'كيف يعمل تذكير الواتساب والـ SMS؟' : 'How do the WhatsApp & SMS reminders trigger?'}</span>
                <span className="text-[#FF5A5F] font-bold text-lg group-open:rotate-45 transition-transform duration-200">+</span>
              </summary>
              <p className="mt-3 text-sm text-[#6E6A63] leading-relaxed">
                {isAr 
                  ? 'بمجرد تأكيد الحجز، يقوم النظام تلقائياً بجدولة رسائل مخصصة تذهب لجوال العميلة قبل الموعد بـ ٢٤ ساعة وتنبيه إضافي قبل الموعد بـ ٣ ساعات لمساعدتها في الحضور وتسهيل تأكيد أو إلغاء الحجز لتوفير مساحة لمواعيد أخرى.'
                  : 'Upon booking confirmation, our system automatically schedules personalized alerts sent to the clients phone 24 hours prior, with an additional nudge 3 hours before. This helps them attend on time or reschedule easily.'}
              </p>
            </details>
          </div>
        </div>
      </section>

      {/* ===== CONTACT / DEMO FORM SECTION ===== */}
      <section id="contact" className="py-20 bg-white border-t border-[#E9E7E2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            <div className="space-y-6">
              <span className="text-xs font-bold text-[#FF5A5F] tracking-wider uppercase">{isAr ? 'استشير خبيراتنا' : 'Talk with Our Onboarding Experts'}</span>
              <h2 className="font-serif text-3xl sm:text-4xl text-[#14332B] font-bold leading-tight">
                {isAr ? 'اطلبي عرضاً توضيحياً مجاناً وجرّبي نظام CONFIRMED' : 'Request a free live demo & guided tour of CONFIRMED'}
              </h2>
              <p className="text-[#6E6A63] text-base leading-relaxed">
                {isAr 
                  ? 'سيتواصل معك فريقنا لمساعدتك وتزويدك ببيانات الدخول، وشرح الميزات الملائمة لصالونك أو مركز السبا الخاص بك.'
                  : 'Our customer success team will contact you to set up your customized trial environment and walk you through CONFIRMED.'}
              </p>

              <div className="space-y-4 pt-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#FF5A5F]/10 text-[#FF5A5F] flex items-center justify-center">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs text-[#6E6A63]">{isAr ? 'راسلنا على البريد الإلكتروني' : 'Email Us directly'}</p>
                    <p className="text-sm font-bold text-[#1C1B18]">Ah@hotmail.com</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#FF5A5F]/10 text-[#FF5A5F] flex items-center justify-center">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs text-[#6E6A63]">{isAr ? 'رقم الاتصال المباشر وواتساب' : 'Direct Call or WhatsApp'}</p>
                    <p className="text-sm font-bold text-[#1C1B18]">920011445</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-[#F6F6F4] border border-[#E9E7E2] rounded-3xl p-8 shadow-inner">
              {!formSent ? (
                <form onSubmit={handleContactSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-[#1C1B18] mb-2">{isAr ? 'اسمك الكريم *' : 'Your Name *'}</label>
                      <input 
                        type="text" 
                        required
                        value={contactName}
                        onChange={(e) => setContactName(e.target.value)}
                        placeholder={isAr ? "سارة المطيري" : "e.g. Sara Al-Mutairi"}
                        className="w-full text-sm px-4 py-3 bg-white border border-[#E9E7E2] rounded-xl focus:outline-none focus:border-[#FF5A5F] text-[#1C1B18]"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-[#1C1B18] mb-2">{isAr ? 'نوع النشاط *' : 'Salon Type *'}</label>
                      <select 
                        value={facilityType}
                        onChange={(e) => setFacilityType(e.target.value)}
                        className="w-full text-sm px-4 py-3 bg-white border border-[#E9E7E2] rounded-xl focus:outline-none focus:border-[#FF5A5F] text-[#1C1B18]"
                      >
                        <option value="صالون نسائي">{isAr ? 'صالون نسائي متكامل' : 'Full Beauty Salon'}</option>
                        <option value="صالون شعر">{isAr ? 'صالون شعر وأظافر' : 'Hair & Nail Salon'}</option>
                        <option value="مركز سبا / مساج">{isAr ? 'مركز سبا و مساج' : 'Spa & Wellness Center'}</option>
                        <option value="عيادة تجميل">{isAr ? 'مركز وعيادة تجميل' : 'Cosmetic Clinic'}</option>
                        <option value="خدمات منزلية">{isAr ? 'صالون خدمات منزلية' : 'Home-Service Salon'}</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-[#1C1B18] mb-2">{isAr ? 'البريد الإلكتروني *' : 'Email Address *'}</label>
                      <input 
                        type="email" 
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="you@domain.com"
                        className="w-full text-sm px-4 py-3 bg-white border border-[#E9E7E2] rounded-xl focus:outline-none focus:border-[#FF5A5F] text-[#1C1B18]"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-[#1C1B18] mb-2">{isAr ? 'رقم جوال التواصل *' : 'Mobile Number *'}</label>
                      <input 
                        type="tel" 
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="05xxxxxxxx"
                        className="w-full text-sm px-4 py-3 bg-white border border-[#E9E7E2] rounded-xl focus:outline-none focus:border-[#FF5A5F] text-[#1C1B18]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#1C1B18] mb-2">{isAr ? 'أخبرينا عن صالونك وعملك (اختياري)' : 'Tell us about your business (Optional)'}</label>
                    <textarea 
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder={isAr ? "كم عدد الموظفات لديك؟ وما هي الصعوبات الحالية؟" : "How many stylists do you employ? What are your key pain points?"}
                      rows={3}
                      className="w-full text-sm px-4 py-3 bg-white border border-[#E9E7E2] rounded-xl focus:outline-none focus:border-[#FF5A5F] text-[#1C1B18]"
                    />
                  </div>

                  <button 
                    type="submit"
                    className="w-full py-3.5 bg-[#FF5A5F] hover:bg-[#FFAE34] text-white text-sm font-bold rounded-xl shadow-lg shadow-[#FF5A5F]/20 hover:shadow-[#FF5A5F]/30 transition-all duration-200 cursor-pointer"
                  >
                    {isAr ? 'إرسال طلب العرض التجريبي مجاناً' : 'Submit Free Demo Request'}
                  </button>
                </form>
              ) : (
                <div className="text-center py-8 space-y-4">
                  <div className="w-16 h-16 rounded-full bg-[#FF5A5F]/10 text-[#FF5A5F] flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-10 h-10" />
                  </div>
                  <h3 className="font-serif text-2xl font-bold text-slate-800">{isAr ? 'شكراً لاهتمامك بـ CONFIRMED ✓' : 'Thank You for Choosing CONFIRMED ✓'}</h3>
                  <p className="text-sm text-[#6E6A63] max-w-sm mx-auto">
                    {isAr 
                      ? `تم استلام طلبك بنجاح. سنقوم بمراجعة طلبك وإعداد نسختك التجريبية والتواصل معك على رقم الجوال ${phone} خلال ٢٤ ساعة القادمة.`
                      : `Your request was dispatched successfully. Our onboarding experts will contact you at ${phone} within 24 hours to set up your free trial demo.`}
                  </p>
                  <button 
                    onClick={() => setFormSent(false)}
                    className="text-xs font-bold text-[#FF5A5F] underline cursor-pointer"
                  >
                    {isAr ? 'إرسال طلب آخر' : 'Submit another request'}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </>
  )}

      {/* ===== FOOTER ===== */}
      <footer className="bg-[#F8FAFC] text-slate-500 pt-16 pb-8 border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            {/* Column 1: Brand Info */}
            <div className="space-y-4">
              <div className="flex flex-col gap-1">
                <div className="flex gap-1.5 items-center">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#FF5A5F] shadow-sm animate-pulse" />
                  <span className="w-2.5 h-2.5 rounded-full bg-[#9E9E9E] shadow-sm" />
                  <span className="w-2.5 h-2.5 rounded-full bg-[#FFAE34] shadow-sm" />
                </div>
                <span className="font-sans text-lg font-black tracking-[0.2em] text-[#14332B] leading-none block uppercase">CONFIRMED</span>
                <span className="text-[8px] font-semibold text-slate-400 tracking-wider leading-none block uppercase">{isAr ? 'سهولة الحجز' : 'EASY TO BOOK'}</span>
              </div>
              <p className="text-xs leading-relaxed text-slate-500">
                {isAr 
                  ? 'منصة سحابية سعودية متكاملة لإدارة صالونات التجميل ومراكز العناية والسبا النسائية والمنزلية وتسهيل المواعيد.'
                  : 'Saudi-integrated cloud platform engineered to run high-end beauty salons, wellness centers, and premium home services.'}
              </p>
            </div>

            {/* Column 2: System Features */}
            <div className="space-y-4">
              <h4 className="font-bold text-xs text-[#14332B] uppercase tracking-wider">{isAr ? 'المميزات الرئيسية' : 'Key Features'}</h4>
              <ul className="space-y-2 text-xs">
                <li><a href="#" className="hover:text-[#FF5A5F] transition-colors">{isAr ? 'إدارة الحجوزات والمواعيد' : 'Appointment Scheduling'}</a></li>
                <li><a href="#" className="hover:text-[#FF5A5F] transition-colors">{isAr ? 'نظام نقاط البيع POS' : 'Point of Sale (POS)'}</a></li>
                <li><a href="#" className="hover:text-[#FF5A5F] transition-colors">{isAr ? 'إدارة الموظفات والعملاء' : 'Staff & CRM Hub'}</a></li>
                <li><a href="#" className="hover:text-[#FF5A5F] transition-colors">{isAr ? 'التقارير الذكية والمحاسبة' : 'Smart Analytics & Reports'}</a></li>
              </ul>
            </div>

            {/* Column 3: Partner Portal Access */}
            <div className="space-y-4">
              <h4 className="font-bold text-xs text-[#14332B] uppercase tracking-wider">{isAr ? 'بوابة الشركاء' : 'B2B Partner Portal'}</h4>
              <ul className="space-y-2 text-xs">
                <li>
                  <button 
                    onClick={() => setShowLoginModal(true)} 
                    className="hover:text-[#FF5A5F] transition-colors bg-transparent border-none p-0 font-semibold text-[#FF5A5F] cursor-pointer flex items-center gap-1"
                  >
                    <Lock className="w-3 h-3" />
                    <span>{isAr ? 'دخول الشركاء والموظفين' : 'Merchant Secure Login'}</span>
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => setShowRegisterModal(true)} 
                    className="hover:text-[#FF5A5F] transition-colors bg-transparent border-none p-0 cursor-pointer"
                  >
                    {isAr ? 'تسجيل صالون جديد' : 'Register New Salon'}
                  </button>
                </li>
                <li><a href="#" className="hover:text-[#FF5A5F] transition-colors">{isAr ? 'الشروط والأحكام' : 'Terms of Service'}</a></li>
                <li><a href="#" className="hover:text-[#FF5A5F] transition-colors">{isAr ? 'سياسة الخصوصية' : 'Privacy Policy'}</a></li>
              </ul>
            </div>

            {/* Column 4: Contact & Verification */}
            <div className="space-y-4">
              <h4 className="font-bold text-xs text-[#14332B] uppercase tracking-wider">{isAr ? 'اتصلي بنا' : 'Contact Support'}</h4>
              <ul className="space-y-2 text-xs text-slate-500">
                <li>{isAr ? '📍 الرياض، المملكة العربية السعودية' : '📍 Riyadh, Saudi Arabia'}</li>
                <li>{isAr ? '✉️ الدعم الفني: support@confirmed.sa' : '✉️ Support: support@confirmed.sa'}</li>
                <li className="pt-2 font-mono text-[10px] text-emerald-600 font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                  <span>{isAr ? 'جميع الخوادم تعمل بنجاح' : 'All Systems Operational'}</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="pt-8 border-t border-slate-200 flex flex-col md:flex-row justify-between items-center gap-4 text-xs">
            <p className="text-slate-400">
              {isAr 
                ? '© ٢٠٢٦ كُونفيرمد. جميع الحقوق محفوظة لشركة كُونفيرمد لتقنية المعلومات.' 
                : '© 2026 CONFIRMED. All rights reserved. Registered under Confirmed Saudi IT Co.'}
            </p>
            <div className="flex gap-4">
              <span className="text-slate-400">{isAr ? 'صنع بفخر في المملكة العربية السعودية 🇸🇦' : 'Proudly crafted in Saudi Arabia 🇸🇦'}</span>
            </div>
          </div>
        </div>
      </footer>

      {/* ===== HIGH SECURITY MULTI-FACTOR LOGIN PORTAL MODAL ===== */}
      {showLoginModal && (
        <div className="fixed inset-0 bg-[#070b13]/95 backdrop-blur-xl flex items-center justify-center p-4 md:p-8 z-50 animate-fadeIn overflow-y-auto">
          {/* Subtle radial and grid glowing background to set the premium Dribbble mood */}
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-[#131d35] via-[#070b13] to-[#02050b] pointer-events-none" />
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:3rem_3rem] opacity-[0.05] pointer-events-none" />
          
          {/* Ambient organic glowing blobs of brand coral and emerald green */}
          <div className="absolute top-1/4 left-1/4 w-[30rem] h-[30rem] bg-[#FF5A5F]/10 rounded-full blur-[120px] pointer-events-none" />
          <div className="absolute bottom-1/4 right-1/4 w-[25rem] h-[25rem] bg-emerald-500/5 rounded-full blur-[100px] pointer-events-none" />

          {/* Core Login Card Box */}
          <div className="bg-[#0e1626]/90 border border-slate-800/80 rounded-[36px] w-full max-w-5xl shadow-2xl relative overflow-hidden grid grid-cols-1 lg:grid-cols-12 max-h-[92vh] lg:max-h-[88vh]">
            
            {/* Left Column: Security Badges, Minimal Info, and Cryptographic Keycards */}
            <div className="lg:col-span-5 bg-gradient-to-b from-[#111c30] to-[#0b1220] p-6 md:p-8 lg:p-10 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-slate-850 relative overflow-y-auto min-h-[300px] lg:min-h-0">
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#FF5A5F]/5 rounded-full blur-3xl pointer-events-none" />
              
              <div className="space-y-8 relative z-10">
                {/* Brand Logo & Secure Connection Signal */}
                <div className="flex items-center justify-between">
                  <div className="flex gap-2 items-center">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#FF5A5F] shadow-[0_0_10px_#FF5A5F]" />
                    <span className="font-sans text-xs font-black tracking-[0.25em] text-white">CONFIRMED B2B</span>
                  </div>
                  
                  {/* Subtle Language switcher for convenience inside portal */}
                  <button
                    type="button"
                    onClick={toggleLanguage}
                    className="px-2.5 py-1 rounded-lg bg-slate-800/60 border border-slate-700/50 hover:bg-slate-700 text-slate-300 text-[10px] font-bold transition-all"
                  >
                    {isAr ? 'EN' : 'AR'}
                  </button>
                </div>

                {/* Main Security Statement */}
                <div className="space-y-3">
                  <span className="text-[10px] font-bold text-[#FF5A5F] tracking-widest uppercase block font-mono">
                    {isAr ? 'بروتوكول حماية البنوك المشفر' : 'BANK-GRADE SECURITY ENGINES'}
                  </span>
                  <h4 className="font-serif text-xl md:text-2xl font-bold text-white leading-snug">
                    {isAr ? 'بوابة الولوج المشتركة للمؤسسات' : 'Enterprise Unified Gateway'}
                  </h4>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    {isAr 
                      ? 'بوابة دخول آمنة مخصصة لشركاء كُونفيرمد للتجميل والسبا. نوفر أعلى مستويات التشفير للبيانات السحابية وسجلات العمليات.'
                      : 'Secure, high-performance portal designed exclusively for Confirmed B2B partners. End-to-end cloud protection safeguards sensitive merchant files.'}
                  </p>
                </div>

                {/* Subtle & Clean Security Badges (Requested) */}
                <div className="space-y-3.5 pt-2">
                  <div className="flex items-center gap-3 px-3.5 py-2.5 bg-[#0f172a]/80 border border-emerald-500/20 rounded-2xl transition-all hover:border-emerald-500/40">
                    <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-400">
                      <ShieldCheck className="w-4.5 h-4.5" />
                    </div>
                    <div>
                      <span className="block text-xs font-bold text-white font-sans">{isAr ? 'تم تفعيل التحقق الثنائي (MFA)' : 'MFA Enabled'}</span>
                      <span className="block text-[10px] text-emerald-400 font-mono">★ FIDO2 / TOTP SECURED</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 px-3.5 py-2.5 bg-[#0f172a]/80 border border-sky-500/20 rounded-2xl transition-all hover:border-sky-500/40">
                    <div className="w-8 h-8 rounded-lg bg-sky-500/10 flex items-center justify-center text-sky-400">
                      <Lock className="w-4.5 h-4.5" />
                    </div>
                    <div>
                      <span className="block text-xs font-bold text-white font-sans">{isAr ? 'اتصال مشفر وآمن بالكامل' : 'Secure Encrypted Connection'}</span>
                      <span className="block text-[10px] text-sky-400 font-mono">✦ AES-256 SSL VAULT</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Cryptographic Keycards (Autofill helpers) */}
              <div className="mt-8 pt-6 border-t border-slate-800/60 space-y-3 relative z-10">
                <span className="block text-[10px] font-bold tracking-wider text-slate-400 uppercase flex items-center gap-1 font-mono">
                  <Key className="w-3.5 h-3.5 text-[#FF5A5F]" />
                  {isAr ? 'عقود الوصول التجريبية السريعة' : 'Authorized Access Tokens'}
                </span>
                <div className="grid grid-cols-1 gap-2 pt-1 max-h-[180px] overflow-y-auto pr-1">
                  {/* Dynamic Approved Provider Tokens */}
                  {providerRequests?.filter((r: any) => r.status === 'approved').slice(0, 3).map((prov: any) => (
                    <button
                      key={prov.id}
                      type="button"
                      onClick={() => handleAutoFillDemo(prov.email || prov.phone || prov.storeName)}
                      className="w-full text-start p-2.5 rounded-xl bg-emerald-950/20 hover:bg-emerald-950/40 border border-emerald-900/40 hover:border-[#FF5A5F]/30 transition-all text-slate-300 cursor-pointer flex justify-between items-center group"
                    >
                      <div className="space-y-0.5 truncate pr-2">
                        <span className="block text-[11px] font-bold text-emerald-400 group-hover:text-[#FF5A5F] transition-colors truncate">
                          {prov.storeName} ({prov.name})
                        </span>
                        <span className="block text-[9px] text-slate-500 font-mono truncate">ROLE: {prov.activity || 'SALON PROVIDER'}</span>
                      </div>
                      <span className="text-[8px] tracking-wider bg-emerald-900/60 text-emerald-300 px-1.5 py-0.5 rounded font-bold uppercase group-hover:bg-[#FF5A5F] group-hover:text-white transition-all shrink-0">APPROVED</span>
                    </button>
                  ))}

                  <button
                    type="button"
                    onClick={() => handleAutoFillDemo('amal.hair')}
                    className="w-full text-start p-2.5 rounded-xl bg-slate-900/40 hover:bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-all text-slate-300 cursor-pointer flex justify-between items-center group"
                  >
                    <div className="space-y-0.5">
                      <span className="block text-[11px] font-bold text-white group-hover:text-[#FF5A5F] transition-colors">amal.hair (أمل للتجميل)</span>
                      <span className="block text-[9px] text-slate-500 font-mono">ROLE: PROVIDER STAFF</span>
                    </div>
                    <span className="text-[8px] tracking-wider bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded font-bold uppercase group-hover:bg-[#FF5A5F] group-hover:text-white transition-all">Token</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleAutoFillDemo('admin')}
                    className="w-full text-start p-2.5 rounded-xl bg-slate-900/40 hover:bg-slate-900/80 border border-slate-800 hover:border-[#FF5A5F]/30 transition-all text-slate-300 cursor-pointer flex justify-between items-center group"
                  >
                    <div className="space-y-0.5">
                      <span className="block text-[11px] font-bold text-white group-hover:text-[#FF5A5F] transition-colors">admin (مديرة المنصة)</span>
                      <span className="block text-[9px] text-slate-500 font-mono">ROLE: PLATFORM MASTER</span>
                    </div>
                    <span className="text-[8px] tracking-wider bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded font-bold uppercase group-hover:bg-[#FF5A5F] group-hover:text-white transition-all">Root</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Right Column: Center-aligned Elegant Login Card Form */}
            <div className="lg:col-span-7 p-6 md:p-10 flex flex-col justify-between overflow-y-auto bg-[#0a101d] relative min-h-[450px]">
              {/* Close Icon */}
              <button 
                onClick={() => {
                  setShowLoginModal(false);
                  setShowMfaSandbox(false);
                }}
                className="absolute top-5 right-5 p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white transition-all cursor-pointer shadow-md"
                title={isAr ? 'إغلاق' : 'Close'}
              >
                <X className="w-4 h-4" />
              </button>

              {/* Title & Step Navigation */}
              <div className="mb-6">
                <span className="text-[9px] font-bold text-[#FF5A5F] uppercase tracking-[0.2em] font-mono block">
                  {isAr ? 'نظام التحقق الثنائي الآمن' : 'MFA SECURED GATEWAY'}
                </span>
                <h3 className="font-serif text-2xl md:text-3xl font-bold text-white mt-1.5">
                  {loginStep === 1 
                    ? (isAr ? 'بوابة تسجيل الدخول للمؤسسات' : 'B2B Client Identity Secure Portal')
                    : (isAr ? 'التحقق الثنائي المشفر (2FA)' : 'Cryptographic 2-Factor Authentication')}
                </h3>
                <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
                  {loginStep === 1 
                    ? (isAr ? 'الرجاء إدخال اسم المستخدم ورمز المرور المشفر لتشغيل بروتوكول الاتصال.' : 'Please enter your authorized username or email credentials to proceed.')
                    : (isAr ? 'أدخل الرمز المكون من 6 أرقام المستلم على أجهزتك المعتمدة.' : 'Type the 6-digit dynamic authentication token dispatched to your safe device.')}
                </p>
              </div>

              {/* Security Advisory & Warning Messaging */}
              {errorMessage && (
                <div className="mb-6 p-4 bg-red-950/40 border border-red-500/30 rounded-2xl flex items-start gap-3 text-xs text-red-200 shadow-sm animate-shake">
                  <ShieldAlert className="w-5 h-5 text-[#FF5A5F] shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <p className="font-bold text-white">{isAr ? 'تنبيه نظام الحماية' : 'Security Access Violation'}</p>
                    <p className="leading-relaxed opacity-90">{errorMessage}</p>
                    {isLockedOut && (
                      <p className="font-mono text-xs font-bold text-[#FF5A5F] mt-1.5 flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-[#FF5A5F] animate-ping" />
                        <span>{isAr ? `سيتم فك القفل التلقائي بعد: ${lockoutTimer} ثانية` : `Automatic vault cooldown: ${lockoutTimer}s`}</span>
                      </p>
                    )}
                  </div>
                </div>
              )}

              {/* STEP 1: CREDENTIALS SUBMISSION */}
              {loginStep === 1 && (
                <form onSubmit={handleCredentialsSubmit} className="space-y-5 my-auto">
                  
                  {/* Visual Attempt Tracker Bar */}
                  <div className="flex justify-between items-center px-4 py-2.5 bg-slate-900/60 border border-slate-800/80 rounded-xl text-xs text-slate-400">
                    <span className="flex items-center gap-1.5 font-medium font-sans">
                      <Lock className="w-3.5 h-3.5 text-[#FF5A5F]" />
                      {isAr ? 'المحاولات المتبقية لقفل الحساب:' : 'Brute-force lockout security counter:'}
                    </span>
                    <span className={`font-mono font-bold px-2.5 py-0.5 rounded-lg text-xs ${
                      attemptsLeft >= 3 
                        ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20' 
                        : attemptsLeft === 2 
                        ? 'bg-amber-500/15 text-amber-400 border border-amber-500/20 animate-pulse' 
                        : 'bg-red-500/20 text-red-400 border border-red-500/35 animate-bounce'
                    }`}>
                      {attemptsLeft} / 4
                    </span>
                  </div>

                  {/* Username/Email Input */}
                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-slate-300 font-sans">
                      {isAr ? 'اسم المستخدم أو البريد الإلكتروني للمؤسسة' : 'Username / Corporate Email'}
                    </label>
                    <div className="relative">
                      <User className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-500" />
                      <input 
                        type="text" 
                        required
                        disabled={isLockedOut}
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        placeholder={isAr ? "amal.hair أو بريد الموظفة" : "e.g., amal.hair or admin"}
                        className="w-full text-sm pl-11 pr-4 py-3 bg-[#0a101d] text-white border border-slate-800 hover:border-slate-700 rounded-xl focus:outline-none focus:border-[#FF5A5F] focus:ring-1 focus:ring-[#FF5A5F] disabled:bg-slate-950 disabled:text-slate-600 transition-all placeholder-slate-600 font-sans"
                      />
                    </div>
                  </div>

                  {/* Password Input */}
                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-slate-300 font-sans">
                      {isAr ? 'كلمة المرور المشفرة' : 'Password'}
                    </label>
                    <div className="relative">
                      <Lock className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-500" />
                      <input 
                        type={showPassword ? "text" : "password"} 
                        required
                        disabled={isLockedOut}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••••••••"
                        className="w-full text-sm pl-11 pr-11 py-3 bg-[#0a101d] text-white border border-slate-800 hover:border-slate-700 rounded-xl focus:outline-none focus:border-[#FF5A5F] focus:ring-1 focus:ring-[#FF5A5F] disabled:bg-slate-950 transition-all placeholder-slate-600 font-mono"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3.5 top-3 p-1 text-slate-500 hover:text-slate-300 cursor-pointer transition-colors"
                        title={showPassword ? 'إخفاء' : 'عرض'}
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Prominent Secure Action Button (Requested) */}
                  <div className="pt-4">
                    <button
                      type="submit"
                      disabled={isLockedOut}
                      className="w-full py-4 bg-[#FF5A5F] hover:bg-[#E04B50] active:scale-[0.99] text-white text-sm font-bold rounded-xl shadow-lg shadow-[#FF5A5F]/20 hover:shadow-[#FF5A5F]/35 transition-all duration-200 cursor-pointer disabled:bg-slate-800 disabled:text-slate-600 disabled:shadow-none flex items-center justify-center gap-2"
                    >
                      <ShieldCheck className="w-4.5 h-4.5 text-white animate-pulse" />
                      <span>{isAr ? 'تأمين الاتصال والمتابعة للتحقق الثنائي ←' : 'Secure Connection & Proceed to 2FA'}</span>
                    </button>
                  </div>

                  {/* Safe Sandbox Notification Quick Hint */}
                  <div className="mt-4 p-3 bg-slate-900/40 border border-slate-800 rounded-2xl text-[10px] text-slate-400 leading-relaxed font-mono">
                    <span className="text-[#FF5A5F] font-bold block mb-1">🔑 CRITICAL PASSCODE PROTOCOL</span>
                    {isAr 
                      ? 'للمراجعة، الحساب الافتراضي هو (admin) وكلمة المرور هي (password123). كود التحقق الثنائي سيظهر تلقائياً في أسفل الشاشة.' 
                      : 'Test details: use user (admin) and password (password123). The 2FA notification will instantly prompt in the viewport margin.'}
                  </div>
                </form>
              )}

              {/* STEP 2: TWO-FACTOR OTP CHALLENGE FORM */}
              {loginStep === 2 && (
                <form onSubmit={handleOTPSubmit} className="space-y-6 my-auto">
                  <div className="p-4 bg-emerald-950/30 border border-emerald-500/20 rounded-2xl text-xs text-emerald-300 space-y-2">
                    <p className="font-bold flex items-center gap-1.5 text-white">
                      <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>{isAr ? 'تم إرسال كود التحقق الثنائي!' : 'Dual 2-Factor Code Transmitted'}</span>
                    </p>
                    <p className="leading-relaxed opacity-90">
                      {isAr 
                        ? `لقد تم إرسال الرمز التعريفي المؤقت مباشرة إلى الجوال والبريد المسجل كرسالة نصية مشفرة.` 
                        : `We have dispatched a cryptographic security passkey directly to your registered phone & email inbox.`}
                    </p>
                  </div>

                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-slate-300 flex justify-between font-sans">
                      <span>{isAr ? 'أدخل رمز التحقق (OTP) المكون من 6 أرقام' : '6-Digit Verification Token'}</span>
                      <span className="text-[#FF5A5F] font-mono font-bold animate-pulse">{isAr ? 'صالح لمدة دقيقتين' : 'Expires in 2:00'}</span>
                    </label>
                    
                    <div className="relative">
                      <Key className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-500" />
                      <input 
                        type="text" 
                        required
                        maxLength={6}
                        value={enteredOTP}
                        onChange={(e) => {
                          setEnteredOTP(e.target.value.replace(/\D/g, ''));
                          setOtpError('');
                        }}
                        placeholder="••••••"
                        className="w-full text-center tracking-[0.6em] font-mono text-xl font-bold py-3.5 bg-[#0a101d] text-white border border-slate-800 rounded-xl focus:outline-none focus:border-[#FF5A5F] focus:ring-1 focus:ring-[#FF5A5F] pl-10"
                      />
                    </div>
                    {otpError && (
                      <p className="text-xs text-[#FF5A5F] font-bold mt-2 animate-shake">✕ {otpError}</p>
                    )}
                  </div>

                  {/* Resend Action */}
                  <div className="text-center pt-2">
                    <button
                      type="button"
                      onClick={() => {
                        const randomCode = Math.floor(100000 + Math.random() * 900000).toString();
                        setGeneratedOTP(randomCode);
                        setOtpSent(true);
                        setOtpError('');
                        setEnteredOTP('');
                        setShowMfaSandbox(false);

                        const isEmail = username.trim().toLowerCase().includes('@') || username.trim().toLowerCase() === 'admin';
                        const deliveryType = isEmail ? 'email' : 'sms';
                        const target = isEmail 
                          ? (username.trim().toLowerCase() === 'admin' ? 'admin@confirmed.sa' : username.trim()) 
                          : (username.trim().toLowerCase() === 'amal.hair' ? '0550000123' : username.trim().toLowerCase() === 'dalal.spa' ? '0550000456' : username.trim().toLowerCase() === 'shahad.nail' ? '0550000789' : '0550000000');
                        triggerSimulatedNotification(deliveryType, target, randomCode);
                      }}
                      className="text-xs font-bold text-[#FF5A5F] hover:underline cursor-pointer flex items-center gap-1.5 mx-auto bg-transparent border-none transition-all hover:opacity-80"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>{isAr ? 'إعادة توليد وإرسال رمز التحقق (OTP)' : 'Regenerate & Resend 2FA OTP'}</span>
                    </button>
                  </div>

                  {/* Verification action buttons */}
                  <div className="flex flex-col sm:flex-row gap-3 pt-3">
                    <button
                      type="submit"
                      className="flex-1 py-3.5 bg-emerald-600 hover:bg-emerald-500 active:scale-[0.99] text-white font-bold text-sm rounded-xl shadow-lg shadow-emerald-600/10 hover:shadow-emerald-600/20 transition-all cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <ShieldCheck className="w-4 h-4 text-white" />
                      <span>{isAr ? 'توثيق الهوية والدخول الآمن' : 'Authorize Identity & Sign In'}</span>
                    </button>
                    
                    <button
                      type="button"
                      onClick={() => {
                        setLoginStep(1);
                        setEnteredOTP('');
                        setOtpError('');
                      }}
                      className="px-5 py-3.5 bg-[#0e1626] border border-slate-800 hover:border-slate-700 hover:bg-slate-900 text-slate-300 hover:text-white font-bold text-sm rounded-xl transition-all cursor-pointer"
                    >
                      {isAr ? 'رجوع' : 'Back'}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      )}


      {/* ===== SERVICE PROVIDER REGISTRATION MULTI-STEP MODAL ===== */}
      {showRegisterModal && (
        <div className="fixed inset-0 bg-[#1C1B18]/40 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl border border-[#E9E7E2] w-full max-w-lg p-6 md:p-8 shadow-2xl relative animate-scaleIn max-h-[90vh] overflow-y-auto">
            <button 
              onClick={() => {
                setShowRegisterModal(false);
                setRegisterStep(1);
                setRegName('');
                setRegPhone('');
                setRegEmail('');
                setRegStoreName('');
                setRegCustomActivity('');
                setRegFormError('');
                setCardName('');
                setCardNumber('');
                setCardExpiry('');
                setCardCvv('');
              }}
              className="absolute top-4 left-4 p-2 rounded-full hover:bg-[#F6F6F4] text-[#6E6A63] cursor-pointer"
            >
              <Plus className="w-5 h-5 rotate-45" />
            </button>

            {/* Stepper Headers */}
            {registerStep < 4 && (
              <div className="mb-8">
                <div className="flex items-center justify-between">
                  <h3 className="font-serif text-xl sm:text-2xl font-bold text-[#14332B]">
                    {isAr ? 'الانضمام كمزود خدمة جديد' : 'Join as a Service Provider'}
                  </h3>
                </div>
                <p className="text-xs text-[#6E6A63] mt-1">
                  {isAr 
                    ? 'سجلي صالونك أو مركزك التجميلي الآن واحصلي على تفعيل فوري بعد إتمام الدفع والتحقق.' 
                    : 'Register your salon or beauty center and gain instant activation after payment verification.'}
                </p>

                {/* Steps visual indicators */}
                <div className="flex items-center justify-between mt-6 relative">
                  <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-slate-150 -translate-y-1/2 z-0" />
                  
                  {/* Step 1 Indicator */}
                  <div className="relative z-10 flex flex-col items-center">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                      registerStep >= 1 ? 'bg-[#FF5A5F] text-white' : 'bg-slate-100 text-slate-450 border border-[#E9E7E2]'
                    }`}>
                      1
                    </div>
                    <span className="text-[10px] sm:text-xs font-bold mt-1.5 text-slate-850">
                      {isAr ? 'المعلومات الأساسية' : 'Basic Info'}
                    </span>
                  </div>

                  {/* Step 2 Indicator */}
                  <div className="relative z-10 flex flex-col items-center">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                      registerStep >= 2 ? 'bg-[#FF5A5F] text-white' : 'bg-slate-100 text-slate-450 border border-[#E9E7E2]'
                    }`}>
                      2
                    </div>
                    <span className="text-[10px] sm:text-xs font-bold mt-1.5 text-slate-850">
                      {isAr ? 'بيانات المنشأة' : 'Company Details'}
                    </span>
                  </div>

                  {/* Step 3 Indicator */}
                  <div className="relative z-10 flex flex-col items-center">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                      registerStep >= 3 ? 'bg-[#FF5A5F] text-white' : 'bg-slate-100 text-slate-450 border border-[#E9E7E2]'
                    }`}>
                      3
                    </div>
                    <span className="text-[10px] sm:text-xs font-bold mt-1.5 text-slate-850">
                      {isAr ? 'الدفع والاشتراك' : 'Payment Checkout'}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Step Form Body */}
            <form onSubmit={(e) => e.preventDefault()} className="space-y-5">
              {regFormError && (
                <div className="p-3 bg-red-50 text-red-600 border border-red-150 rounded-xl text-xs font-bold flex items-center gap-1.5 animate-shake">
                  <ShieldAlert className="w-4 h-4 shrink-0" />
                  <span>{regFormError}</span>
                </div>
              )}

              {/* STEP 1: Personal Info */}
              {registerStep === 1 && (
                <div className="space-y-4 animate-fadeIn">
                  <div>
                    <label className="block text-xs font-bold text-[#1C1B18] mb-1.5">
                      {isAr ? 'اسم موظفة التواصل/المزود *' : 'Contact Person / Provider Full Name *'}
                    </label>
                    <div className="relative">
                      <User className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                      <input 
                        type="text"
                        required
                        value={regName}
                        onChange={(e) => setRegName(e.target.value)}
                        placeholder={isAr ? 'مثال: نورة محمد السديري' : 'e.g. Noura Al-Sudairy'}
                        className="w-full text-sm pl-10 pr-4 py-2.5 border border-[#E9E7E2] rounded-xl focus:outline-none focus:border-[#FF5A5F]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-[#1C1B18] mb-1.5">
                        {isAr ? 'رقم الجوال لتفعيل الحساب *' : 'Active Mobile Number *'}
                      </label>
                      <div className="relative">
                        <Phone className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                        <input 
                          type="tel"
                          required
                          value={regPhone}
                          onChange={(e) => setRegPhone(e.target.value)}
                          placeholder="055XXXXXXX"
                          className="w-full text-sm pl-10 pr-4 py-2.5 border border-[#E9E7E2] rounded-xl focus:outline-none focus:border-[#FF5A5F]"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#1C1B18] mb-1.5">
                        {isAr ? 'البريد الإلكتروني لاستلام الرابط *' : 'Email Address for Dashboard Link *'}
                      </label>
                      <div className="relative">
                        <Mail className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                        <input 
                          type="email"
                          required
                          value={regEmail}
                          onChange={(e) => setRegEmail(e.target.value)}
                          placeholder="name@provider.com"
                          className="w-full text-sm pl-10 pr-4 py-2.5 border border-[#E9E7E2] rounded-xl focus:outline-none focus:border-[#FF5A5F]"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex pt-4">
                    <button
                      type="button"
                      onClick={() => {
                        if (!regName || !regPhone || !regEmail) {
                          setRegFormError(isAr ? 'الرجاء ملء جميع البيانات للمتابعة' : 'Please fill in all details to proceed');
                        } else {
                          setRegisterStep(2);
                          setRegFormError('');
                        }
                      }}
                      className="w-full py-3 bg-[#FF5A5F] hover:bg-[#E04B50] text-white font-bold text-sm rounded-xl shadow-lg shadow-[#FF5A5F]/15 transition-all cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <span>{isAr ? 'الخطوة التالية (بيانات المنشأة) ←' : 'Next (Company Details) ←'}</span>
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 2: Store / Company Details & Niche */}
              {registerStep === 2 && (
                <div className="space-y-4 animate-fadeIn">
                  <div>
                    <label className="block text-xs font-bold text-[#1C1B18] mb-1.5">
                      {isAr ? 'اسم المتجر أو صالون التجميل *' : 'Salon, Spa or Company Name *'}
                    </label>
                    <div className="relative">
                      <Building className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                      <input 
                        type="text"
                        required
                        value={regStoreName}
                        onChange={(e) => setRegStoreName(e.target.value)}
                        placeholder={isAr ? 'مثال: صالون نورة للتجميل والعناية' : 'e.g. Noura Salon & Spa'}
                        className="w-full text-sm pl-10 pr-4 py-2.5 border border-[#E9E7E2] rounded-xl focus:outline-none focus:border-[#FF5A5F]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#1C1B18] mb-1.5">
                      {isAr ? 'ما هو النشاط الأساسي للمنشأة؟ *' : 'What is the primary facility activity? *'}
                    </label>
                    <div className="relative">
                      <Briefcase className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                      <select
                        value={regActivity}
                        onChange={(e) => setRegActivity(e.target.value)}
                        className="w-full text-sm pl-10 pr-4 py-2.5 border border-[#E9E7E2] rounded-xl focus:outline-none focus:border-[#FF5A5F] bg-white text-slate-800"
                      >
                        <option value="صالون شعر وتجميل">{isAr ? 'صالون شعر وتجميل متكامل' : 'Full Beauty & Hair Salon'}</option>
                        <option value="مركز سبا ومساج">{isAr ? 'مركز سبا ومساج صحي' : 'Healthy Spa & Massage Center'}</option>
                        <option value="مركز عناية بالأظافر">{isAr ? 'عيادة ومركز متخصص للعناية بالأظافر' : 'Specialized Nails Lounge'}</option>
                        <option value="ميك اب ارتست مستقلة">{isAr ? 'خبيرات مكياج وتجميل مستقلات' : 'Independent Makeup Stylist'}</option>
                        <option value="أخرى">{isAr ? 'نشاط آخر (يرجى كتابته)' : 'Other (Please specify)'}</option>
                      </select>
                    </div>
                  </div>

                  {regActivity === 'أخرى' && (
                    <div className="animate-fadeIn">
                      <label className="block text-xs font-bold text-[#1C1B18] mb-1.5">
                        {isAr ? 'اكتبي تفاصيل النشاط بالتفصيل *' : 'Specify your activity niche *'}
                      </label>
                      <input 
                        type="text"
                        required
                        value={regCustomActivity}
                        onChange={(e) => setRegCustomActivity(e.target.value)}
                        placeholder={isAr ? 'مثال: مصففة عرايس وعلاجات كيراتين' : 'e.g. Bridal Hairstyling & Keratin'}
                        className="w-full text-sm px-4 py-2.5 border border-[#E9E7E2] rounded-xl focus:outline-none focus:border-[#FF5A5F]"
                      />
                    </div>
                  )}

                  <div className="flex gap-3 pt-4">
                    <button
                      type="button"
                      onClick={() => setRegisterStep(1)}
                      className="px-6 py-3 border border-[#E9E7E2] text-[#6E6A63] hover:bg-[#F6F6F4] font-bold text-sm rounded-xl transition-all cursor-pointer"
                    >
                      {isAr ? 'رجوع' : 'Back'}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (!regStoreName) {
                          setRegFormError(isAr ? 'الرجاء إدخال اسم المتجر أو صالون التجميل' : 'Please input the salon or store name');
                        } else if (regActivity === 'أخرى' && !regCustomActivity) {
                          setRegFormError(isAr ? 'الرجاء كتابة تفاصيل النشاط بالتفصيل' : 'Please specify other activity details');
                        } else {
                          setRegisterStep(3);
                          setRegFormError('');
                        }
                      }}
                      className="flex-1 py-3 bg-[#FF5A5F] hover:bg-[#E04B50] text-white font-bold text-sm rounded-xl shadow-lg shadow-[#FF5A5F]/15 transition-all cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <span>{isAr ? 'الذهاب للدفع والاشتراك ←' : 'Go to Secure Checkout ←'}</span>
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 3: Secure Payment & Package Details */}
              {registerStep === 3 && (
                <div className="space-y-4 animate-fadeIn">
                  {/* Selected Package Details Panel */}
                  <div className="bg-[#F8FAFC] border border-slate-200 rounded-2xl p-4 flex justify-between items-center">
                    <div className="space-y-0.5 text-right rtl:text-right">
                      <span className="text-[10px] font-bold text-[#FF5A5F] uppercase tracking-wide block font-sans">
                        {isAr ? 'الباقة المحددة' : 'Selected Tier'}
                      </span>
                      <h4 className="font-serif text-base font-bold text-[#14332B]">
                        {selectedPackage === 'basic' ? (isAr ? 'الباقة الأساسية' : 'Basic Starter Plan') : (isAr ? 'الباقة الاحترافية المتكاملة' : 'Professional Growth Plan')}
                      </h4>
                      <p className="text-[11px] text-[#6E6A63]">
                        {billing === 'yearly' ? (isAr ? 'نظام المحاسبة السنوي (توفير ٢٠٪)' : 'Billed Annually (Save 20%)') : (isAr ? 'نظام المحاسبة الشهري المرن' : 'Billed Monthly')}
                      </p>
                    </div>

                    <div className="text-left rtl:text-left">
                      <span className="font-serif text-xl sm:text-2xl font-bold text-[#FF5A5F] block">
                        {selectedPackage === 'basic' ? (billing === 'yearly' ? '1,908' : '199') : (billing === 'yearly' ? '3,828' : '399')}
                      </span>
                      <span className="text-[10px] text-[#6E6A63] font-bold block text-left">
                        {isAr ? 'ر.س' : 'SAR'} / {billing === 'yearly' ? (isAr ? 'سنة' : 'year') : (isAr ? 'شهر' : 'month')}
                      </span>
                    </div>
                  </div>

                  {/* Payment Methods Tab */}
                  <div className="space-y-3">
                    <label className="block text-xs font-bold text-[#1C1B18]">
                      {isAr ? 'اختر وسيلة الدفع الآمنة *' : 'Secure Payment Method *'}
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      <button
                        type="button"
                        onClick={() => setPaymentMethod('mada')}
                        className={`py-2 px-3 border text-xs font-bold rounded-xl transition-all cursor-pointer flex flex-col items-center justify-center gap-1 ${
                          paymentMethod === 'mada' 
                            ? 'border-[#FF5A5F] bg-[#FF5A5F]/5 text-[#FF5A5F]' 
                            : 'border-[#E9E7E2] hover:bg-[#F6F6F4] text-slate-600'
                        }`}
                      >
                        <span className="text-xs uppercase font-extrabold text-blue-600">MADA</span>
                        <span className="text-[9px] font-normal">{isAr ? 'مدى السعودية' : 'Saudi Mada'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setPaymentMethod('credit')}
                        className={`py-2 px-3 border text-xs font-bold rounded-xl transition-all cursor-pointer flex flex-col items-center justify-center gap-1 ${
                          paymentMethod === 'credit' 
                            ? 'border-[#FF5A5F] bg-[#FF5A5F]/5 text-[#FF5A5F]' 
                            : 'border-[#E9E7E2] hover:bg-[#F6F6F4] text-slate-600'
                        }`}
                      >
                        <CreditCard className="w-4 h-4 text-slate-500" />
                        <span className="text-[9px] font-normal">{isAr ? 'بطاقة ائتمان' : 'Visa / Master'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setPaymentMethod('applepay')}
                        className={`py-2 px-3 border text-xs font-bold rounded-xl transition-all cursor-pointer flex flex-col items-center justify-center gap-1 ${
                          paymentMethod === 'applepay' 
                            ? 'border-black bg-black text-white' 
                            : 'border-[#E9E7E2] hover:bg-[#F6F6F4] text-slate-600'
                        }`}
                      >
                        <span className="font-serif font-black tracking-tighter text-sm"> Pay</span>
                        <span className="text-[9px] font-normal">{isAr ? 'دفع سريع' : 'Instant Apple'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Card Form */}
                  {paymentMethod !== 'applepay' ? (
                    <div className="p-4 bg-white border border-[#E9E7E2] rounded-2xl space-y-3 animate-fadeIn">
                      <div>
                        <label className="block text-[10px] font-bold text-[#1C1B18] uppercase mb-1">{isAr ? 'اسم حامل البطاقة *' : 'Cardholder Name *'}</label>
                        <input
                          type="text"
                          required
                          value={cardName}
                          onChange={(e) => setCardName(e.target.value)}
                          placeholder={isAr ? 'مثال: نورة محمد السديري' : 'e.g. Noura Al-Sudairy'}
                          className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-[#FF5A5F]"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-[#1C1B18] uppercase mb-1">{isAr ? 'رقم البطاقة الائتمانية / مدى *' : 'Card Number *'}</label>
                        <div className="relative">
                          <CreditCard className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400" />
                          <input
                            type="text"
                            required
                            maxLength={19}
                            value={cardNumber}
                            onChange={(e) => {
                              // basic card formatting
                              const val = e.target.value.replace(/\D/g, '').replace(/(.{4})/g, '$1 ').trim();
                              setCardNumber(val);
                            }}
                            placeholder="4000 1234 5678 9010"
                            className="w-full text-xs pl-9 pr-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-[#FF5A5F]"
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[10px] font-bold text-[#1C1B18] uppercase mb-1">{isAr ? 'تاريخ الانتهاء *' : 'Expiry Date *'}</label>
                          <input
                            type="text"
                            required
                            maxLength={5}
                            value={cardExpiry}
                            onChange={(e) => {
                              const val = e.target.value.replace(/\D/g, '');
                              if (val.length >= 2) {
                                setCardExpiry(val.slice(0, 2) + '/' + val.slice(2, 4));
                              } else {
                                setCardExpiry(val);
                              }
                            }}
                            placeholder="MM/YY"
                            className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-[#FF5A5F] text-center"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold text-[#1C1B18] uppercase mb-1">{isAr ? 'الرمز السري (CVV) *' : 'Security Code (CVV) *'}</label>
                          <input
                            type="password"
                            required
                            maxLength={3}
                            value={cardCvv}
                            onChange={(e) => setCardCvv(e.target.value.replace(/\D/g, ''))}
                            placeholder="•••"
                            className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-[#FF5A5F] text-center"
                          />
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="p-6 bg-slate-50 border border-dashed border-slate-300 rounded-2xl flex flex-col items-center justify-center space-y-2 animate-fadeIn">
                      <div className="w-10 h-10 rounded-full bg-black flex items-center justify-center text-white text-lg"></div>
                      <p className="text-xs font-bold text-slate-800">{isAr ? 'Apple Pay معرّف وجاهز للاستخدام الآمن' : 'Apple Pay configured and ready'}</p>
                      <p className="text-[10px] text-slate-400">{isAr ? 'اضغطي على الزر بالأسفل لتأكيد الهوية البيومترية وإتمام الدفع' : 'Authenticate with FaceID/TouchID upon submission'}</p>
                    </div>
                  )}

                  {/* Secure Padlock compliance badge */}
                  <div className="p-3 bg-emerald-50 text-emerald-800 border border-emerald-100 rounded-xl text-[10px] leading-relaxed flex gap-2">
                    <Lock className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <p>
                      {isAr 
                        ? 'تشفير فوري آمن وقنوات متوافقة كلياً مع المعايير الأمنية لمدى السعودية وهيئة المدفوعات السعودية (PCI-DSS).' 
                        : 'Fully certified end-to-end payment vault. Your billing session is secured using SSL with TLS 1.3 cryptographic parameters.'}
                    </p>
                  </div>

                  <div className="flex gap-3 pt-2">
                    <button
                      type="button"
                      onClick={() => setRegisterStep(2)}
                      className="px-6 py-3 border border-[#E9E7E2] text-[#6E6A63] hover:bg-[#F6F6F4] font-bold text-sm rounded-xl transition-all cursor-pointer"
                    >
                      {isAr ? 'رجوع' : 'Back'}
                    </button>
                    <button
                      type="button"
                      disabled={isProcessingPayment}
                      onClick={() => {
                        // Validate Card details first
                        if (paymentMethod !== 'applepay') {
                          if (!cardName || !cardNumber || !cardExpiry || !cardCvv) {
                            setRegFormError(isAr ? 'الرجاء إدخال جميع معلومات بطاقتك البنكية لإتمام الدفع الآمن' : 'Please input all card credentials to proceed securely');
                            return;
                          }
                          if (cardNumber.replace(/\s/g, '').length < 15) {
                            setRegFormError(isAr ? 'رقم البطاقة غير مكتمل. يرجى مراجعته.' : 'Invalid or incomplete credit card number.');
                            return;
                          }
                        }

                        setIsProcessingPayment(true);
                        setRegFormError('');
                        
                        // Simulate PCI-DSS secure card auth and OTP transmission
                        setTimeout(() => {
                          setIsProcessingPayment(false);
                          
                          // Formulate final onboarding request
                          const amount = selectedPackage === 'basic' ? (billing === 'yearly' ? '1908' : '199') : (billing === 'yearly' ? '3828' : '399');
                          const newRequest = {
                            id: 'req-' + Math.random().toString(36).substring(2, 9),
                            name: regName,
                            phone: regPhone,
                            email: regEmail,
                            storeName: regStoreName,
                            activity: regActivity === 'أخرى' && regCustomActivity ? regCustomActivity : regActivity,
                            status: 'pending',
                            requestedAt: new Date().toISOString(),
                            selectedPackage: selectedPackage || 'pro',
                            billingCycle: billing,
                            amountPaid: amount,
                            paymentMethod: paymentMethod,
                            paymentStatus: 'paid_verified'
                          };
                          
                          if (onAddProviderRequest) {
                            onAddProviderRequest(newRequest);
                          }
                          
                          setRegisterStep(4); // Advance to Success Screen
                        }, 1800);
                      }}
                      className="flex-1 py-3 bg-[#14332B] hover:bg-[#1C473C] text-white font-bold text-sm rounded-xl shadow-lg transition-all cursor-pointer flex items-center justify-center gap-2"
                    >
                      {isProcessingPayment ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin text-emerald-400" />
                          <span>{isAr ? 'جاري التحقق والمصادقة الأمنية...' : 'Securing transaction credentials...'}</span>
                        </>
                      ) : (
                        <>
                          <ShieldCheck className="w-4 h-4 text-emerald-400" />
                          <span>
                            {isAr 
                              ? `دفع ومصادقة ${selectedPackage === 'basic' ? (billing === 'yearly' ? '1,908' : '199') : (billing === 'yearly' ? '3,828' : '399')} ر.س` 
                              : `Authorize & Pay ${selectedPackage === 'basic' ? (billing === 'yearly' ? '1,908' : '199') : (billing === 'yearly' ? '3,828' : '399')} SAR`}
                          </span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}
            </form>

            {/* STEP 4: Success confirmation screen */}
            {registerStep === 4 && (
              <div className="text-center py-6 space-y-6 animate-scaleIn">
                <div className="w-20 h-20 bg-emerald-50 border-4 border-emerald-200 text-emerald-500 rounded-full flex items-center justify-center mx-auto shadow-inner">
                  <Check className="w-10 h-10 stroke-[3]" />
                </div>

                <div className="space-y-2">
                  <h4 className="font-serif text-2xl font-bold text-[#14332B]">
                    {isAr ? 'تم سداد الاشتراك وإرسال طلبك! 🎉' : 'Payment Approved & Registered! 🎉'}
                  </h4>
                  <p className="text-sm text-emerald-700 font-bold leading-relaxed max-w-sm mx-auto">
                    {isAr 
                      ? '✓ تمت عملية الدفع ومصادقتها بنجاح عبر بوابة مدى للتحقق الثلاثي الآمن.' 
                      : '✓ Payment captured and authorized via integrated Mada Secure Vault.'}
                  </p>
                  <p className="text-xs text-[#6E6A63] leading-relaxed max-w-sm mx-auto">
                    {isAr 
                      ? 'مرحباً بكِ في مجتمع CONFIRMED. لقد تلقينا طلب صالونك وجاري تفعيله الآن في لوحة الإدارة من قبل إدارة المنصة.'
                      : 'Your pending portal activation is currently queued for immediate administrator sign-off.'}
                  </p>
                </div>

                {/* Simulated Notification Notice */}
                <div className="bg-[#F8FAFC] border border-slate-200 rounded-2xl p-4 text-xs text-slate-600 leading-normal font-mono text-left rtl:text-right max-w-sm mx-auto space-y-1">
                  <span className="font-sans font-bold text-slate-800 block mb-1">📋 {isAr ? 'ملخص الطلب المدفوع والمؤمن:' : 'Pending Secured Request:'}</span>
                  <div>• {isAr ? 'المزود:' : 'Provider:'} <span className="text-[#FF5A5F] font-bold">{regName}</span></div>
                  <div>• {isAr ? 'المنشأة:' : 'Store:'} <span className="text-slate-800 font-bold">{regStoreName}</span></div>
                  <div>• {isAr ? 'الباقة المشتراة:' : 'Package:'} <span className="text-emerald-600 font-bold">{selectedPackage === 'basic' ? (isAr ? 'الباقة الأساسية' : 'Basic') : (isAr ? 'الباقة الاحترافية' : 'Professional')}</span></div>
                  <div>• {isAr ? 'المبلغ المستلم:' : 'Amount Paid:'} <span className="text-slate-800 font-bold">{selectedPackage === 'basic' ? (billing === 'yearly' ? '1,908' : '199') : (billing === 'yearly' ? '3,828' : '399')} ر.س</span></div>
                  <div>• {isAr ? 'حالة التفعيل:' : 'Status:'} <span className="text-amber-600 font-bold">{isAr ? 'بانتظار موافقة الإدارة' : 'Pending Admin Activation'}</span></div>
                  <p className="text-[10px] text-slate-400 pt-2 font-sans leading-normal">
                    * {isAr ? 'تنبيه: قومي بتسجيل الدخول كمدير (admin) في الصفحة الرئيسية لعرض طلبك فورياً وتفعيله لإرسال رابط الدخول الآمن لإيميلك.' : 'Hint: Log in as "admin" on the homepage to instant-activate this ticket and trigger the secure SMTP onboarding email simulation!'}
                  </p>
                </div>

                <div className="pt-4">
                  <button
                    onClick={() => {
                      setShowRegisterModal(false);
                      setRegisterStep(1);
                      setRegName('');
                      setRegPhone('');
                      setRegEmail('');
                      setRegStoreName('');
                      setRegCustomActivity('');
                      setRegFormError('');
                      setCardName('');
                      setCardNumber('');
                      setCardExpiry('');
                      setCardCvv('');
                    }}
                    className="w-full py-3.5 bg-[#14332B] hover:bg-[#1C473C] text-white font-bold text-sm rounded-xl transition-all cursor-pointer"
                  >
                    {isAr ? 'العودة للرئيسية' : 'Back to Landing Page'}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Dynamic Simulated Device Push Notification Banner */}
      {activeNotification && (
        <div 
          className={`fixed top-6 left-1/2 -translate-x-1/2 md:left-auto md:right-6 md:translate-x-0 z-[9999] max-w-sm w-full mx-auto p-1.5 transition-all duration-500 ease-out ${
            activeNotification.visible 
              ? 'translate-y-0 opacity-100 scale-100' 
              : '-translate-y-12 opacity-0 scale-95 pointer-events-none'
          }`}
        >
          <div className="bg-[#1C1B18]/95 backdrop-blur-md text-white border border-[#4a4843] p-4 rounded-2xl shadow-2xl flex gap-3 relative overflow-hidden">
            {/* Ambient pulse background light */}
            <div className={`absolute top-0 right-0 w-24 h-24 rounded-full blur-2xl ${
              activeNotification.type === 'email' ? 'bg-emerald-500/10' : 'bg-[#FF5A5F]/15'
            }`} />

            <div className="shrink-0 flex items-center justify-center">
              {activeNotification.type === 'email' ? (
                <div className="w-10 h-10 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
                  <Mail className="w-5 h-5 text-emerald-400" />
                </div>
              ) : (
                <div className="w-10 h-10 rounded-full bg-[#FF5A5F]/10 border border-[#FF5A5F]/20 flex items-center justify-center">
                  <Smartphone className="w-5 h-5 text-[#FF5A5F]" />
                </div>
              )}
            </div>

            <div className="flex-1 space-y-1 relative z-10">
              <div className="flex justify-between items-center text-[10px] text-slate-400 font-bold tracking-wider uppercase">
                <span>
                  {activeNotification.type === 'email' 
                    ? (isAr ? '📧 بريد إلكتروني جديد آمن' : '📧 Secure New Email')
                    : (isAr ? '💬 رسالة نصية قصيرة (SMS)' : '💬 SMS Verification Message')}
                </span>
                <span className="text-slate-500 font-mono text-[9px]">{isAr ? 'الآن' : 'NOW'}</span>
              </div>
              
              <p className="text-xs font-bold text-slate-200">
                {activeNotification.type === 'email' ? 'security@confirmed.sa' : 'CONFIRMED_MFA'}
              </p>

              <p className="text-xs text-slate-300 leading-relaxed pt-0.5">
                {activeNotification.type === 'email' ? (
                  isAr 
                    ? `عزيزي مزود الخدمة، كود التحقق الثنائي (OTP) لتسجيل الدخول إلى CONFIRMED هو: `
                    : `Dear provider, your secure 2FA authentication code is: `
                ) : (
                  isAr
                    ? `رمز التحقق الثنائي الآمن لتسجيل الدخول الخاص بك هو: `
                    : `Your CONFIRMED secure OTP verification code is: `
                )}
                <span className="font-mono font-black text-white bg-white/10 px-2 py-0.5 rounded border border-white/15 mx-1 text-sm inline-block select-all tracking-wider animate-pulse">
                  {activeNotification.code}
                </span>
              </p>

              <div className="text-[9px] text-[#FF5A5F] pt-1 font-medium flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-[#FF5A5F] animate-pulse" />
                <span>
                  {isAr 
                    ? `وصلت لجوال الموظف المسجل: ${activeNotification.recipient}` 
                    : `Dispatched directly to registered endpoint: ${activeNotification.recipient}`}
                </span>
              </div>
            </div>

            {/* Click to close */}
            <button 
              type="button"
              onClick={() => setActiveNotification(prev => prev ? { ...prev, visible: false } : null)}
              className="absolute top-3 right-3 p-1 text-slate-400 hover:text-white rounded-full transition-colors cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
