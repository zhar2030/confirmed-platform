#!/bin/bash
set -e

DIR="$(cd "$(dirname "$0")" && pwd)/files"

echo "======================================"
echo "  CONFIRMED — Full Deployment Script"
echo "======================================"

# 1. Backend
echo "[1/5] Updating backend..."
cp "$DIR/api-server/dist/index.mjs" /root/api-server/dist/index.mjs
echo "      ✓ index.mjs copied"

# 2. Frontend
echo "[2/5] Updating frontend..."
mkdir -p /root/confirmed-server/public/assets
cp "$DIR/confirmed-server/public/index.html"   /root/confirmed-server/public/
cp "$DIR/confirmed-server/public/favicon.svg"  /root/confirmed-server/public/
cp "$DIR/confirmed-server/public/robots.txt"   /root/confirmed-server/public/
cp "$DIR/confirmed-server/public/assets/"*     /root/confirmed-server/public/assets/
echo "      ✓ Frontend files copied"

# 3. Apache config
echo "[3/5] Updating Apache config..."
cp "$DIR/apache2/000-default-le-ssl.conf" /etc/apache2/sites-enabled/000-default-le-ssl.conf
echo "      ✓ Apache SSL config updated"

# 4. Enable mod_rewrite
echo "[4/5] Enabling mod_rewrite..."
a2enmod rewrite 2>/dev/null || true
echo "      ✓ mod_rewrite enabled"

# 5. Restart services
echo "[5/5] Restarting services..."
apache2ctl configtest
systemctl reload apache2
echo "      ✓ Apache reloaded"
pm2 restart confirmed
echo "      ✓ Node.js server restarted"

echo ""
echo "======================================"
echo "  ✅ Deployment complete!"
echo "  Site: https://confirmedgrowth.com"
echo "  Booking: https://confirmedgrowth.com/book/{salon-slug}"
echo "======================================"
