#!/bin/bash
# ============================================================
# CONFIRMED Platform — Deploy Script
# Run this from the directory containing the zip:
#   bash deploy.sh
# ============================================================
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WEB_ROOT="/var/www/html"
API_DEST="/root/api-server/dist"
APACHE_CONF="/etc/apache2/sites-enabled/000-default-le-ssl.conf"

echo "🚀 Starting CONFIRMED deployment..."

# 1. Enable required Apache modules
echo "→ Enabling Apache modules..."
a2enmod rewrite proxy proxy_http ssl 2>/dev/null || true

# 2. Deploy frontend
echo "→ Deploying frontend to $WEB_ROOT..."
mkdir -p "$WEB_ROOT/assets"
cp "$SCRIPT_DIR/frontend/index.html"   "$WEB_ROOT/"
cp "$SCRIPT_DIR/frontend/favicon.svg"  "$WEB_ROOT/" 2>/dev/null || true
cp "$SCRIPT_DIR/frontend/robots.txt"   "$WEB_ROOT/" 2>/dev/null || true
cp "$SCRIPT_DIR/frontend/assets/"*     "$WEB_ROOT/assets/"

# 3. Deploy .htaccess (critical — prevents API calls from being rewritten)
echo "→ Writing .htaccess..."
cp "$SCRIPT_DIR/config/.htaccess" "$WEB_ROOT/.htaccess"

# 4. Deploy Apache config
echo "→ Updating Apache config..."
cp "$SCRIPT_DIR/config/apache-ssl.conf" "$APACHE_CONF"

# 5. Deploy backend
echo "→ Deploying backend..."
mkdir -p "$API_DEST"
cp "$SCRIPT_DIR/backend/index.mjs" "$API_DEST/index.mjs"

# 6. Restart services
echo "→ Restarting services..."
apache2ctl configtest
systemctl reload apache2
pm2 restart confirmed || pm2 start "$API_DEST/index.mjs" --name confirmed

echo ""
echo "✅ Deployment complete!"
echo "   Site:    https://confirmedgrowth.com"
echo "   Booking: https://confirmedgrowth.com/book/YOUR_SALON_SLUG"
echo ""
echo "⚠️  If this is a FRESH server with no .env file, create it:"
echo "   echo 'DATABASE_URL=your_postgres_url' > /root/confirmed-server/.env"
echo "   Then restart: pm2 restart confirmed"
