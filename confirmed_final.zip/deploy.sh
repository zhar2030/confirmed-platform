#!/bin/bash
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"

echo "======================================"
echo "  CONFIRMED — Full Deployment"
echo "======================================"

# 1. Backend
echo "[1/4] Backend..."
cp "$DIR/backend/index.mjs" /root/api-server/dist/index.mjs

# 2. Frontend → /var/www/html (Apache DocumentRoot)
echo "[2/4] Frontend..."
mkdir -p /var/www/html/assets
cp "$DIR/frontend/index.html"        /var/www/html/
cp "$DIR/frontend/favicon.svg"       /var/www/html/
cp "$DIR/frontend/robots.txt"        /var/www/html/
cp "$DIR/frontend/assets/"*          /var/www/html/assets/

# 3. Apache config
echo "[3/4] Apache config..."
cat > /etc/apache2/sites-enabled/000-default-le-ssl.conf << 'APACHEEOF'
<IfModule mod_ssl.c>
<VirtualHost _default_:443>
    ServerAdmin webmaster@localhost
    ServerName confirmedgrowth.com
    DocumentRoot /var/www/html
    DirectoryIndex index.html
    Options -Indexes
    ErrorLog /var/log/apache2/error.log
    CustomLog /var/log/apache2/access.log combined
    SSLEngine on
    SSLCertificateFile /etc/letsencrypt/live/confirmedgrowth.com/fullchain.pem
    SSLCertificateKeyFile /etc/letsencrypt/live/confirmedgrowth.com/privkey.pem
    Include /etc/letsencrypt/options-ssl-apache.conf
    ProxyPass /api/ http://127.0.0.1:3000/api/
    ProxyPassReverse /api/ http://127.0.0.1:3000/api/

    <Directory /var/www/html>
        Options -Indexes
        AllowOverride All
        Require all granted
    </Directory>
    <IfModule mod_rewrite.c>
        RewriteEngine On
        RewriteCond %{REQUEST_FILENAME} !-f
        RewriteRule ^ /index.html [L]
    </IfModule>
</VirtualHost>
</IfModule>
APACHEEOF

# 4. Restart
echo "[4/4] Restarting..."
a2enmod rewrite 2>/dev/null || true
apache2ctl configtest
systemctl reload apache2
pm2 restart confirmed

echo ""
echo "✅ Done! https://confirmedgrowth.com"
echo "✅ Booking: https://confirmedgrowth.com/book/{slug}"
