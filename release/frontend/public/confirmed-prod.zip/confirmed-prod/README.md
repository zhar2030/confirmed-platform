# CONFIRMED Platform — Production Package

## متطلبات السيرفر
- Ubuntu 22.04 LTS (Hostinger VPS)
- Node.js 20+
- Apache2 + mod_ssl + mod_rewrite + mod_proxy
- PM2 (`npm install -g pm2`)
- PostgreSQL (Hostinger Managed DB أو خارجي)
- SSL certificate (Let's Encrypt)

## خطوات التثبيت على سيرفر جديد

### 1. رفع الملف وفك الضغط
```bash
# ارفعي الملف عبر FTP/SCP ثم:
cd /root && unzip confirmed-prod.zip
```

### 2. إعداد ملف .env
```bash
nano /root/confirmed-server/.env
```
أضيفي:
```
DATABASE_URL=postgresql://user:pass@host:5432/dbname
SESSION_SECRET=any_random_64_chars_here
```

### 3. تشغيل سكريبت الديبلوي
```bash
bash /root/confirmed-prod/deploy.sh
```

السكريبت يقوم تلقائياً بـ:
- نسخ ملفات الفرونت إلى `/var/www/html/`
- كتابة `.htaccess` الصحيح (يمنع إعادة توجيه /api)
- تحديث Apache config
- نسخ الباك اند إلى `/root/api-server/dist/`
- تشغيل الباك اند عبر PM2
- فحص الصحة

### 4. إعداد SSL (إذا لم يكن موجوداً)
```bash
apt install -y certbot python3-certbot-apache
certbot --apache -d confirmedgrowth.com
```

## هيكل الملفات
```
confirmed-prod/
├── frontend/           → /var/www/html/
│   ├── index.html
│   ├── favicon.svg
│   └── assets/         → /var/www/html/assets/
├── backend/
│   └── index.mjs       → /root/api-server/dist/index.mjs
├── config/
│   ├── .htaccess       → /var/www/html/.htaccess  ⚠️ مهم جداً
│   ├── apache-ssl.conf → /etc/apache2/sites-enabled/000-default-le-ssl.conf
│   └── .env.example    → نموذج لملف .env
├── database/
│   └── schema.sql      → يُطبَّق تلقائياً عند أول تشغيل
└── deploy.sh           → سكريبت الديبلوي الشامل
```

## بعد التثبيت

| الرابط | الوصف |
|--------|-------|
| `https://confirmedgrowth.com` | الموقع الرئيسي |
| `https://confirmedgrowth.com/book/SLUG` | بوابة حجز الصالون |
| `https://confirmedgrowth.com/api/health` | فحص صحة الـ API |

## أوامر مفيدة
```bash
pm2 logs confirmed          # سجلات الباك اند
pm2 restart confirmed       # إعادة تشغيل
pm2 status                  # حالة الخدمات
tail -f /var/log/apache2/error.log  # سجلات Apache
```

## ميزات المنصة
- ✅ تسجيل دخول بـ OTP (بدون كلمة مرور)
- ✅ داشبورد صالون متكامل (حجوزات، عملاء، موظفات، خدمات، تقارير)
- ✅ بوابة حجز إلكتروني عام (`/book/:slug`)
  - اختيار الفرع (عند وجود أكثر من فرع)
  - اختيار الخدمة والموظفة والتاريخ والوقت
  - إدخال الاسم والجوال والإيميل
  - رقم حجز فوري (BK-XXXXX)
- ✅ إدارة فروع متعددة
- ✅ نظام اشتراكات
- ✅ لوحة تحكم المالك (Super Admin)
- ✅ تعدد المستأجرين (Multi-tenant) مع Row-Level Security
- ✅ واجهة عربية/إنجليزية (RTL)
