#!/bin/bash
# =================================================================
# CONFIRMED Platform — Production Deploy Script
# Tested on: Ubuntu 22.04 / Hostinger VPS
# Run as root:  bash deploy.sh
# =================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WEB_ROOT="/var/www/html"
API_DIR="/root/api-server"
ENV_FILE="/root/confirmed-server/.env"
APACHE_CONF="/etc/apache2/sites-enabled/000-default-le-ssl.conf"
PM2_APP="confirmed"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
log()  { echo -e "${GREEN}✓${NC} $1"; }
warn() { echo -e "${YELLOW}⚠${NC}  $1"; }
err()  { echo -e "${RED}✗${NC} $1"; exit 1; }

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║   CONFIRMED Platform — Production Deploy  ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# ── 1. System dependencies ──────────────────────────────────────
log "Checking system dependencies..."
command -v node  >/dev/null 2>&1 || err "Node.js not found. Install: curl -fsSL https://deb.nodesource.com/setup_20.x | bash - && apt install -y nodejs"
command -v pm2   >/dev/null 2>&1 || { warn "PM2 not found — installing..."; npm install -g pm2; }
command -v apache2ctl >/dev/null 2>&1 || err "Apache2 not found. Install: apt install -y apache2"

# Enable required Apache modules
a2enmod rewrite proxy proxy_http ssl 2>/dev/null || true

# ── 2. Check .env ───────────────────────────────────────────────
if [ ! -f "$ENV_FILE" ]; then
    warn ".env file not found at $ENV_FILE"
    mkdir -p "$(dirname "$ENV_FILE")"
    cp "$SCRIPT_DIR/config/.env.example" "$ENV_FILE"
    warn "Created $ENV_FILE from template — EDIT IT before continuing!"
    echo ""
    echo "Required: nano $ENV_FILE"
    echo "Then re-run: bash deploy.sh"
    exit 1
fi

if ! grep -q "DATABASE_URL=postgresql" "$ENV_FILE" 2>/dev/null; then
    err "DATABASE_URL not set in $ENV_FILE — cannot continue"
fi
log ".env found and valid"

# ── 3. Deploy frontend ──────────────────────────────────────────
log "Deploying frontend → $WEB_ROOT"
mkdir -p "$WEB_ROOT/assets"
cp "$SCRIPT_DIR/frontend/index.html"  "$WEB_ROOT/"
cp "$SCRIPT_DIR/frontend/favicon.svg" "$WEB_ROOT/" 2>/dev/null || true
cp "$SCRIPT_DIR/frontend/robots.txt"  "$WEB_ROOT/" 2>/dev/null || true
cp -f "$SCRIPT_DIR/frontend/assets/"* "$WEB_ROOT/assets/"

# ── 4. Deploy .htaccess (critical — prevents API rewrites) ──────
log "Writing .htaccess (API exclusion rule)..."
cp "$SCRIPT_DIR/config/.htaccess" "$WEB_ROOT/.htaccess"

# ── 5. Deploy Apache config ─────────────────────────────────────
log "Updating Apache SSL config..."
cp "$SCRIPT_DIR/config/apache-ssl.conf" "$APACHE_CONF"
apache2ctl configtest 2>&1 | grep -E "Syntax|Error" || true
systemctl reload apache2
log "Apache reloaded"

# ── 6. Deploy backend ───────────────────────────────────────────
log "Deploying backend → $API_DIR/dist/"
mkdir -p "$API_DIR/dist"
cp "$SCRIPT_DIR/backend/index.mjs" "$API_DIR/dist/index.mjs"

# Copy DB schema (used by auto-migration on first boot)
mkdir -p "$API_DIR/dist"
cp "$SCRIPT_DIR/database/schema.sql" "$API_DIR/dist/database.sql" 2>/dev/null || true

# ── 7. Start / restart backend ──────────────────────────────────
log "Starting backend with PM2..."
if pm2 describe "$PM2_APP" >/dev/null 2>&1; then
    pm2 restart "$PM2_APP" --update-env
else
    pm2 start "$API_DIR/dist/index.mjs" \
        --name "$PM2_APP" \
        --node-args="--env-file=$ENV_FILE" \
        --env NODE_ENV=production \
        -- 
    # Fallback if --node-args not supported
    pm2 delete "$PM2_APP" 2>/dev/null || true
    export $(grep -v '^#' "$ENV_FILE" | xargs) 2>/dev/null || true
    NODE_ENV=production pm2 start "$API_DIR/dist/index.mjs" --name "$PM2_APP"
fi
pm2 save 2>/dev/null || true
pm2 startup 2>/dev/null | tail -1 | bash 2>/dev/null || true

# ── 8. Health check ─────────────────────────────────────────────
sleep 3
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:3000/api/health 2>/dev/null || echo "000")
if [ "$HTTP_CODE" = "200" ] || [ "$HTTP_CODE" = "404" ]; then
    log "Backend is responding (HTTP $HTTP_CODE)"
else
    warn "Backend health check returned HTTP $HTTP_CODE — check logs: pm2 logs $PM2_APP"
fi

# ── Done ────────────────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════╗"
echo "║          ✅  Deploy Complete!             ║"
echo "╚══════════════════════════════════════════╝"
echo ""
echo "  Site:      https://confirmedgrowth.com"
echo "  Bookings:  https://confirmedgrowth.com/book/YOUR_SLUG"
echo "  API:       https://confirmedgrowth.com/api/health"
echo ""
echo "  Useful commands:"
echo "    pm2 logs $PM2_APP        # Backend logs"
echo "    pm2 status               # Process status"
echo "    tail -f /var/log/apache2/error.log  # Apache errors"
echo ""
